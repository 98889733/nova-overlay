var A=window.Android||{close(){},setAccent(){},exitApp(){},hasOverlay(){return true},requestOverlay(){},startMenu(){},stopMenu(){}};
var st={};try{st=JSON.parse(localStorage.getItem('nova')||'{}')}catch(e){}
function save(){try{localStorage.setItem('nova',JSON.stringify(st))}catch(e){}}
var accent=st.accent||'#7C5CFF';
document.documentElement.style.setProperty('--a',accent);
function setAccent(c){accent=c;st.accent=c;save();document.documentElement.style.setProperty('--a',c);try{A.setAccent(c)}catch(e){}}
function toast(t){var e=document.getElementById('toast');if(!e)return;e.textContent=t;e.classList.add('on');clearTimeout(e._t);e._t=setTimeout(function(){e.classList.remove('on')},1200)}
function rgba(a){var h=accent.replace('#','');return 'rgba('+parseInt(h.substr(0,2),16)+','+parseInt(h.substr(2,2),16)+','+parseInt(h.substr(4,2),16)+','+a+')'}
function hsl(h){var s=.9,l=.6,a=s*Math.min(l,1-l),f=function(n){var k=(n+h/30)%12,v=l-a*Math.max(Math.min(k-3,9-k,1),-1);return Math.round(v*255).toString(16).padStart(2,'0')};return '#'+f(0)+f(8)+f(4)}
// background engine: modes stars | tri | sq | off
var cv,cx,W,H,P=[],dpr=window.devicePixelRatio||1;
function bgInit(){cv=document.getElementById('bg');if(!cv)return;cx=cv.getContext('2d');W=cv.clientWidth;H=cv.clientHeight;cv.width=W*dpr;cv.height=H*dpr;cx.setTransform(dpr,0,0,dpr,0,0);
 P=[];var n=st.count||60;for(var i=0;i<n;i++)P.push({x:Math.random()*W,y:Math.random()*H,vx:(Math.random()-.5)*.6,vy:(Math.random()-.5)*.6,r:Math.random()*1.5+.7,s:6+Math.random()*10,a:Math.random()*6.28,w:(Math.random()-.5)*.03})}
function shape(p,m){cx.save();cx.translate(p.x,p.y);cx.rotate(p.a);cx.strokeStyle=rgba(.7);cx.lineWidth=1.2;cx.beginPath();
 if(m=='sq'){cx.rect(-p.s/2,-p.s/2,p.s,p.s)}else{cx.moveTo(0,-p.s);cx.lineTo(p.s,p.s*.8);cx.lineTo(-p.s,p.s*.8);cx.closePath()}cx.stroke();cx.restore()}
function bgLoop(){if(!cx)return;cx.clearRect(0,0,W,H);var m=st.bg||'stars';
 if(m!='off'){for(var i=0;i<P.length;i++){var p=P[i];p.x+=p.vx;p.y+=p.vy;p.a+=p.w;if(p.x<0||p.x>W)p.vx*=-1;if(p.y<0||p.y>H)p.vy*=-1;
  if(m=='stars'){cx.fillStyle=rgba(.9);cx.beginPath();cx.arc(p.x,p.y,p.r,0,6.283);cx.fill();
   for(var j=i+1;j<P.length;j++){var q=P[j],dx=p.x-q.x,dy=p.y-q.y,d=Math.sqrt(dx*dx+dy*dy);if(d<90){cx.strokeStyle=rgba(.5*(1-d/90));cx.lineWidth=.8;cx.beginPath();cx.moveTo(p.x,p.y);cx.lineTo(q.x,q.y);cx.stroke()}}}
  else shape(p,m)}}
 requestAnimationFrame(bgLoop)}
function bgStart(){bgInit();bgLoop();window.onresize=bgInit}
// shared appearance settings
function buildAppearance(el){
 var cols=['#7C5CFF','#00D1FF','#00E676','#FF4D6A','#FFB300','#FF4DE1','#FFFFFF'];
 el.innerHTML='<div class="sec">ACCENT COLOR</div><div class="row col"><div class="chips" id="cols"></div></div>'+
 '<div class="row col"><div class="top2"><span>Custom hue</span></div><input type="range" class="hue" id="hue" min="0" max="360" value="260"></div>'+
 '<div class="sec">BACKGROUND</div><div class="row col"><div class="chips" id="bgs"></div></div>'+
 '<div class="row col"><div class="top2"><span>Particle count</span><span class="val" id="cv">'+(st.count||60)+'</span></div><input type="range" id="cnt" min="10" max="150" value="'+(st.count||60)+'"></div>';
 var ce=el.querySelector('#cols');cols.forEach(function(c){var d=document.createElement('div');d.className='c'+(c==accent?' on':'');d.style.background=c;
  d.onclick=function(){[].forEach.call(ce.children,function(x){x.classList.remove('on')});d.classList.add('on');setAccent(c)};ce.appendChild(d)});
 el.querySelector('#hue').oninput=function(e){[].forEach.call(ce.children,function(x){x.classList.remove('on')});setAccent(hsl(e.target.value))};
 var be=el.querySelector('#bgs');[['stars','Stars'],['tri','Triangles'],['sq','Squares'],['off','Off']].forEach(function(b){var d=document.createElement('div');d.className='chip'+((st.bg||'stars')==b[0]?' on':'');d.textContent=b[1];
  d.onclick=function(){[].forEach.call(be.children,function(x){x.classList.remove('on')});d.classList.add('on');st.bg=b[0];save()};be.appendChild(d)});
 el.querySelector('#cnt').oninput=function(e){st.count=+e.target.value;save();el.querySelector('#cv').textContent=st.count;bgInit()}}
function planText(){if(!st.plan)return 'No license';var left=st.exp==0?'Lifetime':Math.max(0,Math.ceil((st.exp-Date.now())/864e5))+' days left';return st.plan+'  |  '+left}
function xp(n){st.xp=(st.xp||0)+n;save()}
function level(){return 1+Math.floor((st.xp||0)/100)}
