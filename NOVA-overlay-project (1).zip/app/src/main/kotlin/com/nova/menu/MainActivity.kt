package com.nova.menu

import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.webkit.JavascriptInterface
import android.webkit.WebView
import android.widget.Toast

class MainActivity : Activity() {
    private lateinit var wv: WebView

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        wv = WebView(this)
        wv.setBackgroundColor(Color.parseColor("#0B0B14"))
        wv.settings.javaScriptEnabled = true
        wv.settings.domStorageEnabled = true
        wv.addJavascriptInterface(object {
            @JavascriptInterface fun hasOverlay(): Boolean = Settings.canDrawOverlays(this@MainActivity)
            @JavascriptInterface fun requestOverlay() {
                runOnUiThread {
                    startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
                }
            }
            @JavascriptInterface fun startMenu() {
                runOnUiThread {
                    if (!Settings.canDrawOverlays(this@MainActivity)) {
                        Toast.makeText(this@MainActivity, "Allow overlay first", Toast.LENGTH_SHORT).show()
                    } else {
                        val i = Intent(this@MainActivity, OverlayService::class.java)
                        startForegroundService(i)
                        Toast.makeText(this@MainActivity, "Menu started. Open any game or app.", Toast.LENGTH_LONG).show()
                        moveTaskToBack(true)
                    }
                }
            }
            @JavascriptInterface fun stopMenu() { runOnUiThread { stopService(Intent(this@MainActivity, OverlayService::class.java)) } }
            @JavascriptInterface fun setAccent(c: String) {}
            @JavascriptInterface fun close() {}
            @JavascriptInterface fun exitApp() {}
        }, "Android")
        wv.loadUrl("file:///android_asset/app.html")
        setContentView(wv)
        if (Build.VERSION.SDK_INT >= 33) requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
    }

    override fun onResume() {
        super.onResume()
        if (::wv.isInitialized) wv.evaluateJavascript("if(window.refresh)refresh()", null)
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() { moveTaskToBack(true) }
}
