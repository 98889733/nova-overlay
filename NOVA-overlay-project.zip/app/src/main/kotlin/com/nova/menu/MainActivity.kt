package com.nova.menu

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    private lateinit var status: TextView

    private fun btn(text: String, onClick: () -> Unit): Button {
        val b = Button(this)
        b.text = text
        b.setTextColor(Color.WHITE)
        b.isAllCaps = false
        val bg = GradientDrawable()
        bg.cornerRadius = 40f
        bg.setColor(Color.parseColor("#2A2150"))
        bg.setStroke(3, Color.parseColor("#7C5CFF"))
        b.background = bg
        val lp = LinearLayout.LayoutParams(-1, 140)
        lp.topMargin = 28
        b.layoutParams = lp
        b.setOnClickListener { onClick() }
        return b
    }

    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.gravity = Gravity.CENTER
        root.setBackgroundColor(Color.parseColor("#0B0B14"))
        root.setPadding(70, 40, 70, 40)

        val title = TextView(this)
        title.text = "NOVA CLIENT"
        title.textSize = 30f
        title.setTextColor(Color.parseColor("#7C5CFF"))
        title.gravity = Gravity.CENTER
        root.addView(title)

        status = TextView(this)
        status.textSize = 14f
        status.setTextColor(Color.parseColor("#9A9AB5"))
        status.gravity = Gravity.CENTER
        status.setPadding(0, 20, 0, 30)
        root.addView(status)

        root.addView(btn("1. Allow overlay permission") {
            if (!Settings.canDrawOverlays(this)) {
                startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            } else Toast.makeText(this, "Already allowed", Toast.LENGTH_SHORT).show()
        })
        root.addView(btn("2. Start menu") {
            if (!Settings.canDrawOverlays(this)) {
                Toast.makeText(this, "Allow overlay first", Toast.LENGTH_SHORT).show()
            } else {
                val i = Intent(this, OverlayService::class.java)
                if (Build.VERSION.SDK_INT >= 26) startForegroundService(i) else startService(i)
                Toast.makeText(this, "Menu started. Open any game or app.", Toast.LENGTH_LONG).show()
                moveTaskToBack(true)
            }
        })
        root.addView(btn("Stop menu") { stopService(Intent(this, OverlayService::class.java)) })
        setContentView(root)

        if (Build.VERSION.SDK_INT >= 33) requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
    }

    override fun onResume() {
        super.onResume()
        status.text = if (Settings.canDrawOverlays(this)) "Overlay permission: granted" else "Overlay permission: not granted"
    }
}
