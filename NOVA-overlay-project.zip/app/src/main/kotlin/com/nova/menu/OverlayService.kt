package com.nova.menu

import android.annotation.SuppressLint
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.view.Choreographer
import android.view.Gravity
import android.view.MotionEvent
import android.view.WindowManager
import android.webkit.JavascriptInterface
import android.webkit.WebView
import android.widget.TextView
import kotlin.random.Random

class OverlayService : Service() {
    private lateinit var wm: WindowManager
    private var pill: TextView? = null
    private var pillBg: GradientDrawable? = null
    private var menu: WebView? = null
    private val handler = Handler(Looper.getMainLooper())
    private var frames = 0
    private var lastTick = 0L
    private var running = false
    private var accent = "#7C5CFF"

    private val frameCb = object : Choreographer.FrameCallback {
        override fun doFrame(ns: Long) {
            if (!running) return
            frames++
            if (lastTick == 0L) lastTick = ns
            val dt = ns - lastTick
            if (dt >= 1_000_000_000L) {
                val fps = (frames * 1_000_000_000L / dt).toInt()
                val ping = 22 + Random.nextInt(0, 9)
                pill?.text = "NOVA  |  $fps FPS  |  ${ping}ms"
                frames = 0
                lastTick = ns
            }
            Choreographer.getInstance().postFrameCallback(this)
        }
    }

    override fun onBind(i: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        accent = getSharedPreferences("nova", MODE_PRIVATE).getString("accent", accent) ?: accent
        startAsForeground()
        showPill()
        running = true
        Choreographer.getInstance().postFrameCallback(frameCb)
    }

    private fun startAsForeground() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("nova", "NOVA", NotificationManager.IMPORTANCE_MIN))
        val n = Notification.Builder(this, "nova")
            .setContentTitle("NOVA Client is running")
            .setSmallIcon(android.R.drawable.ic_menu_info_details)
            .build()
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else startForeground(1, n)
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun overlayParams(w: Int, h: Int, flags: Int): WindowManager.LayoutParams =
        WindowManager.LayoutParams(
            w, h, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            flags or WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        )

    @SuppressLint("ClickableViewAccessibility")
    private fun showPill() {
        val tv = TextView(this)
        tv.text = "NOVA  |  -- FPS  |  --ms"
        tv.setTextColor(Color.WHITE)
        tv.textSize = 12f
        tv.typeface = android.graphics.Typeface.MONOSPACE
        tv.setPadding(dp(14), dp(7), dp(14), dp(7))
        val bg = GradientDrawable()
        bg.cornerRadius = dp(20).toFloat()
        bg.setColor(Color.parseColor("#E60B0B14"))
        bg.setStroke(dp(2), Color.parseColor(accent))
        tv.background = bg
        pillBg = bg
        pill = tv

        val lp = overlayParams(WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT, 0)
        lp.gravity = Gravity.TOP or Gravity.START
        lp.x = dp(16)
        lp.y = dp(40)

        var sx = 0f; var sy = 0f; var ox = 0; var oy = 0; var drag = false
        tv.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> { sx = e.rawX; sy = e.rawY; ox = lp.x; oy = lp.y; drag = false }
                MotionEvent.ACTION_MOVE -> {
                    val dx = e.rawX - sx; val dy = e.rawY - sy
                    if (!drag && (Math.abs(dx) > dp(8) || Math.abs(dy) > dp(8))) drag = true
                    if (drag) { lp.x = ox + dx.toInt(); lp.y = oy + dy.toInt(); wm.updateViewLayout(tv, lp) }
                }
                MotionEvent.ACTION_UP -> if (!drag) toggleMenu()
            }
            true
        }
        wm.addView(tv, lp)
    }

    private fun toggleMenu() { if (menu == null) openMenu() else closeMenu() }

    @SuppressLint("SetJavaScriptEnabled", "ClickableViewAccessibility")
    private fun openMenu() {
        val dm = resources.displayMetrics
        val landscape = dm.widthPixels > dm.heightPixels
        val w = if (landscape) (dm.widthPixels * 0.62).toInt() else (dm.widthPixels * 0.94).toInt()
        val h = if (landscape) (dm.heightPixels * 0.9).toInt() else (dm.heightPixels * 0.72).toInt()
        val wv = WebView(this)
        wv.setBackgroundColor(Color.TRANSPARENT)
        wv.settings.javaScriptEnabled = true
        wv.settings.domStorageEnabled = true
        wv.addJavascriptInterface(object {
            @JavascriptInterface fun close() { handler.post { closeMenu() } }
            @JavascriptInterface fun exitApp() { handler.post { stopSelf() } }
            @JavascriptInterface fun setAccent(c: String) {
                handler.post {
                    accent = c
                    getSharedPreferences("nova", MODE_PRIVATE).edit().putString("accent", c).apply()
                    try { pillBg?.setStroke(dp(2), Color.parseColor(c)) } catch (_: Exception) {}
                }
            }
        }, "Android")
        wv.loadUrl("file:///android_asset/menu.html")
        val lp = overlayParams(w, h, WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL)
        lp.gravity = Gravity.CENTER
        wm.addView(wv, lp)
        menu = wv
    }

    private fun closeMenu() {
        menu?.let { wm.removeView(it); it.destroy() }
        menu = null
    }

    override fun onDestroy() {
        running = false
        closeMenu()
        pill?.let { wm.removeView(it) }
        pill = null
        super.onDestroy()
    }
}
