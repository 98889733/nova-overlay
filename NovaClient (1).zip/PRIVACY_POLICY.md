# Privacy Policy — NOVA Client

NOVA Client does not collect, transmit or share any personal data. It has no accounts, no ads, no analytics and no network access.

All data stays on your device:
- App settings, level and XP are stored locally in the app's private storage.
- Screenshots and screen recordings are created only when you press the button, are stored in the app's private storage, and are copied to your Photos/Movies only when you press "Download".
- The screen-capture permission is used only for screenshots and recordings you start yourself. Nothing is uploaded.
- The "display over other apps" permission is used only to show the floating FPS pill and menu.
- The list of installed apps is read only to let you pick apps to launch from the floating menu. It never leaves the device.

Contact: add your e-mail here before publishing.
