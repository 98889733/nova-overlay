plugins { id("com.android.application"); id("org.jetbrains.kotlin.android") }
android {
    namespace = "com.nova.client"
    compileSdk = 34
    defaultConfig { applicationId = "com.nova.client"; minSdk = 29; targetSdk = 34; versionCode = 1; versionName = "1.0" }
    signingConfigs { create("nova") { storeFile = file("nova.jks"); storePassword = "android"; keyAlias = "nova"; keyPassword = "android" } }
    buildTypes { getByName("debug") { signingConfig = signingConfigs.getByName("nova") } }
    compileOptions { sourceCompatibility = JavaVersion.VERSION_17; targetCompatibility = JavaVersion.VERSION_17 }
    kotlinOptions { jvmTarget = "17" }
}
