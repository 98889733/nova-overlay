plugins { id("com.android.application"); id("org.jetbrains.kotlin.android") }
android {
    namespace = "com.nova.client"
    compileSdk = 34
    defaultConfig { applicationId = "com.nova.client"; minSdk = 29; targetSdk = 34; versionCode = (System.getenv("GITHUB_RUN_NUMBER")?.toIntOrNull() ?: 2); versionName = "1.1" }
    signingConfigs { create("nova") { storeFile = file("nova.jks"); storePassword = "android"; keyAlias = "nova"; keyPassword = "android" } }
    signingConfigs { create("rel") { if (System.getenv("KS_PASS") != null && file("release.jks").exists()) { storeFile = file("release.jks"); storePassword = System.getenv("KS_PASS"); keyAlias = System.getenv("KS_ALIAS") ?: "nova"; keyPassword = System.getenv("KS_PASS") } } }
    buildTypes {
        getByName("debug") { signingConfig = signingConfigs.getByName("nova") }
        getByName("release") {
            isMinifyEnabled = true; isShrinkResources = true
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
            signingConfig = if (System.getenv("KS_PASS") != null && file("release.jks").exists()) signingConfigs.getByName("rel") else signingConfigs.getByName("nova")
        }
    }
    compileOptions { sourceCompatibility = JavaVersion.VERSION_17; targetCompatibility = JavaVersion.VERSION_17 }
    kotlinOptions { jvmTarget = "17" }
}
