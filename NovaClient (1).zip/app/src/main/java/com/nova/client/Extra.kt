package com.nova.client
import android.content.*
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.provider.Settings
import android.widget.*

var torch = false
fun flash(c: Context) {
    try {
        val cm = c.getSystemService(CameraManager::class.java)
        val id = cm.cameraIdList.firstOrNull { cm.getCameraCharacteristics(it).get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true } ?: return
        torch = !torch; cm.setTorchMode(id, torch)
    } catch (e: Exception) { Toast.makeText(c, "Фонарик недоступен", Toast.LENGTH_SHORT).show() }
}
class BootReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        P.init(c)
        if (P.sp.getBoolean("boot", false) && Settings.canDrawOverlays(c)) c.startForegroundService(Intent(c, OverlayService::class.java))
    }
}
