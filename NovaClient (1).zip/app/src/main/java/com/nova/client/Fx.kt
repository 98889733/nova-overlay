package com.nova.client
import android.animation.Animator
import android.animation.AnimatorListenerAdapter
import android.animation.ValueAnimator
import android.content.Context
import android.graphics.*
import android.text.StaticLayout
import android.text.TextPaint
import android.view.*
import android.view.animation.OvershootInterpolator
import android.widget.*
import java.util.Random
import kotlin.math.*

fun withA(c: Int, a: Int) = Color.argb(a.coerceIn(0, 255), Color.red(c), Color.green(c), Color.blue(c))
fun ease(x: Float): Float { val c = x.coerceIn(0f, 1f); return 1f - (1f - c) * (1f - c) * (1f - c) }
fun clamp01(x: Float) = x.coerceIn(0f, 1f)
fun boltPts(rnd: Random, d: Float, x0: Float, y0: Float, x1: Float, y1: Float, amp: Float, n: Int = 12): List<PointF> {
    val pts = ArrayList<PointF>()
    val dx = x1 - x0; val dy = y1 - y0; val len = max(1f, hypot(dx, dy)); val nx = -dy / len; val ny = dx / len
    for (i in 0..n) {
        val f = i / n.toFloat(); val off = if (i == 0 || i == n) 0f else (rnd.nextFloat() - 0.5f) * amp
        pts.add(PointF(x0 + dx * f + nx * off, y0 + dy * f + ny * off))
    }
    return pts
}
fun drawBolt(cv: Canvas, p: Paint, d: Float, pts: List<PointF>, a: Float) {
    val path = Path()
    pts.forEachIndexed { i, q -> if (i == 0) path.moveTo(q.x, q.y) else path.lineTo(q.x, q.y) }
    p.shader = null; p.style = Paint.Style.STROKE; p.strokeJoin = Paint.Join.ROUND
    p.strokeWidth = 8 * d; p.color = withA(P.accent, (120 * a).toInt()); cv.drawPath(path, p)
    p.strokeWidth = 2.2f * d; p.color = withA(Color.WHITE, (255 * a).toInt()); cv.drawPath(path, p)
}

// ---------- Реактивная кнопка NOVA
class NovaBtn(c: Context, val onTap: () -> Unit) : View(c) {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG); private var ring = -1f; private var t = 0f
    init {
        setOnClickListener { performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP); pulse(); onTap() }
        setOnTouchListener { v, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> v.animate().scaleX(0.86f).scaleY(0.86f).setDuration(80).start()
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> v.animate().scaleX(1f).scaleY(1f).setDuration(240).setInterpolator(OvershootInterpolator(3f)).start()
            }
            false
        }
    }
    private fun pulse() {
        val an = ValueAnimator.ofFloat(0f, 1f); an.duration = 600
        an.addUpdateListener { ring = it.animatedValue as Float }
        an.addListener(object : AnimatorListenerAdapter() { override fun onAnimationEnd(a: Animator) { ring = -1f } })
        an.start()
    }
    override fun onDraw(cv: Canvas) {
        t += 0.05f; val d = context.resources.displayMetrics.density; val cx = width / 2f; val cy = height / 2f
        val r = 14 * d * (1f + 0.05f * sin(t))
        if (ring >= 0f) { p.style = Paint.Style.STROKE; p.strokeWidth = 2.5f * d; p.color = withA(P.accent, ((1 - ring) * 200).toInt()); cv.drawCircle(cx, cy, r + ring * 8 * d, p) }
        p.style = Paint.Style.FILL
        p.shader = RadialGradient(cx - r * 0.3f, cy - r * 0.3f, r * 1.4f, P.mix(P.accent, Color.WHITE, 0.35f), P.mix(P.accent, Color.BLACK, 0.3f), Shader.TileMode.CLAMP)
        cv.drawCircle(cx, cy, r, p); p.shader = null
        p.color = Color.WHITE; p.textAlign = Paint.Align.CENTER; p.textSize = 15 * d; p.typeface = Typeface.DEFAULT_BOLD
        cv.drawText("N", cx, cy - (p.ascent() + p.descent()) / 2, p)
        postInvalidateOnAnimation()
    }
}

// ---------- Маскот NOVA
class Mascot(c: Context) : View(c) {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG); private var t = 0f; private var jump = 0f; private var smile = 0f
    private var msg = "Привет! Я NOVA"; private var sl: StaticLayout? = null; private var slKey = ""
    private val phrases = listOf("Привет! Я NOVA", "Давай поднимем уровень!", "Лови звёзды в играх!", "Секрет ищешь? Я не скажу", "Молнии — это красиво", "Ты крутой!", "Нажми на меня ещё")
    private val rnd = Random()
    init { setOnClickListener { jump = 1f; smile = 1f; msg = phrases[rnd.nextInt(phrases.size)]; performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP) } }
    override fun onMeasure(w: Int, h: Int) { setMeasuredDimension(MeasureSpec.getSize(w), context.dp(150)) }
    override fun onDraw(cv: Canvas) {
        t += 0.05f; jump = max(0f, jump - 0.035f); smile = max(0f, smile - 0.01f)
        val d = context.resources.displayMetrics.density; val cx = 70 * d; val base = height - 18 * d
        val bob = sin(t) * 4 * d - sin(jump * PI.toFloat()) * 26 * d
        p.style = Paint.Style.FILL; p.color = 0x22000000; cv.drawOval(RectF(cx - 36 * d, base - 6 * d, cx + 36 * d, base + 6 * d), p)
        val top = base - 96 * d + bob; val bot = base + bob
        p.style = Paint.Style.STROKE; p.strokeWidth = 3 * d; p.color = P.sub(); cv.drawLine(cx, top, cx, top - 14 * d, p)
        p.style = Paint.Style.FILL; p.color = P.accent; cv.drawCircle(cx, top - 16 * d, 6 * d * (1f + 0.3f * sin(t * 3)), p)
        p.shader = LinearGradient(cx, top, cx, bot, P.accent, P.mix(P.accent, Color.BLACK, 0.35f), Shader.TileMode.CLAMP)
        cv.drawRoundRect(RectF(cx - 40 * d, top, cx + 40 * d, bot), 28 * d, 28 * d, p); p.shader = null
        p.color = 0xFF10121A.toInt(); cv.drawRoundRect(RectF(cx - 30 * d, top + 14 * d, cx + 30 * d, top + 54 * d), 16 * d, 16 * d, p)
        val blink = if ((t % 4f) > 3.85f) 0.15f else 1f; val look = sin(t * 0.7f) * 3 * d
        p.color = Color.WHITE
        for (ex in floatArrayOf(cx - 14 * d, cx + 14 * d)) cv.drawOval(RectF(ex - 6 * d + look, top + 32 * d - 8 * d * blink, ex + 6 * d + look, top + 32 * d + 8 * d * blink), p)
        p.style = Paint.Style.STROKE; p.strokeWidth = 2.5f * d; p.color = P.accent; p.strokeCap = Paint.Cap.ROUND
        cv.drawArc(RectF(cx - 9 * d, top + 38 * d, cx + 9 * d, top + 48 * d + smile * 6 * d), 0f, 180f, false, p)
        p.strokeCap = Paint.Cap.BUTT
        val bx = cx + 56 * d; val bw = width - bx - 10 * d
        if (bw > 80 * d) {
            val key = msg + bw.toInt()
            if (sl == null || key != slKey) {
                val tp = TextPaint(Paint.ANTI_ALIAS_FLAG); tp.textSize = 13 * d; tp.color = P.fg()
                sl = StaticLayout.Builder.obtain(msg, 0, msg.length, tp, (bw - 20 * d).toInt()).build(); slKey = key
            }
            val l = sl!!; val bh = l.height + 20 * d; val by = base - 56 * d - bh / 2
            p.style = Paint.Style.FILL; p.color = P.mix(P.bg(), P.fg(), 0.1f); cv.drawRoundRect(RectF(bx, by, bx + bw, by + bh), 14 * d, 14 * d, p)
            cv.save(); cv.translate(bx + 10 * d, by + 10 * d); l.draw(cv); cv.restore()
        }
        postInvalidateOnAnimation()
    }
}

// ---------- 3D-иконки
class Icon3D(c: Context, val kind: String) : View(c) {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    override fun onMeasure(w: Int, h: Int) { val s = context.dp(46); setMeasuredDimension(s, s) }
    private fun glyph(cv: Canvas, cx: Float, cy: Float, s: Float, main: Boolean, tile: Int) {
        val ink = if (main) Color.WHITE else 0x66000000
        val hole = if (main) P.mix(tile, Color.BLACK, 0.25f) else 0x66000000
        p.shader = null; p.style = Paint.Style.FILL; p.color = ink
        when (kind) {
            "shot" -> { cv.drawRoundRect(RectF(cx - 2.6f * s, cy - 1.6f * s, cx + 2.6f * s, cy + 2f * s), s * .5f, s * .5f, p); p.color = hole; cv.drawCircle(cx, cy + .2f * s, 1.1f * s, p); p.color = ink; cv.drawCircle(cx, cy + .2f * s, .6f * s, p) }
            "rec" -> { p.style = Paint.Style.STROKE; p.strokeWidth = .5f * s; cv.drawCircle(cx, cy, 2.3f * s, p); p.style = Paint.Style.FILL; p.color = if (main) 0xFFFF4D4D.toInt() else ink; cv.drawCircle(cx, cy, 1.2f * s, p) }
            "torch" -> {
                val pa = Path(); pa.moveTo(cx - 2f * s, cy - 2.4f * s); pa.lineTo(cx + 2f * s, cy - 2.4f * s); pa.lineTo(cx + 1.2f * s, cy - .4f * s); pa.lineTo(cx - 1.2f * s, cy - .4f * s); pa.close()
                cv.drawPath(pa, p); cv.drawRoundRect(RectF(cx - 1.2f * s, cy - .1f * s, cx + 1.2f * s, cy + 2.6f * s), .4f * s, .4f * s, p)
            }
            "timer" -> {
                p.style = Paint.Style.STROKE; p.strokeWidth = .55f * s; cv.drawCircle(cx, cy + .3f * s, 2.2f * s, p)
                cv.drawLine(cx, cy + .3f * s, cx, cy - 1.1f * s, p); cv.drawLine(cx, cy + .3f * s, cx + 1.1f * s, cy + .9f * s, p)
                p.style = Paint.Style.FILL; cv.drawRect(cx - .6f * s, cy - 2.9f * s, cx + .6f * s, cy - 2.3f * s, p)
            }
            "cross" -> {
                p.style = Paint.Style.STROKE; p.strokeWidth = .5f * s
                cv.drawLine(cx - 2.6f * s, cy, cx - .8f * s, cy, p); cv.drawLine(cx + .8f * s, cy, cx + 2.6f * s, cy, p)
                cv.drawLine(cx, cy - 2.6f * s, cx, cy - .8f * s, p); cv.drawLine(cx, cy + .8f * s, cx, cy + 2.6f * s, p); cv.drawCircle(cx, cy, 1.8f * s, p)
            }
            "game" -> {
                cv.drawRoundRect(RectF(cx - 3f * s, cy - 1.6f * s, cx + 3f * s, cy + 1.8f * s), 1.2f * s, 1.2f * s, p); p.color = hole
                cv.drawRect(cx - 2.2f * s, cy - .25f * s, cx - .6f * s, cy + .25f * s, p); cv.drawRect(cx - 1.65f * s, cy - .8f * s, cx - 1.15f * s, cy + .8f * s, p)
                cv.drawCircle(cx + 1.2f * s, cy + .4f * s, .35f * s, p); cv.drawCircle(cx + 2f * s, cy - .2f * s, .35f * s, p)
            }
            "phone" -> { cv.drawRoundRect(RectF(cx - 1.7f * s, cy - 2.7f * s, cx + 1.7f * s, cy + 2.7f * s), .6f * s, .6f * s, p); p.color = hole; cv.drawRect(cx - 1.2f * s, cy - 2.1f * s, cx + 1.2f * s, cy + 1.8f * s, p) }
            "apps" -> { for (i in 0..1) for (j in 0..1) cv.drawRoundRect(RectF(cx - 2.3f * s + i * 2.5f * s, cy - 2.3f * s + j * 2.5f * s, cx - .2f * s + i * 2.5f * s, cy - .2f * s + j * 2.5f * s), .4f * s, .4f * s, p) }
            "fun" -> { cv.drawRoundRect(RectF(cx - 2.3f * s, cy - 2.3f * s, cx + 2.3f * s, cy + 2.3f * s), .8f * s, .8f * s, p); p.color = hole; for (k in -1..1) cv.drawCircle(cx + k * 1.3f * s, cy + k * 1.3f * s, .38f * s, p) }
            else -> {
                p.style = Paint.Style.STROKE; p.strokeWidth = .9f * s; cv.drawCircle(cx, cy, 1.5f * s, p); p.style = Paint.Style.FILL
                for (i in 0 until 8) { cv.save(); cv.rotate(i * 45f, cx, cy); cv.drawRect(cx - .35f * s, cy - 2.7f * s, cx + .35f * s, cy - 1.9f * s, p); cv.restore() }
            }
        }
    }
    override fun onDraw(cv: Canvas) {
        val d = context.resources.displayMetrics.density; val w = width.toFloat(); val h = height.toFloat(); val col = P.accent
        val depth = 4 * d; val l = 3 * d; val t = 3 * d; val r = w - 3 * d; val b = h - 3 * d - depth
        p.style = Paint.Style.FILL; p.shader = null; p.color = P.mix(col, Color.BLACK, 0.5f); cv.drawRoundRect(RectF(l, t + depth, r, b + depth), 12 * d, 12 * d, p)
        p.shader = LinearGradient(0f, t, 0f, b, P.mix(col, Color.WHITE, 0.35f), col, Shader.TileMode.CLAMP); cv.drawRoundRect(RectF(l, t, r, b), 12 * d, 12 * d, p); p.shader = null
        p.color = 0x33FFFFFF; cv.drawRoundRect(RectF(l + 3 * d, t + 2 * d, r - 3 * d, t + (b - t) * 0.42f), 9 * d, 9 * d, p)
        val cx = (l + r) / 2; val cy = (t + b) / 2; val s = 5.2f * d
        glyph(cv, cx + 1.2f * d, cy + 1.8f * d, s, false, col); glyph(cv, cx, cy, s, true, col)
    }
}
fun Context.toolRow(kind: String, label: String, sub: String = "", f: () -> Unit): View = LinearLayout(this).apply {
    gravity = Gravity.CENTER_VERTICAL; setPadding(dp(10), dp(8), dp(12), dp(8)); background = rr(P.card(), dp(14).toFloat(), P.mix(P.bg(), P.fg(), 0.1f))
    addView(Icon3D(context, kind), LinearLayout.LayoutParams(dp(46), dp(46)))
    addView(LinearLayout(context).apply {
        orientation = LinearLayout.VERTICAL; addView(tv(label, 15f, P.fg(), true)); if (sub.isNotEmpty()) addView(tv(sub, 12f, P.sub()))
    }, LinearLayout.LayoutParams(0, -2, 1f).apply { leftMargin = dp(12) })
    setOnClickListener { f() }
    setOnTouchListener { v, e ->
        when (e.action) {
            MotionEvent.ACTION_DOWN -> v.animate().scaleX(.96f).scaleY(.96f).setDuration(80).start()
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> v.animate().scaleX(1f).scaleY(1f).setDuration(120).start()
        }
        false
    }
}

// ---------- Эквалайзер (анимация, не реагирует на музыку)
class Eq(c: Context) : View(c) {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG); private val n = 28
    private val v = FloatArray(n); private val tg = FloatArray(n); private var t = 0f; private var style = P.int("eqs", 0); private val rnd = Random()
    init { setOnClickListener { style = (style + 1) % 3; P.putI("eqs", style) } }
    override fun onMeasure(w: Int, h: Int) { setMeasuredDimension(MeasureSpec.getSize(w), context.dp(90)) }
    override fun onDraw(cv: Canvas) {
        t += 0.06f
        for (i in 0 until n) { if (rnd.nextInt(8) == 0) tg[i] = rnd.nextFloat() * (0.4f + 0.6f * (0.5f + 0.5f * sin(t * 0.7f + i * 0.3f))); v[i] += (tg[i] - v[i]) * 0.18f }
        val w = width.toFloat(); val h = height.toFloat(); p.color = P.accent; p.shader = null
        when (style) {
            0 -> { p.style = Paint.Style.FILL; val bw = w / n; for (i in 0 until n) { val bh = 6 + v[i] * (h - 10); cv.drawRoundRect(RectF(i * bw + 2, h - bh, (i + 1) * bw - 2, h), 4f, 4f, p) } }
            1 -> {
                p.style = Paint.Style.STROKE; p.strokeWidth = 3 * context.resources.displayMetrics.density; val path = Path()
                for (i in 0 until n) { val x = i * w / (n - 1); val y = h / 2 + (v[i] - 0.5f) * h * 0.9f * (if (i % 2 == 0) 1f else -1f); if (i == 0) path.moveTo(x, y) else path.lineTo(x, y) }
                cv.drawPath(path, p)
            }
            else -> {
                p.style = Paint.Style.STROKE; p.strokeWidth = 3f; val cx = w / 2; val cy = h / 2; val r0 = h * 0.25f
                for (i in 0 until n) { val an = i * 2 * PI.toFloat() / n; val r1 = r0 + v[i] * h * 0.25f; cv.drawLine(cx + r0 * cos(an), cy + r0 * sin(an), cx + r1 * cos(an), cy + r1 * sin(an), p) }
            }
        }
        postInvalidateOnAnimation()
    }
}

// ---------- HUD, сканирующая линия, электричество
class Hud(c: Context) : View(c) {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG); private var t = 0f; private val rnd = Random()
    var anchors: List<View> = emptyList()
    private var bolt: List<PointF>? = null; private var boltT = 0f; private var next = 1.5f
    fun zap() { if (P.sp.getBoolean("elec", false) && Xp.ok("elec")) { next = 0f; invalidate() } }
    private fun center(v: View, me: IntArray): PointF { val l = IntArray(2); v.getLocationInWindow(l); return PointF(l[0] - me[0] + v.width / 2f, l[1] - me[1] + v.height / 2f) }
    override fun onDraw(cv: Canvas) {
        val d = context.resources.displayMetrics.density; val w = width.toFloat(); val h = height.toFloat(); t += 0.016f; val ac = P.accent
        val hud = P.sp.getBoolean("hud", false) && Xp.ok("hud"); val scan = P.sp.getBoolean("scan", false) && Xp.ok("scan"); val elec = P.sp.getBoolean("elec", false) && Xp.ok("elec")
        p.shader = null
        if (hud) {
            p.style = Paint.Style.STROKE; p.strokeWidth = d; p.color = withA(ac, 14)
            var gx = 0f; while (gx < w) { cv.drawLine(gx, 0f, gx, h, p); gx += 26 * d }
            var gy = 0f; while (gy < h) { cv.drawLine(0f, gy, w, gy, p); gy += 26 * d }
            p.strokeWidth = 2 * d; p.color = withA(ac, 150 + (60 * sin(t * 3)).toInt()); val ln = 20 * d; val m = 5 * d
            cv.drawLine(m, m + ln, m, m, p); cv.drawLine(m, m, m + ln, m, p); cv.drawLine(w - m - ln, m, w - m, m, p); cv.drawLine(w - m, m, w - m, m + ln, p)
            cv.drawLine(m, h - m - ln, m, h - m, p); cv.drawLine(m, h - m, m + ln, h - m, p); cv.drawLine(w - m - ln, h - m, w - m, h - m, p); cv.drawLine(w - m, h - m - ln, w - m, h - m, p)
            p.style = Paint.Style.FILL; p.textSize = 8 * d; p.textAlign = Paint.Align.LEFT; p.color = withA(ac, 190)
            cv.drawText("SYS//ONLINE  LVL " + Xp.level(), 14 * d, h - 7 * d, p)
        }
        if (scan) {
            val y = ((t * 0.35f) % 1f) * h
            p.style = Paint.Style.FILL; p.shader = LinearGradient(0f, y - 50 * d, 0f, y, withA(ac, 0), withA(ac, 90), Shader.TileMode.CLAMP)
            cv.drawRect(0f, y - 50 * d, w, y, p); p.shader = null
            p.style = Paint.Style.STROKE; p.strokeWidth = 1.5f * d; p.color = withA(ac, 220); cv.drawLine(0f, y, w, y, p)
        }
        if (elec && anchors.size >= 2) {
            val b = bolt
            if (b == null) {
                next -= 0.016f
                if (next <= 0f) {
                    val me = IntArray(2); getLocationInWindow(me)
                    val a = anchors[rnd.nextInt(anchors.size)]; var bb = anchors[rnd.nextInt(anchors.size)]
                    if (bb === a) bb = anchors[(anchors.indexOf(a) + 1) % anchors.size]
                    val pa = center(a, me); val pb = center(bb, me)
                    bolt = boltPts(rnd, d, pa.x, pa.y, pb.x, pb.y, 26 * d, 9); boltT = 0.3f
                }
            } else {
                boltT -= 0.016f; drawBolt(cv, p, d, b, clamp01(boltT / 0.3f))
                if (boltT <= 0f) { bolt = null; next = 1.5f + rnd.nextFloat() * 3f }
            }
        }
        if (hud || scan || elec) postInvalidateOnAnimation()
    }
}

// ---------- Анимации появления меню
class FxView(c: Context, val mode: String, val bmp: Bitmap, val loc: IntArray, val dir: Int, val done: () -> Unit) : View(c) {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG); private var t = 0f; private val rnd = Random()
    private val d = c.resources.displayMetrics.density
    private val bolts = ArrayList<List<PointF>>(); private var lastStep = -1; private var flash = 0f
    private val dur = when (mode) { "portal" -> 1400L; "split" -> 1500L; "hole" -> 1300L; "lightning" -> 1200L; "slide" -> 650L; else -> 850L }
    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        val an = ValueAnimator.ofFloat(0f, 1f); an.duration = dur
        an.addUpdateListener { t = it.animatedValue as Float; invalidate() }
        an.addListener(object : AnimatorListenerAdapter() { override fun onAnimationEnd(a: Animator) { done() } })
        an.start()
    }
    private fun snap(cv: Canvas, x: Float, y: Float, a: Float) { p.shader = null; p.style = Paint.Style.FILL; p.alpha = (255 * clamp01(a)).toInt(); cv.drawBitmap(bmp, x, y, p); p.alpha = 255 }
    override fun onDraw(cv: Canvas) {
        val w = width.toFloat(); val h = height.toFloat()
        val fl = IntArray(2); getLocationOnScreen(fl)
        val mx = (loc[0] - fl[0]).toFloat(); val my = (loc[1] - fl[1]).toFloat()
        val bw = bmp.width.toFloat(); val bh = bmp.height.toFloat(); val cx = mx + bw / 2; val cy = my + bh / 2; val ac = P.accent
        p.alpha = 255
        when (mode) {
            "slide" -> {
                val e = ease(t); var dx = 0f; var dy = 0f
                when (dir) { 0 -> dx = -(mx + bw) * (1 - e); 1 -> dx = (w - mx) * (1 - e); 2 -> dy = -(my + bh) * (1 - e); else -> dy = (h - my) * (1 - e) }
                snap(cv, mx + dx, my + dy, 1f)
            }
            "halves" -> {
                val e = ease(t); val half = bw / 2
                val dl = -(mx + half) * (1 - e); val dr = (w - mx - half) * (1 - e); p.shader = null
                cv.drawBitmap(bmp, Rect(0, 0, half.toInt(), bmp.height), RectF(mx + dl, my, mx + dl + half, my + bh), p)
                cv.drawBitmap(bmp, Rect(half.toInt(), 0, bmp.width, bmp.height), RectF(mx + half + dr, my, mx + bw + dr, my + bh), p)
                if (t > 0.85f) { val a = (t - 0.85f) / 0.15f; p.style = Paint.Style.STROKE; p.strokeWidth = 3 * d; p.color = withA(Color.WHITE, ((1 - a) * 255).toInt()); cv.drawLine(cx, my, cx, my + bh, p) }
            }
            "portal" -> {
                val grow = ease(clamp01(t / 0.3f)); val shrink = ease(clamp01((t - 0.72f) / 0.28f)); val r = min(bw, bh) * 0.36f * grow * (1 - shrink)
                if (r > 1f) {
                    p.style = Paint.Style.FILL
                    p.shader = RadialGradient(cx, cy, r, intArrayOf(0xFF05030F.toInt(), 0xFF05030F.toInt(), withA(ac, 230), withA(ac, 0)), floatArrayOf(0f, 0.55f, 0.85f, 1f), Shader.TileMode.CLAMP)
                    cv.drawOval(RectF(cx - r, cy - r * 0.6f, cx + r, cy + r * 0.6f), p); p.shader = null
                    p.style = Paint.Style.STROKE; p.strokeWidth = 3 * d
                    for (k in 0..3) {
                        val q = r * (1 - 0.17f * k); p.color = withA(P.mix(ac, Color.WHITE, 0.2f * k), 220)
                        cv.drawArc(RectF(cx - q, cy - q * 0.6f, cx + q, cy + q * 0.6f), t * 720f * (if (k % 2 == 0) 1f else -1f) + k * 70f, 220f, false, p)
                    }
                }
                val te = ease(clamp01((t - 0.22f) / 0.45f))
                if (te > 0f) {
                    p.style = Paint.Style.FILL; p.typeface = Typeface.DEFAULT_BOLD; p.textAlign = Paint.Align.CENTER
                    p.textSize = 56 * d * (0.3f + 0.7f * te); p.color = withA(Color.WHITE, (255 * te).toInt()); p.setShadowLayer(14 * d, 0f, 0f, ac)
                    cv.drawText("NOVA", cx, cy - 70 * d * te, p); p.clearShadowLayer()
                }
                val me = ease(clamp01((t - 0.65f) / 0.35f))
                if (me > 0f) { cv.save(); val sc = 0.85f + 0.15f * me; cv.scale(sc, sc, cx, cy); snap(cv, mx, my, me); cv.restore() }
            }
            "split" -> {
                val a = ease(clamp01(t / 0.35f)); val c2 = ease(clamp01((t - 0.5f) / 0.35f)); val me = clamp01((t - 0.45f) / 0.4f)
                if (me > 0f) snap(cv, mx, my, me)
                val ty = -60 * d + (cy + 60 * d) * a; val dx = c2 * (w / 2 + 120 * d)
                p.style = Paint.Style.FILL; p.typeface = Typeface.DEFAULT_BOLD; p.textAlign = Paint.Align.CENTER; p.textSize = 60 * d; p.color = Color.WHITE; p.setShadowLayer(12 * d, 0f, 0f, ac)
                if (c2 < 1f) {
                    cv.save(); cv.clipRect(0f, 0f, cx, h); cv.translate(-dx, 0f); cv.drawText("NOVA", cx, ty, p); cv.restore()
                    cv.save(); cv.clipRect(cx, 0f, w, h); cv.translate(dx, 0f); cv.drawText("NOVA", cx, ty, p); cv.restore()
                }
                p.clearShadowLayer()
                if (t > 0.33f && t < 0.52f) { p.style = Paint.Style.STROKE; p.strokeWidth = 3 * d; p.color = withA(Color.WHITE, 230); cv.drawLine(cx, ty - 60 * d, cx, ty + 20 * d, p) }
            }
            "hole" -> {
                val grow = ease(clamp01(t / 0.35f)); val out = ease(clamp01((t - 0.4f) / 0.5f)); val shrink = ease(clamp01((t - 0.8f) / 0.2f))
                val r = min(bw, bh) * 0.3f * grow * (1 - shrink)
                if (out > 0f) { cv.save(); cv.translate(cx, cy); cv.rotate((1 - out) * 220f); cv.scale(out, out); snap(cv, -bw / 2, -bh / 2, out); cv.restore() }
                if (r > 1f) {
                    p.style = Paint.Style.FILL
                    p.shader = RadialGradient(cx, cy, r * 1.5f, intArrayOf(Color.BLACK, Color.BLACK, withA(ac, 230), withA(0xFFFFB347.toInt(), 120), 0), floatArrayOf(0f, 0.55f, 0.66f, 0.82f, 1f), Shader.TileMode.CLAMP)
                    cv.drawCircle(cx, cy, r * 1.5f, p); p.shader = null
                    p.style = Paint.Style.STROKE; p.strokeWidth = 2 * d; p.color = withA(Color.WHITE, 140)
                    for (k in 0..2) { val q = r * (1.1f + .12f * k); cv.drawArc(RectF(cx - q, cy - q * .35f, cx + q, cy + q * .35f), t * 900f + k * 120f, 140f, false, p) }
                }
            }
            else -> {
                val step = (t / 0.08f).toInt()
                if (step != lastStep && t < 0.8f) {
                    lastStep = step; bolts.clear(); flash = 0.5f
                    repeat(2 + rnd.nextInt(2)) { bolts.add(boltPts(rnd, d, rnd.nextFloat() * w, 0f, rnd.nextFloat() * w, h, 70 * d, 16)) }
                }
                val me = clamp01((t - 0.45f) / 0.35f); if (me > 0f) snap(cv, mx, my, me)
                if (t < 0.85f) bolts.forEach { drawBolt(cv, p, d, it, 1f) }
                if (flash > 0f) { p.shader = null; p.style = Paint.Style.FILL; p.color = withA(Color.WHITE, (flash * 255).toInt()); cv.drawRect(0f, 0f, w, h, p); flash = max(0f, flash - 0.04f) }
            }
        }
    }
}
