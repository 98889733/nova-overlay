package com.nova.client
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.PixelFormat
import android.os.*
import android.view.*
import android.widget.*
import kotlin.math.abs

class OverlayService : Service() {
    companion object { var inst: OverlayService? = null }
    private lateinit var wm: WindowManager
    private lateinit var pp: WindowManager.LayoutParams
    private val ctx by lazy { ContextThemeWrapper(this, android.R.style.Theme_DeviceDefault) }
    private var pill: LinearLayout? = null; private var menu: Shell? = null
    private var fpsTv: TextView? = null; private var collapsed = false
    private val h = Handler(Looper.getMainLooper())
    private var fc = 0; private var lt = 0L
    private val cb = object : Choreographer.FrameCallback {
        override fun doFrame(t: Long) {
            if (inst == null) return
            fc++; if (lt == 0L) lt = t
            if (t - lt >= 500_000_000L) { fpsTv?.text = "FPS " + Math.round(fc * 1e9 / (t - lt)); fc = 0; lt = t }
            Choreographer.getInstance().postFrameCallback(this)
        }
    }
    private val type = WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
    private val flags = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL
    override fun onBind(i: Intent?): IBinder? = null
    override fun onStartCommand(i: Intent?, f: Int, s: Int) = START_STICKY
    override fun onCreate() {
        super.onCreate(); inst = this; P.init(this)
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        val n = notif(this, "Меню запущено")
        if (Build.VERSION.SDK_INT >= 34) startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE) else startForeground(1, n)
        pp = WindowManager.LayoutParams(-2, -2, type, flags, PixelFormat.TRANSLUCENT).apply { gravity = Gravity.TOP or Gravity.START; x = ctx.dp(20); y = ctx.dp(60) }
        buildPill(); Choreographer.getInstance().postFrameCallback(cb)
    }
    override fun onDestroy() {
        inst = null; closeMenu(); pill?.let { try { wm.removeView(it) } catch (e: Exception) {} }; super.onDestroy()
    }
    fun restyle() = buildPill()
    private fun buildPill() {
        pill?.let { try { wm.removeView(it) } catch (e: Exception) {} }
        val c = ctx
        fpsTv = c.tv("FPS --", 13f, P.accent, true)
        val arrow = c.tv(if (collapsed) "▸" else "▾", 14f, P.fg(), true)
        val l = LinearLayout(c).apply {
            gravity = Gravity.CENTER_VERTICAL; setPadding(c.dp(12), c.dp(6), c.dp(10), c.dp(6)); background = rr(P.bg(), c.dp(18).toFloat(), P.accent)
            alpha = 0.96f; visibility = if (menu != null) View.INVISIBLE else View.VISIBLE
        }
        if (!collapsed) l.addView(fpsTv)
        l.addView(arrow.apply { setPadding(if (collapsed) 0 else c.dp(10), 0, 0, 0) })
        var sx = 0f; var sy = 0f; var ox = 0; var oy = 0; var moved = false
        l.setOnTouchListener { v, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> { sx = e.rawX; sy = e.rawY; ox = pp.x; oy = pp.y; moved = false }
                MotionEvent.ACTION_MOVE -> {
                    val dx = e.rawX - sx; val dy = e.rawY - sy
                    if (abs(dx) > 10 || abs(dy) > 10) moved = true
                    if (moved) { pp.x = ox + dx.toInt(); pp.y = oy + dy.toInt(); wm.updateViewLayout(v, pp) }
                }
                MotionEvent.ACTION_UP -> if (!moved) { if (collapsed || e.x > arrow.left) { collapsed = !collapsed; buildPill() } else openMenu() }
            }
            true
        }
        wm.addView(l, pp); pill = l
    }
    private fun openMenu() {
        if (menu != null) return
        pill?.visibility = View.INVISIBLE
        val c = ctx; val dm = resources.displayMetrics
        val sh = Shell(c, "NOVA", "bgM", listOf("Приложения", "Инструменты", "Настройки"), 24, { closeMenu() }) { i, s ->
            when (i) {
                0 -> appsPage(c, s) { pk -> closeMenu(); packageManager.getLaunchIntentForPackage(pk)?.let { startActivity(it.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) } }
                1 -> toolsPage(c, s)
                else -> c.settingsView { s.rebuild() }
            }
        }
        val lp = WindowManager.LayoutParams((dm.widthPixels * 0.92).toInt(), (dm.heightPixels * 0.72).toInt(), type, flags, PixelFormat.TRANSLUCENT).apply { gravity = Gravity.CENTER }
        wm.addView(sh, lp); menu = sh
    }
    fun closeMenu() {
        menu?.let { try { wm.removeView(it) } catch (e: Exception) {} }; menu = null; pill?.visibility = View.VISIBLE
    }
    private fun need(): Boolean {
        if (CaptureService.inst != null) return false
        Toast.makeText(this, "Сначала выдай доступ к записи экрана", Toast.LENGTH_LONG).show()
        startActivity(Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK).putExtra("cap", true))
        return true
    }
    fun snap() {
        if (need()) return
        if (CaptureService.inst?.recording == true) { Toast.makeText(this, "Сначала останови запись", Toast.LENGTH_SHORT).show(); return }
        closeMenu(); pill?.visibility = View.INVISIBLE
        h.postDelayed({ CaptureService.inst?.shot() }, 500); h.postDelayed({ pill?.visibility = View.VISIBLE }, 1200)
    }
    fun toggleRec() {
        if (need()) return
        val cs = CaptureService.inst ?: return
        if (cs.recording) { cs.stopRec(); menu?.rebuild() } else { cs.startRec(); closeMenu() }
    }
}
