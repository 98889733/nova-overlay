package com.nova.client
import android.app.*
import android.content.*
import android.graphics.Color
import android.media.AudioManager
import android.media.ToneGenerator
import android.os.*
import android.widget.Toast
import java.io.File
import java.text.SimpleDateFormat
import java.util.*

object P {
    lateinit var sp: SharedPreferences
    fun init(c: Context) { if (!::sp.isInitialized) sp = c.applicationContext.getSharedPreferences("nova", 0) }
    fun int(k: String, d: Int) = sp.getInt(k, d)
    fun putI(k: String, v: Int) = sp.edit().putInt(k, v).apply()
    fun str(k: String, d: String = "") = sp.getString(k, d) ?: d
    fun putS(k: String, v: String) = sp.edit().putString(k, v).apply()
    fun putB(k: String, v: Boolean) = sp.edit().putBoolean(k, v).apply()
    val dark: Boolean get() = sp.getBoolean("dark", false)
    val accent: Int get() = int("acc", 0xFF5B6CFF.toInt())
    private fun lum(c: Int) = (0.299f * Color.red(c) + 0.587f * Color.green(c) + 0.114f * Color.blue(c)) / 255f
    fun bg(): Int { val v = int("pbg", 0); return if (v != 0) v else if (dark) 0xFF14151C.toInt() else Color.WHITE }
    fun fg(): Int { val v = int("ptx", 0); return if (v != 0) v else if (lum(bg()) < 0.5f) Color.WHITE else 0xFF16171D.toInt() }
    fun mix(a: Int, b: Int, t: Float) = Color.rgb(
        (Color.red(a) + (Color.red(b) - Color.red(a)) * t).toInt(),
        (Color.green(a) + (Color.green(b) - Color.green(a)) * t).toInt(),
        (Color.blue(a) + (Color.blue(b) - Color.blue(a)) * t).toInt())
    fun card() = mix(bg(), fg(), 0.08f)
    fun sub() = mix(bg(), fg(), 0.55f)
    fun apps() = str("apps", "org.telegram.messenger").split("|").filter { it.isNotEmpty() }
    fun addApp(p: String) { if (p !in apps()) putS("apps", (apps() + p).joinToString("|")) }
    fun delApp(p: String) = putS("apps", (apps() - p).joinToString("|"))
}

object T {
    var end = 0L; var total = 0
    private val h = Handler(Looper.getMainLooper())
    private var r: Runnable? = null
    fun left(): Int = if (end > 0) maxOf(0L, (end - System.currentTimeMillis() + 999) / 1000).toInt() else total
    fun start(c: Context) {
        if (total <= 0) return
        end = System.currentTimeMillis() + total * 1000L
        r?.let { h.removeCallbacks(it) }
        r = Runnable { end = 0; ring(c) }
        h.postDelayed(r!!, total * 1000L)
    }
    fun stop() { r?.let { h.removeCallbacks(it) }; end = 0 }
    private fun ring(c: Context) {
        Toast.makeText(c, "Таймер!", Toast.LENGTH_LONG).show()
        c.getSystemService(Vibrator::class.java)?.vibrate(VibrationEffect.createOneShot(900, 255))
        try { ToneGenerator(AudioManager.STREAM_ALARM, 100).startTone(ToneGenerator.TONE_CDMA_ALERT_CALL_GUARD, 1500) } catch (e: Exception) {}
    }
}

fun Context.dir(n: String) = File(filesDir, n).apply { mkdirs() }
fun ts(): String = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
fun notif(c: Context, t: String): Notification {
    c.getSystemService(NotificationManager::class.java).createNotificationChannel(NotificationChannel("nova", "NOVA", NotificationManager.IMPORTANCE_LOW))
    return Notification.Builder(c, "nova").setContentTitle("NOVA Client").setContentText(t).setSmallIcon(android.R.drawable.ic_menu_view).build()
}
