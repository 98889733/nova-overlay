package com.nova.client
import android.content.Context
import android.graphics.*
import android.view.*
import android.widget.*
import kotlin.math.*

class CS(val k: String, val n: String, val lv: Int)
val CS_BASIC = listOf(CS("cross", "Прицел", 1), CS("dot", "Точка", 1), CS("circle", "Круг", 1), CS("plus", "Плюс", 1), CS("x", "Икс", 2), CS("square", "Квадрат", 2),
    CS("tri", "Треугольник", 2), CS("star4", "Звёздочка", 3), CS("diamond", "Ромб", 3), CS("hex", "Шестиугольник", 3), CS("bull", "Мишень", 3), CS("ring2", "Два кольца", 4),
    CS("brk", "Скобки", 4), CS("star5", "Звезда", 4), CS("stars", "Звёзды", 5), CS("chev", "Шевроны", 5), CS("arrows", "Стрелки", 5), CS("spark", "Искры", 6))
val CS_CHAR = listOf(CS("smile", "Смайл", 3), CS("heart", "Сердце", 3), CS("cat", "Котик", 4), CS("skull", "Череп", 5), CS("bolt", "Молния", 5), CS("ghost", "Призрак", 6),
    CS("eye", "Глаз", 6), CS("ninja", "Сюрикен", 7), CS("alien", "Пришелец", 7), CS("robot", "Робот", 8), CS("crown", "Корона", 9), CS("pumpkin", "Тыква", 9),
    CS("panda", "Панда", 10), CS("fox", "Лиса", 11))
val CS_FX = listOf(CS("fire", "Огонь", 4), CS("moon", "Луна", 5), CS("sun", "Солнце", 5), CS("snow", "Снежинка", 6), CS("jupiter", "Юпитер", 6), CS("earth", "Земля", 7),
    CS("radar", "Радар", 7), CS("saturn", "Сатурн", 8), CS("plasma", "Плазма", 8), CS("galaxy", "Галактика", 9), CS("comet", "Комета", 9), CS("hole", "Чёрная дыра", 10))
val CS_ALL = CS_BASIC + CS_CHAR + CS_FX
val CS_EFF = listOf(CS("none", "Нет", 1), CS("pulse", "Пульс", 2), CS("spin", "Вращение", 2), CS("spinr", "Обратное", 3), CS("blink", "Мигание", 3),
    CS("shake", "Дрожь", 4), CS("glow", "Свечение", 5), CS("rainbow", "Радуга", 6), CS("orbit", "Орбита", 7))
val ANIMATED = setOf("fire", "moon", "sun", "snow", "jupiter", "earth", "radar", "saturn", "plasma", "galaxy", "comet", "hole", "stars", "spark")
val CCOLS = listOf(0L, 0xFFFFFFFF, 0xFFFF3B3B, 0xFF22C55E, 0xFFFFD60A, 0xFF06B6D4, 0xFFFF4DD8, 0xFFFF8A00, 0xFF5B6CFF, 0xFF16171D).map { it.toInt() }

fun Context.csl(c: CS) = if (Xp.lv(c.lv)) c.n else "${c.n} · ур.${c.lv}"
fun Context.csGate(k: String, list: List<CS> = CS_ALL): Boolean {
    val cs = list.firstOrNull { it.k == k } ?: return true
    if (Xp.lv(cs.lv)) return true
    Toast.makeText(this, "Откроется на уровне ${cs.lv}", Toast.LENGTH_SHORT).show(); return false
}
fun Context.subTabs(names: List<String>, cur: Int, key: String, sel: (Int) -> Unit): View =
    chipRow(names.mapIndexed { i, n -> "$i" to n }, "$cur", key) { sel(it.toInt()) }
fun withA(c: Int, a: Int) = Color.argb(a.coerceIn(0, 255), Color.red(c), Color.green(c), Color.blue(c))

private val PIF = PI.toFloat()
private fun lumOf(c: Int) = (0.299f * Color.red(c) + 0.587f * Color.green(c) + 0.114f * Color.blue(c)) / 255f
private fun polyPath(cx: Float, cy: Float, r: Float, n: Int, rot: Float): Path {
    val pa = Path()
    for (i in 0 until n) { val an = rot + i * 2 * PIF / n; val x = cx + r * cos(an); val y = cy + r * sin(an); if (i == 0) pa.moveTo(x, y) else pa.lineTo(x, y) }
    pa.close(); return pa
}
private fun starPath(cx: Float, cy: Float, ro: Float, ri: Float, n: Int, rot: Float): Path {
    val pa = Path()
    for (i in 0 until n * 2) { val q = if (i % 2 == 0) ro else ri; val an = rot + i * PIF / n; val x = cx + q * cos(an); val y = cy + q * sin(an); if (i == 0) pa.moveTo(x, y) else pa.lineTo(x, y) }
    pa.close(); return pa
}

fun drawCross(cv: Canvas, p: Paint, key: String, cx: Float, cy: Float, r: Float, col: Int, t: Float) {
    val det = if (lumOf(col) > 0.6f) 0xFF15151B.toInt() else Color.WHITE
    val sw = max(1.5f, r * 0.16f)
    fun st(c: Int) { p.shader = null; p.style = Paint.Style.STROKE; p.strokeWidth = sw; p.color = c }
    fun fl(c: Int) { p.shader = null; p.style = Paint.Style.FILL; p.color = c }
    p.strokeCap = Paint.Cap.ROUND; p.strokeJoin = Paint.Join.ROUND
    st(col)
    when (key) {
        "dot" -> { fl(col); cv.drawCircle(cx, cy, r * 0.3f, p) }
        "circle" -> { cv.drawCircle(cx, cy, r * 0.8f, p); fl(col); cv.drawCircle(cx, cy, r * 0.12f, p) }
        "plus" -> { cv.drawLine(cx - r, cy, cx + r, cy, p); cv.drawLine(cx, cy - r, cx, cy + r, p) }
        "x" -> { val q = r * 0.75f; cv.drawLine(cx - q, cy - q, cx + q, cy + q, p); cv.drawLine(cx + q, cy - q, cx - q, cy + q, p) }
        "square" -> cv.drawRect(cx - r * 0.75f, cy - r * 0.75f, cx + r * 0.75f, cy + r * 0.75f, p)
        "tri" -> cv.drawPath(polyPath(cx, cy + r * 0.1f, r, 3, -PIF / 2), p)
        "diamond" -> cv.drawPath(polyPath(cx, cy, r, 4, 0f), p)
        "hex" -> cv.drawPath(polyPath(cx, cy, r * 0.9f, 6, 0f), p)
        "bull" -> { cv.drawCircle(cx, cy, r * 0.9f, p); cv.drawCircle(cx, cy, r * 0.55f, p); fl(col); cv.drawCircle(cx, cy, r * 0.2f, p) }
        "ring2" -> { cv.drawCircle(cx, cy, r * 0.9f, p); cv.drawCircle(cx, cy, r * 0.5f, p) }
        "brk" -> {
            for (sx in intArrayOf(-1, 1)) for (sy in intArrayOf(-1, 1)) {
                val x = cx + sx * r * 0.8f; val y = cy + sy * r * 0.8f
                cv.drawLine(x, y, x, y - sy * r * 0.5f, p); cv.drawLine(x, y, x - sx * r * 0.5f, y, p)
            }
        }
        "chev" -> {
            for (i in 0..3) {
                cv.save(); cv.rotate(i * 90f, cx, cy); val pa = Path()
                pa.moveTo(cx - r, cy - r * 0.3f); pa.lineTo(cx - r * 0.55f, cy); pa.lineTo(cx - r, cy + r * 0.3f); cv.drawPath(pa, p); cv.restore()
            }
        }
        "arrows" -> {
            fl(col)
            for (i in 0..3) {
                cv.save(); cv.rotate(i * 90f, cx, cy); val pa = Path()
                pa.moveTo(cx - r, cy - r * 0.25f); pa.lineTo(cx - r, cy + r * 0.25f); pa.lineTo(cx - r * 0.5f, cy); pa.close(); cv.drawPath(pa, p); cv.restore()
            }
        }
        "star5" -> { fl(col); cv.drawPath(starPath(cx, cy, r, r * 0.45f, 5, -PIF / 2), p) }
        "star4" -> { fl(col); cv.drawPath(starPath(cx, cy, r, r * 0.3f, 4, -PIF / 2), p) }
        "stars" -> {
            fl(col)
            for (i in 0..4) {
                val a = i * 2 * PIF / 5 - PIF / 2; val s = 0.6f + 0.4f * sin(t * 3 + i)
                cv.drawPath(starPath(cx + r * 0.62f * cos(a), cy + r * 0.62f * sin(a), r * 0.34f * s, r * 0.15f * s, 5, -PIF / 2), p)
            }
        }
        "spark" -> {
            fl(col)
            for (i in 0..3) {
                val a = i * PIF / 2 + PIF / 4; val s = 0.5f + 0.5f * abs(sin(t * 2 + i))
                cv.drawPath(starPath(cx + r * 0.6f * cos(a), cy + r * 0.6f * sin(a), r * 0.38f * s, r * 0.07f * s, 4, 0f), p)
            }
            cv.drawCircle(cx, cy, r * 0.1f, p)
        }
        "smile" -> {
            fl(col); cv.drawCircle(cx, cy, r * 0.9f, p); fl(det)
            cv.drawCircle(cx - r * 0.32f, cy - r * 0.2f, r * 0.12f, p); cv.drawCircle(cx + r * 0.32f, cy - r * 0.2f, r * 0.12f, p)
            st(det); cv.drawArc(RectF(cx - r * 0.5f, cy - r * 0.15f, cx + r * 0.5f, cy + r * 0.55f), 20f, 140f, false, p)
        }
        "heart" -> {
            fl(col); val pa = Path(); pa.moveTo(cx, cy + r * 0.85f)
            pa.cubicTo(cx - r * 1.4f, cy - r * 0.1f, cx - r * 0.6f, cy - r * 1.0f, cx, cy - r * 0.3f)
            pa.cubicTo(cx + r * 0.6f, cy - r * 1.0f, cx + r * 1.4f, cy - r * 0.1f, cx, cy + r * 0.85f); pa.close(); cv.drawPath(pa, p)
        }
        "cat" -> {
            fl(col); cv.drawCircle(cx, cy + r * 0.12f, r * 0.7f, p)
            val l = Path(); l.moveTo(cx - r * 0.72f, cy - r * 0.05f); l.lineTo(cx - r * 0.62f, cy - r * 0.95f); l.lineTo(cx - r * 0.1f, cy - r * 0.5f); l.close(); cv.drawPath(l, p)
            val rt = Path(); rt.moveTo(cx + r * 0.72f, cy - r * 0.05f); rt.lineTo(cx + r * 0.62f, cy - r * 0.95f); rt.lineTo(cx + r * 0.1f, cy - r * 0.5f); rt.close(); cv.drawPath(rt, p)
            fl(det); cv.drawCircle(cx - r * 0.26f, cy + r * 0.05f, r * 0.1f, p); cv.drawCircle(cx + r * 0.26f, cy + r * 0.05f, r * 0.1f, p)
            val nz = Path(); nz.moveTo(cx - r * 0.08f, cy + r * 0.25f); nz.lineTo(cx + r * 0.08f, cy + r * 0.25f); nz.lineTo(cx, cy + r * 0.35f); nz.close(); cv.drawPath(nz, p)
            st(det); p.strokeWidth = sw * 0.6f
            cv.drawLine(cx - r * 0.75f, cy + r * 0.2f, cx - r * 0.3f, cy + r * 0.3f, p); cv.drawLine(cx + r * 0.75f, cy + r * 0.2f, cx + r * 0.3f, cy + r * 0.3f, p)
        }
        "skull" -> {
            fl(col); cv.drawCircle(cx, cy - r * 0.15f, r * 0.7f, p); cv.drawRoundRect(RectF(cx - r * 0.4f, cy + r * 0.2f, cx + r * 0.4f, cy + r * 0.85f), r * 0.1f, r * 0.1f, p)
            fl(det); cv.drawCircle(cx - r * 0.27f, cy - r * 0.15f, r * 0.2f, p); cv.drawCircle(cx + r * 0.27f, cy - r * 0.15f, r * 0.2f, p)
            val nz = Path(); nz.moveTo(cx, cy + r * 0.05f); nz.lineTo(cx - r * 0.1f, cy + r * 0.25f); nz.lineTo(cx + r * 0.1f, cy + r * 0.25f); nz.close(); cv.drawPath(nz, p)
            st(det); p.strokeWidth = sw * 0.5f
            for (i in -1..1) cv.drawLine(cx + i * r * 0.18f, cy + r * 0.45f, cx + i * r * 0.18f, cy + r * 0.8f, p)
        }
        "bolt" -> {
            fl(col); val pa = Path(); pa.moveTo(cx + r * 0.2f, cy - r); pa.lineTo(cx - r * 0.5f, cy + r * 0.1f); pa.lineTo(cx - r * 0.05f, cy + r * 0.1f)
            pa.lineTo(cx - r * 0.3f, cy + r); pa.lineTo(cx + r * 0.55f, cy - r * 0.2f); pa.lineTo(cx + r * 0.05f, cy - r * 0.2f); pa.close(); cv.drawPath(pa, p)
        }
        "ghost" -> {
            fl(col); cv.drawCircle(cx, cy - r * 0.15f, r * 0.65f, p); cv.drawRect(cx - r * 0.65f, cy - r * 0.15f, cx + r * 0.65f, cy + r * 0.6f, p)
            for (i in -1..1) cv.drawCircle(cx + i * r * 0.43f, cy + r * 0.6f, r * 0.22f, p)
            fl(det); cv.drawOval(RectF(cx - r * 0.4f, cy - r * 0.35f, cx - r * 0.15f, cy), p); cv.drawOval(RectF(cx + r * 0.15f, cy - r * 0.35f, cx + r * 0.4f, cy), p)
            cv.drawCircle(cx, cy + r * 0.25f, r * 0.12f, p)
        }
        "eye" -> {
            val pa = Path(); pa.moveTo(cx - r, cy); pa.quadTo(cx, cy - r, cx + r, cy); pa.quadTo(cx, cy + r, cx - r, cy); cv.drawPath(pa, p)
            fl(col); cv.drawCircle(cx, cy, r * 0.38f, p); fl(det); cv.drawCircle(cx, cy, r * 0.17f, p)
        }
        "ninja" -> { fl(col); cv.drawPath(starPath(cx, cy, r, r * 0.25f, 4, -PIF / 4), p); fl(det); cv.drawCircle(cx, cy, r * 0.15f, p) }
        "alien" -> {
            fl(col); cv.drawOval(RectF(cx - r * 0.7f, cy - r * 0.9f, cx + r * 0.7f, cy + r * 0.9f), p); fl(det)
            for (s in intArrayOf(-1, 1)) {
                val ex = cx + s * r * 0.3f
                cv.save(); cv.rotate(s * -25f, ex, cy - r * 0.1f); cv.drawOval(RectF(ex - r * 0.22f, cy - r * 0.3f, ex + r * 0.22f, cy + r * 0.1f), p); cv.restore()
            }
            st(det); p.strokeWidth = sw * 0.6f; cv.drawLine(cx - r * 0.15f, cy + r * 0.5f, cx + r * 0.15f, cy + r * 0.5f, p)
        }
        "robot" -> {
            fl(col); cv.drawRoundRect(RectF(cx - r * 0.7f, cy - r * 0.5f, cx + r * 0.7f, cy + r * 0.7f), r * 0.18f, r * 0.18f, p)
            cv.drawRect(cx - r * 0.04f, cy - r * 0.9f, cx + r * 0.04f, cy - r * 0.5f, p); cv.drawCircle(cx, cy - r * 0.92f, r * 0.1f, p)
            cv.drawRect(cx - r * 0.85f, cy - r * 0.1f, cx - r * 0.7f, cy + r * 0.3f, p); cv.drawRect(cx + r * 0.7f, cy - r * 0.1f, cx + r * 0.85f, cy + r * 0.3f, p)
            fl(det); cv.drawRect(cx - r * 0.45f, cy - r * 0.25f, cx - r * 0.15f, cy + r * 0.05f, p); cv.drawRect(cx + r * 0.15f, cy - r * 0.25f, cx + r * 0.45f, cy + r * 0.05f, p)
            cv.drawRect(cx - r * 0.4f, cy + r * 0.33f, cx + r * 0.4f, cy + r * 0.43f, p)
        }
        "crown" -> {
            fl(col); val pa = Path(); pa.moveTo(cx - r * 0.85f, cy + r * 0.55f); pa.lineTo(cx - r * 0.85f, cy - r * 0.45f); pa.lineTo(cx - r * 0.4f, cy + r * 0.05f)
            pa.lineTo(cx, cy - r * 0.65f); pa.lineTo(cx + r * 0.4f, cy + r * 0.05f); pa.lineTo(cx + r * 0.85f, cy - r * 0.45f); pa.lineTo(cx + r * 0.85f, cy + r * 0.55f); pa.close(); cv.drawPath(pa, p)
            fl(det); for (i in -1..1) cv.drawCircle(cx + i * r * 0.4f, cy + r * 0.32f, r * 0.1f, p)
        }
        "pumpkin" -> {
            fl(col); cv.drawOval(RectF(cx - r * 0.95f, cy - r * 0.6f, cx + r * 0.95f, cy + r * 0.85f), p); fl(det)
            cv.drawRect(cx - r * 0.07f, cy - r * 0.9f, cx + r * 0.07f, cy - r * 0.55f, p)
            val e1 = Path(); e1.moveTo(cx - r * 0.5f, cy - r * 0.1f); e1.lineTo(cx - r * 0.2f, cy - r * 0.1f); e1.lineTo(cx - r * 0.35f, cy - r * 0.35f); e1.close(); cv.drawPath(e1, p)
            val e2 = Path(); e2.moveTo(cx + r * 0.5f, cy - r * 0.1f); e2.lineTo(cx + r * 0.2f, cy - r * 0.1f); e2.lineTo(cx + r * 0.35f, cy - r * 0.35f); e2.close(); cv.drawPath(e2, p)
            val m = Path(); m.moveTo(cx - r * 0.5f, cy + r * 0.2f); m.lineTo(cx - r * 0.25f, cy + r * 0.5f); m.lineTo(cx, cy + r * 0.25f); m.lineTo(cx + r * 0.25f, cy + r * 0.5f); m.lineTo(cx + r * 0.5f, cy + r * 0.2f)
            st(det); cv.drawPath(m, p)
        }
        "panda" -> {
            fl(det); cv.drawCircle(cx - r * 0.6f, cy - r * 0.6f, r * 0.28f, p); cv.drawCircle(cx + r * 0.6f, cy - r * 0.6f, r * 0.28f, p)
            fl(col); cv.drawCircle(cx, cy + r * 0.05f, r * 0.8f, p)
            fl(det); cv.drawOval(RectF(cx - r * 0.55f, cy - r * 0.3f, cx - r * 0.15f, cy + r * 0.15f), p); cv.drawOval(RectF(cx + r * 0.15f, cy - r * 0.3f, cx + r * 0.55f, cy + r * 0.15f), p)
            cv.drawCircle(cx, cy + r * 0.3f, r * 0.12f, p)
            fl(col); cv.drawCircle(cx - r * 0.34f, cy - r * 0.1f, r * 0.07f, p); cv.drawCircle(cx + r * 0.34f, cy - r * 0.1f, r * 0.07f, p)
        }
        "fox" -> {
            fl(col); val pa = Path(); pa.moveTo(cx - r * 0.9f, cy - r * 0.9f); pa.lineTo(cx - r * 0.35f, cy - r * 0.45f); pa.lineTo(cx + r * 0.35f, cy - r * 0.45f)
            pa.lineTo(cx + r * 0.9f, cy - r * 0.9f); pa.lineTo(cx + r * 0.85f, cy + r * 0.1f); pa.lineTo(cx, cy + r * 0.9f); pa.lineTo(cx - r * 0.85f, cy + r * 0.1f); pa.close(); cv.drawPath(pa, p)
            fl(det); cv.drawCircle(cx - r * 0.32f, cy - r * 0.05f, r * 0.1f, p); cv.drawCircle(cx + r * 0.32f, cy - r * 0.05f, r * 0.1f, p); cv.drawCircle(cx, cy + r * 0.7f, r * 0.1f, p)
        }
        "fire" -> {
            val by = cy + r * 0.85f
            val cols = intArrayOf(0xFFFF4A00.toInt(), 0xFFFF9D00.toInt(), 0xFFFFE066.toInt()); val ss = floatArrayOf(1f, 0.72f, 0.42f)
            for (k in 0..2) {
                val s = ss[k]; val f = 1f + 0.12f * sin(t * 9 + k * 2); val tipY = by - r * 1.75f * s * f; val hw = r * 0.9f * s
                val tx = cx + sin(t * 6 + k) * r * 0.08f * s; val pa = Path()
                pa.moveTo(tx, tipY); pa.quadTo(cx - hw * 1.1f, by - r * 0.8f * s, cx, by); pa.quadTo(cx + hw * 1.1f, by - r * 0.8f * s, tx, tipY); pa.close()
                fl(cols[k]); cv.drawPath(pa, p)
            }
        }
        "moon" -> {
            fl(0xFFE4E4E8.toInt()); cv.drawCircle(cx, cy, r * 0.85f, p); fl(0xFFC4C4CA.toInt())
            cv.drawCircle(cx - r * 0.3f, cy - r * 0.2f, r * 0.2f, p); cv.drawCircle(cx + r * 0.25f, cy + r * 0.3f, r * 0.15f, p); cv.drawCircle(cx + r * 0.3f, cy - r * 0.35f, r * 0.1f, p)
        }
        "sun" -> {
            st(0xFFFFA000.toInt()); p.strokeWidth = sw * 0.8f
            for (i in 0 until 12) {
                val a = i * PIF / 6 + t * 0.5f; val q = r * (0.95f + 0.05f * sin(t * 4 + i))
                cv.drawLine(cx + r * 0.65f * cos(a), cy + r * 0.65f * sin(a), cx + q * cos(a), cy + q * sin(a), p)
            }
            fl(0xFFFFC21A.toInt()); cv.drawCircle(cx, cy, r * 0.5f, p)
        }
        "snow" -> {
            for (i in 0..5) {
                cv.save(); cv.rotate(i * 60f + t * 12, cx, cy)
                cv.drawLine(cx, cy, cx, cy - r, p); cv.drawLine(cx, cy - r * 0.55f, cx - r * 0.25f, cy - r * 0.8f, p); cv.drawLine(cx, cy - r * 0.55f, cx + r * 0.25f, cy - r * 0.8f, p); cv.restore()
            }
        }
        "jupiter" -> {
            val q = r * 0.85f; cv.save(); cv.clipPath(Path().apply { addCircle(cx, cy, q, Path.Direction.CW) })
            fl(0xFFE7C9A0.toInt()); cv.drawCircle(cx, cy, q, p)
            val bands = intArrayOf(0xFFB98B5E.toInt(), 0xFFF3DDBB.toInt(), 0xFFC49A6C.toInt(), 0xFFE9CFA6.toInt(), 0xFFA9744A.toInt(), 0xFFEBD3AE.toInt(), 0xFFBF8F62.toInt())
            val bh = 2 * q / bands.size
            for (i in bands.indices) { fl(bands[i]); val y0 = cy - q + i * bh + sin(t + i) * q * 0.02f; cv.drawRect(cx - q, y0, cx + q, y0 + bh * 0.9f, p) }
            val sx = cx + q * 1.2f * sin(t * 0.8f)
            if (cos(t * 0.8f) > 0f) { fl(0xFFC4572F.toInt()); cv.drawOval(RectF(sx - q * 0.22f, cy + q * 0.2f, sx + q * 0.22f, cy + q * 0.42f), p) }
            p.shader = RadialGradient(cx - q * 0.3f, cy - q * 0.3f, q * 1.5f, 0x00000000, 0xAA000000.toInt(), Shader.TileMode.CLAMP); p.style = Paint.Style.FILL
            cv.drawCircle(cx, cy, q, p); p.shader = null; cv.restore()
        }
        "earth" -> {
            val q = r * 0.85f; cv.save(); cv.clipPath(Path().apply { addCircle(cx, cy, q, Path.Direction.CW) })
            fl(0xFF2F6FDB.toInt()); cv.drawCircle(cx, cy, q, p); fl(0xFF3DAA5A.toInt())
            for (i in 0..2) {
                val x = cx + (((i * 0.7f + t * 0.15f) % 2.1f) - 1.05f) * q * 1.6f
                cv.drawOval(RectF(x - q * 0.35f, cy - q * 0.4f + i * q * 0.3f, x + q * 0.35f, cy - q * 0.05f + i * q * 0.3f), p)
            }
            p.shader = RadialGradient(cx - q * 0.3f, cy - q * 0.3f, q * 1.5f, 0x00000000, 0x99000000.toInt(), Shader.TileMode.CLAMP); p.style = Paint.Style.FILL
            cv.drawCircle(cx, cy, q, p); p.shader = null; cv.restore()
        }
        "radar" -> {
            cv.drawCircle(cx, cy, r * 0.9f, p); p.strokeWidth = sw * 0.5f; cv.drawCircle(cx, cy, r * 0.5f, p)
            cv.drawLine(cx - r * 0.9f, cy, cx + r * 0.9f, cy, p); cv.drawLine(cx, cy - r * 0.9f, cx, cy + r * 0.9f, p)
            cv.save(); cv.rotate(t * 120f, cx, cy); p.style = Paint.Style.FILL
            p.shader = SweepGradient(cx, cy, intArrayOf(0x00000000, withA(col, 170)), null); cv.drawCircle(cx, cy, r * 0.9f, p); p.shader = null; cv.restore()
        }
        "saturn" -> {
            cv.save(); cv.rotate(-20f, cx, cy); val ov = RectF(cx - r, cy - r * 0.3f, cx + r, cy + r * 0.3f)
            st(0xFFD8C08A.toInt()); p.strokeWidth = r * 0.12f; cv.drawArc(ov, 180f, 180f, false, p)
            fl(0xFFE8CF9A.toInt()); cv.drawCircle(cx, cy, r * 0.5f, p)
            cv.save(); cv.clipPath(Path().apply { addCircle(cx, cy, r * 0.5f, Path.Direction.CW) }); fl(0xFFC9A66B.toInt()); cv.drawRect(cx - r * 0.5f, cy - r * 0.12f, cx + r * 0.5f, cy + r * 0.04f, p); cv.restore()
            st(0xFFD8C08A.toInt()); p.strokeWidth = r * 0.12f; cv.drawArc(ov, 0f, 180f, false, p); cv.restore()
        }
        "plasma" -> {
            val q = r * (0.85f + 0.1f * sin(t * 4)); p.style = Paint.Style.FILL
            p.shader = RadialGradient(cx, cy, q, intArrayOf(Color.WHITE, col, withA(col, 0)), floatArrayOf(0f, 0.45f, 1f), Shader.TileMode.CLAMP)
            cv.drawCircle(cx, cy, q, p); p.shader = null; st(Color.WHITE); p.strokeWidth = sw * 0.5f
            for (i in 0..2) cv.drawArc(RectF(cx - q * 0.6f, cy - q * 0.6f, cx + q * 0.6f, cy + q * 0.6f), t * 200f + i * 120f, 50f, false, p)
        }
        "galaxy" -> {
            fl(col)
            for (arm in 0..1) for (i in 1..28) {
                val f = i / 28f; val an = arm * PIF + f * 5f + t * 0.6f; val rr0 = f * r * 0.95f
                p.alpha = (255 * (1f - f * 0.5f)).toInt()
                cv.drawCircle(cx + rr0 * cos(an), cy + rr0 * sin(an) * 0.65f, max(1f, r * 0.08f * (1f - f * 0.5f)), p)
            }
            p.alpha = 255; fl(Color.WHITE); cv.drawCircle(cx, cy, r * 0.12f, p)
        }
        "comet" -> {
            for (k in 8 downTo 0) {
                val a = t * 2 - k * 0.14f; fl(if (k == 0) Color.WHITE else col); p.alpha = (255 * (1f - k / 9f)).toInt()
                cv.drawCircle(cx + r * 0.6f * cos(a), cy + r * 0.6f * sin(a), r * (0.2f - k * 0.015f), p)
            }
            p.alpha = 255
        }
        "hole" -> {
            p.style = Paint.Style.FILL
            p.shader = RadialGradient(cx, cy, r, intArrayOf(Color.BLACK, Color.BLACK, 0xFFFF8A00.toInt(), 0x00FF8A00), floatArrayOf(0f, 0.4f, 0.55f, 1f), Shader.TileMode.CLAMP)
            cv.drawCircle(cx, cy, r, p); p.shader = null; st(withA(Color.WHITE, 160)); p.strokeWidth = sw * 0.5f
            for (k in 0..2) {
                val q = r * (0.7f + 0.1f * k); val e = r * (0.25f + 0.04f * k)
                cv.drawArc(RectF(cx - q, cy - e, cx + q, cy + e), t * 300f + k * 120f, 130f, false, p)
            }
        }
        else -> {
            cv.drawLine(cx - r, cy, cx - r * 0.3f, cy, p); cv.drawLine(cx + r * 0.3f, cy, cx + r, cy, p)
            cv.drawLine(cx, cy - r, cx, cy - r * 0.3f, p); cv.drawLine(cx, cy + r * 0.3f, cx, cy + r, p); fl(col); cv.drawCircle(cx, cy, r * 0.1f, p)
        }
    }
    p.strokeCap = Paint.Cap.BUTT; p.shader = null; p.alpha = 255
}

class CrossView(c: Context, val preview: Boolean) : View(c) {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG); private var t = 0f
    override fun onMeasure(w: Int, h: Int) {
        val s = if (preview) context.dp(130) else context.dp(P.int("csize", 48))
        setMeasuredDimension(if (preview) MeasureSpec.getSize(w) else s, s)
    }
    private fun layer(cv: Canvas, key: String, eff: String, colKey: String, cx: Float, cy: Float, r0: Float) {
        if (key == "none") return
        var r = r0; var x = cx; var y = cy; var col = P.int(colKey, 0).let { if (it == 0) P.accent else it }
        cv.save()
        when (eff) {
            "pulse" -> r *= 1f + 0.18f * sin(t * 3)
            "spin" -> cv.rotate(t * 60f, cx, cy)
            "spinr" -> cv.rotate(-t * 60f, cx, cy)
            "blink" -> if ((t * 2).toInt() % 2 == 1) { cv.restore(); return }
            "shake" -> { x += sin(t * 40) * r0 * 0.06f; y += cos(t * 33) * r0 * 0.06f }
            "rainbow" -> col = Color.HSVToColor(floatArrayOf((t * 80) % 360, 0.9f, 1f))
            "orbit" -> { x += cos(t * 2) * r0 * 0.5f; y += sin(t * 2) * r0 * 0.5f }
            "glow" -> p.setShadowLayer(r0 * 0.5f, 0f, 0f, col)
        }
        if (P.sp.getBoolean("cout", false) && eff != "glow") p.setShadowLayer(3f, 0f, 0f, Color.BLACK)
        drawCross(cv, p, key, x, y, r, col, t)
        p.clearShadowLayer(); cv.restore()
    }
    override fun onDraw(cv: Canvas) {
        t += 0.016f
        val size = context.dp(P.int("csize", 48)).toFloat(); val cx = width / 2f; val cy = height / 2f; val r1 = size * 0.36f
        val k1 = P.str("cs1", "cross"); val k2 = P.str("cs2", "none"); val e1 = P.str("ceff1", "none"); val e2 = P.str("ceff2", "none")
        layer(cv, k1, e1, "ccol1", cx, cy, r1)
        layer(cv, k2, e2, "ccol2", cx, cy, r1 * P.int("csz2", 40) / 100f)
        if (e1 != "none" || e2 != "none" || k1 in ANIMATED || k2 in ANIMATED) postInvalidateOnAnimation()
    }
}

private fun layerUi(c: Context, v: ArrayList<View>, n: Int, a: () -> Unit, withNone: Boolean) {
    val key = "cs$n"; val cur = P.str(key, if (n == 1) "cross" else "none")
    fun pick(label: String, list: List<CS>, k: String, first: List<Pair<String, String>>) {
        v.add(c.tv(label, 12f, P.sub()))
        v.add(c.chipRow(first + list.map { it.k to c.csl(it) }, cur, k) { if (it == "none" || c.csGate(it)) { P.putS(key, it); a() } })
    }
    pick("Фигуры", CS_BASIC, "cs${n}a", if (withNone) listOf("none" to "Нет") else emptyList())
    pick("Персонажи", CS_CHAR, "cs${n}b", emptyList()); pick("Эффектные", CS_FX, "cs${n}c", emptyList())
    v.add(c.tv("Анимация", 12f, P.sub()))
    v.add(c.chipRow(CS_EFF.map { it.k to c.csl(it) }, P.str("ceff$n", "none"), "ce$n") { if (c.csGate(it, CS_EFF)) { P.putS("ceff$n", it); a() } })
    v.addAll(c.colorSec("Цвет (A — как акцент меню)", "ccol$n", CCOLS, P.int("ccol$n", 0), P.accent, a))
}

fun crossPage(c: Context, sh: Shell): View {
    val a = { OverlayService.inst?.refreshCross(); sh.rebuild() }
    val v = ArrayList<View>()
    v.add(c.sw("Показывать прицел на экране", "cross", "cross") { OverlayService.inst?.setCross(P.sp.getBoolean("cross", false)); if (P.sp.getBoolean("cross", false)) Q.done("cross") })
    v.add(c.tv("Прицел виден, пока запущено плавающее меню. У огня и планет свои цвета.", 11f, P.sub()))
    v.add(c.card(c.tv("Предпросмотр", 12f, P.sub()), CrossView(c, true)))
    v.add(c.sec("Первый прицел")); layerUi(c, v, 1, a, false)
    v.add(c.tv("Размер", 12f, P.sub())); v.add(c.seek("csize", 16, 96, 48, null, a))
    v.add(c.sec("Второй прицел (внутри первого)")); layerUi(c, v, 2, a, true)
    v.add(c.tv("Размер второго, % от первого", 12f, P.sub())); v.add(c.seek("csz2", 10, 100, 40, null, a))
    v.add(c.sec("Общее"))
    v.add(c.tv("Прозрачность", 12f, P.sub())); v.add(c.seek("calpha", 20, 100, 100, null, a))
    v.add(c.sw("Тёмная обводка", "cout", null, a))
    v.add(c.tv("Сдвиг по горизонтали", 12f, P.sub())); v.add(c.seek("coffx", -200, 200, 0, null, a))
    v.add(c.tv("Сдвиг по вертикали", 12f, P.sub())); v.add(c.seek("coffy", -200, 200, 0, null, a))
    v.add(c.row3(
        c.btn("Случайный", false) {
            val r = java.util.Random(); val ok = CS_ALL.filter { Xp.lv(it.lv) }; val eff = CS_EFF.filter { Xp.lv(it.lv) }
            P.putS("cs1", ok[r.nextInt(ok.size)].k); P.putS("cs2", if (r.nextBoolean()) ok[r.nextInt(ok.size)].k else "none")
            P.putS("ceff1", eff[r.nextInt(eff.size)].k); P.putS("ceff2", eff[r.nextInt(eff.size)].k)
            P.putI("ccol1", CCOLS[1 + r.nextInt(CCOLS.size - 1)]); P.putI("ccol2", CCOLS[1 + r.nextInt(CCOLS.size - 1)]); a()
        },
        c.btn("Сбросить", false) {
            listOf("cs1", "cs2", "ceff1", "ceff2", "ccol1", "ccol2", "csize", "csz2", "calpha", "cout", "coffx", "coffy").forEach { P.sp.edit().remove(it).apply() }; a()
        }))
    return c.stack(*v.toTypedArray())
}
