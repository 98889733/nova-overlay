package com.nova.client
import android.content.Context
import android.view.*
import android.widget.*

class KeyPad(c: Context, val title: String, val masked: Boolean, digitsOnly: Boolean, okLabel: String, val onOk: (String) -> Unit) : LinearLayout(c) {
    private val sb = StringBuilder()
    private val disp = c.tv("", 20f, P.fg(), true)
    private fun refresh() {
        disp.text = if (sb.isEmpty()) title else if (masked) "•".repeat(sb.length) else sb.toString()
        disp.alpha = if (sb.isEmpty()) 0.5f else 1f
    }
    private fun key(ch: String): () -> Unit = { if (sb.length < 24) { sb.append(ch); refresh() } }
    private fun addRow(c: Context, keys: List<Pair<String, () -> Unit>>) {
        val r = LinearLayout(c)
        keys.forEach { (t, f) ->
            r.addView(c.tv(t, 15f, P.fg(), true).apply {
                gravity = Gravity.CENTER; background = rr(P.card(), c.dp(8).toFloat(), P.mix(P.bg(), P.fg(), 0.1f))
                setOnClickListener { performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP); f() }
            }, LinearLayout.LayoutParams(0, c.dp(40), 1f).apply { setMargins(c.dp(2), c.dp(2), c.dp(2), c.dp(2)) })
        }
        addView(r, LinearLayout.LayoutParams(-1, -2))
    }
    init {
        orientation = VERTICAL
        disp.gravity = Gravity.CENTER; disp.setPadding(c.dp(10), c.dp(12), c.dp(10), c.dp(12)); disp.background = rr(P.card(), c.dp(12).toFloat(), P.accent)
        addView(disp, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = c.dp(6) })
        refresh()
        val rows = if (digitsOnly) listOf("123", "456", "789") else listOf("1234567890", "QWERTYUIOP", "ASDFGHJKL", "ZXCVBNM", "@#$%&*-_!.")
        rows.forEach { row -> addRow(c, row.map { ch -> ch.toString() to key(ch.toString()) }) }
        val clear: () -> Unit = { sb.clear(); refresh() }
        val back: () -> Unit = { if (sb.isNotEmpty()) { sb.deleteCharAt(sb.length - 1); refresh() } }
        addRow(c, if (digitsOnly) listOf("Очистить" to clear, "0" to key("0"), "⌫" to back) else listOf("Очистить" to clear, "⌫" to back))
        addView(c.btn(okLabel) { val t = sb.toString(); sb.clear(); refresh(); onOk(t) }, LinearLayout.LayoutParams(-1, -2).apply { topMargin = c.dp(6) })
    }
}
