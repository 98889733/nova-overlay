package com.nova.client
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.content.res.Configuration
import android.graphics.*
import android.graphics.drawable.GradientDrawable
import android.os.*
import android.view.*
import android.widget.*
import java.text.SimpleDateFormat
import java.util.*
import kotlin.math.abs
import kotlin.math.sin

class OverlayService : Service() {
    companion object { var inst: OverlayService? = null }
    private lateinit var wm: WindowManager
    private lateinit var pp: WindowManager.LayoutParams
    private val ctx by lazy { ContextThemeWrapper(this, android.R.style.Theme_DeviceDefault) }
    private var pill: LinearLayout? = null; private var menu: Shell? = null; private var cross: View? = null
    private var fpsTv: TextView? = null; private var collapsed = false
    private val h = Handler(Looper.getMainLooper())
    private var fc = 0; private var lt = 0L
    private val cb = object : Choreographer.FrameCallback {
        override fun doFrame(t: Long) {
            if (inst == null) return
            fc++; if (lt == 0L) lt = t
            if (t - lt >= 500_000_000L) {
                val ex = if (P.sp.getBoolean("pinfo", false)) "  ·  " + SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date()) + "  ·  " + level(this@OverlayService) + "%" else ""
                fpsTv?.text = "FPS " + Math.round(fc * 1e9 / (t - lt)) + ex; fc = 0; lt = t
            }
            Choreographer.getInstance().postFrameCallback(this)
        }
    }
    private val type = WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
    private val flags = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL
    override fun onBind(i: Intent?): IBinder? = null
    override fun onStartCommand(i: Intent?, f: Int, s: Int) = START_STICKY
    override fun onCreate() {
        super.onCreate(); inst = this; P.init(this); Xp.start(this)
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        val n = notif(this, "Меню запущено")
        if (Build.VERSION.SDK_INT >= 34) startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE) else startForeground(1, n)
        P.putL("ses_t", System.currentTimeMillis()); P.putI("ses_b", level(this))
        pp = WindowManager.LayoutParams(-2, -2, type, flags, PixelFormat.TRANSLUCENT).apply { gravity = Gravity.TOP or Gravity.START; x = ctx.dp(20); y = ctx.dp(60) }
        buildPill(); Choreographer.getInstance().postFrameCallback(cb)
        if (P.sp.getBoolean("cross", false)) setCross(true)
    }
    override fun onDestroy() {
        val t0 = P.getL("ses_t")
        if (t0 > 0) { P.putL("last_m", (System.currentTimeMillis() - t0) / 60000); P.putI("last_d", level(this) - P.int("ses_b", 0)) }
        inst = null; closeMenu(); setCross(false); recBadge(false); pill?.let { try { wm.removeView(it) } catch (e: Exception) {} }; super.onDestroy()
    }
    private fun scr(): Point {
        val p = Point()
        if (Build.VERSION.SDK_INT >= 30) { val b = wm.currentWindowMetrics.bounds; p.set(b.width(), b.height()) }
        else @Suppress("DEPRECATION") wm.defaultDisplay.getRealSize(p)
        return p
    }
    private fun menuLp(): WindowManager.LayoutParams {
        val s = scr(); val land = s.x > s.y
        val w = minOf((s.x * P.int("mw", 92) / 100f).toInt(), ctx.dp(560))
        val h = (s.y * (if (land) minOf(0.92f, P.int("mh", 74) / 100f + 0.18f) else P.int("mh", 74) / 100f)).toInt()
        return WindowManager.LayoutParams(w, h, type, flags or WindowManager.LayoutParams.FLAG_WATCH_OUTSIDE_TOUCH, PixelFormat.TRANSLUCENT).apply { gravity = Gravity.CENTER }
    }
    override fun onConfigurationChanged(n: Configuration) {
        super.onConfigurationChanged(n)
        menu?.let { try { wm.updateViewLayout(it, menuLp()) } catch (e: Exception) {} }
        val s = scr(); pp.x = pp.x.coerceIn(0, maxOf(0, s.x - ctx.dp(60))); pp.y = pp.y.coerceIn(0, maxOf(0, s.y - ctx.dp(60)))
        pill?.let { try { wm.updateViewLayout(it, pp) } catch (e: Exception) {} }
    }
    fun restyle() { buildPill(); refreshCross() }
    fun refreshCross() { if (cross != null) { setCross(false); setCross(true) } }
    fun setCross(on: Boolean) {
        cross?.let { try { wm.removeView(it) } catch (e: Exception) {} }; cross = null
        if (!on) return
        val v = CrossView(ctx, false); v.alpha = P.int("calpha", 100) / 100f
        wm.addView(v, WindowManager.LayoutParams(-2, -2, type, WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL, PixelFormat.TRANSLUCENT)
            .apply { gravity = Gravity.CENTER; x = ctx.dp(P.int("coffx", 0)); y = ctx.dp(P.int("coffy", 0)) })
        cross = v
    }
    private fun buildPill() {
        pill?.let { try { wm.removeView(it) } catch (e: Exception) {} }
        val c = ctx
        fpsTv = c.tv("FPS --", P.int("psz", 13).toFloat(), P.accent, true)
        val arrow = c.tv(if (collapsed) "▸" else "▾", 14f, P.fg(), true)
        val l = LinearLayout(c).apply {
            gravity = Gravity.CENTER_VERTICAL; setPadding(c.dp(12), c.dp(6), c.dp(10), c.dp(6)); background = pillBg()
            alpha = P.int("pop", 100) / 100f; visibility = if (menu != null) View.INVISIBLE else View.VISIBLE
        }
        if (!collapsed) l.addView(fpsTv)
        l.addView(arrow.apply { setPadding(if (collapsed) 0 else c.dp(10), 0, 0, 0) })
        pp.flags = flags or (if (P.sp.getBoolean("awake", false)) WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON else 0)
        var sx = 0f; var sy = 0f; var ox = 0; var oy = 0; var moved = false
        l.setOnTouchListener { v, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> { sx = e.rawX; sy = e.rawY; ox = pp.x; oy = pp.y; moved = false }
                MotionEvent.ACTION_MOVE -> {
                    val dx = e.rawX - sx; val dy = e.rawY - sy
                    if (abs(dx) > 10 || abs(dy) > 10) moved = true
                    if (moved) { pp.x = ox + dx.toInt(); pp.y = oy + dy.toInt(); wm.updateViewLayout(v, pp) }
                }
                MotionEvent.ACTION_UP -> if (!moved) { if (collapsed || e.x > arrow.left) { collapsed = !collapsed; buildPill() } else openMenu() }
                else if (P.sp.getBoolean("snap", false) && Xp.ok("snap")) { val sz = scr(); pp.x = if (pp.x + v.width / 2 < sz.x / 2) 0 else sz.x - v.width; wm.updateViewLayout(v, pp) }
            }
            true
        }
        wm.addView(l, pp); pill = l
    }
    private var mlp: WindowManager.LayoutParams? = null
    private fun openMenu() {
        if (menu != null) return
        pill?.visibility = View.INVISIBLE
        val c = ctx
        val sh = Shell(c, "NOVA", "bgM", listOf("Запуск", "Прицел", "Утилиты", "Игры", "Опции"), P.int("mr", 24), { closeMenu() }) { i, s ->
            when (i) {
                0 -> appsPage(c, s) { pk -> closeMenu(); packageManager.getLaunchIntentForPackage(pk)?.let { startActivity(it.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) } }
                1 -> crossPage(c, s)
                2 -> utilsPage(c, s)
                3 -> gamesPage(c, s)
                else -> c.settingsView { s.rebuild() }
            }
        }
        val lp = menuLp(); mlp = lp
        sh.dragCb = { dx, dy -> lp.x += dx.toInt(); lp.y += dy.toInt(); try { wm.updateViewLayout(sh, lp) } catch (e: Exception) {} }
        sh.setOnTouchListener { _, e -> if (e.action == MotionEvent.ACTION_OUTSIDE && !P.sp.getBoolean("keepopen", false)) closeMenu(); false }
        wm.addView(sh, lp); menu = sh
    }
    fun closeMenu() {
        menu?.let { try { wm.removeView(it) } catch (e: Exception) {} }; menu = null; pill?.visibility = View.VISIBLE
    }
    private fun need(): Boolean {
        if (CaptureService.inst != null) return false
        Toast.makeText(this, "Сначала выдай доступ к записи экрана", Toast.LENGTH_LONG).show()
        startActivity(Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK).putExtra("cap", true))
        return true
    }
    fun snap() {
        if (need()) return
        if (CaptureService.inst?.recording == true) { Toast.makeText(this, "Сначала останови запись", Toast.LENGTH_SHORT).show(); return }
        closeMenu(); pill?.visibility = View.INVISIBLE; cross?.visibility = View.INVISIBLE
        h.postDelayed({ CaptureService.inst?.shot() }, 500); h.postDelayed({ pill?.visibility = View.VISIBLE; cross?.visibility = View.VISIBLE }, 1200)
    }
    fun toggleRec() {
        if (need()) return
        val cs = CaptureService.inst ?: return
        if (cs.recording) { cs.stopRec(); menu?.rebuild() } else { cs.startRec(); closeMenu() }
    }
}
