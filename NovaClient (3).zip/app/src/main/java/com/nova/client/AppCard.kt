package com.nova.client
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.*
import android.graphics.drawable.Drawable
import android.net.Uri
import android.provider.Settings
import android.view.*
import android.widget.*
import java.io.File
import java.text.SimpleDateFormat
import java.util.*

// Баннер приложения: цвет берётся из иконки, большая иконка размыто на фоне, маленькая по центру.
class Banner(c: Context, val icon: Drawable, val name: String) : View(c) {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG); private var base = P.accent; private var t = 0f
    init {
        val b = Bitmap.createBitmap(16, 16, Bitmap.Config.ARGB_8888); val cv = Canvas(b)
        icon.setBounds(0, 0, 16, 16); icon.draw(cv)
        var r = 0L; var g = 0L; var bl = 0L; var n = 0L
        for (x in 0 until 16) for (y in 0 until 16) {
            val px = b.getPixel(x, y)
            if (Color.alpha(px) > 128) { r += Color.red(px); g += Color.green(px); bl += Color.blue(px); n++ }
        }
        if (n > 0) base = Color.rgb((r / n).toInt(), (g / n).toInt(), (bl / n).toInt())
    }
    override fun onMeasure(w: Int, h: Int) { setMeasuredDimension(MeasureSpec.getSize(w), context.dp(190)) }
    override fun onDraw(cv: Canvas) {
        t += 0.02f
        val d = context.resources.displayMetrics.density; val w = width.toFloat(); val h = height.toFloat()
        p.style = Paint.Style.FILL
        p.shader = LinearGradient(0f, 0f, w, h, P.mix(base, Color.WHITE, 0.25f), P.mix(base, Color.BLACK, 0.5f), Shader.TileMode.CLAMP)
        cv.drawRoundRect(RectF(0f, 0f, w, h), 18 * d, 18 * d, p); p.shader = null
        cv.save(); cv.clipPath(Path().apply { addRoundRect(RectF(0f, 0f, w, h), 18 * d, 18 * d, Path.Direction.CW) })
        p.color = Color.argb(40, 255, 255, 255)
        cv.drawCircle(w * 0.15f + sin(t) * 12 * d, h * 0.25f, 60 * d, p); cv.drawCircle(w * 0.85f - sin(t * 0.8f) * 14 * d, h * 0.7f, 80 * d, p)
        val big = 170 * d; cv.save(); cv.rotate(-14f, w * 0.78f, h * 0.4f)
        icon.setBounds((w * 0.78f - big / 2).toInt(), (h * 0.4f - big / 2).toInt(), (w * 0.78f + big / 2).toInt(), (h * 0.4f + big / 2).toInt())
        icon.alpha = 60; icon.draw(cv); icon.alpha = 255; cv.restore()
        p.shader = LinearGradient(0f, h * 0.45f, 0f, h, 0x00000000, 0xAA000000.toInt(), Shader.TileMode.CLAMP); cv.drawRect(0f, h * 0.45f, w, h, p); p.shader = null
        cv.restore()
        val s = 72 * d; val cx = w / 2; val top = h * 0.14f
        p.color = Color.argb(60, 0, 0, 0); cv.drawRoundRect(RectF(cx - s / 2 - 2 * d, top + 4 * d, cx + s / 2 + 2 * d, top + s + 8 * d), 20 * d, 20 * d, p)
        p.color = Color.WHITE; cv.drawRoundRect(RectF(cx - s / 2 - 4 * d, top - 4 * d, cx + s / 2 + 4 * d, top + s + 4 * d), 20 * d, 20 * d, p)
        icon.setBounds((cx - s / 2).toInt(), top.toInt(), (cx + s / 2).toInt(), (top + s).toInt()); icon.draw(cv)
        p.color = Color.WHITE; p.textAlign = Paint.Align.CENTER; p.textSize = 17 * d; p.typeface = Typeface.DEFAULT_BOLD
        p.setShadowLayer(4 * d, 0f, 1f, Color.BLACK); cv.drawText(name.take(28), cx, h - 16 * d, p); p.clearShadowLayer()
        postInvalidateOnAnimation()
    }
    private fun sin(x: Float) = kotlin.math.sin(x)
}

fun appDetail(c: Context, sh: Shell, pk: String, go: (String) -> Unit): View {
    val pm = c.packageManager
    val back = { sh.appPk = null; sh.confirm = false; sh.sy = 0; sh.rebuild() }
    val info = try { pm.getPackageInfo(pk, PackageManager.GET_PERMISSIONS) } catch (e: Exception) { null }
    val ic = try { pm.getApplicationIcon(pk) } catch (e: Exception) { null }
    val ai = info?.applicationInfo
    if (info == null || ic == null || ai == null) return c.stack(c.btn("← Назад", false) { back() }, c.tv("Приложение не найдено (возможно, удалено).", 14f))
    val label = pm.getApplicationLabel(ai).toString()
    val df = SimpleDateFormat("dd.MM.yyyy HH:mm", Locale.getDefault())
    val mb = File(ai.sourceDir).length() / 1048576.0
    val opened = P.int("lc_$pk", 0)
    val rows = listOf("Версия" to (info.versionName ?: "—"), "Пакет" to pk, "Установлено" to df.format(Date(info.firstInstallTime)),
        "Обновлено" to df.format(Date(info.lastUpdateTime)), "Размер APK" to "%.1f МБ".format(mb), "Target SDK" to ai.targetSdkVersion.toString(),
        "Разрешений" to (info.requestedPermissions?.size ?: 0).toString(), "Открыто через NOVA" to "$opened раз")
    val infoCard = c.card(*rows.map { (k, v) ->
        LinearLayout(c).apply {
            addView(c.tv(k, 12f, P.sub()), LinearLayout.LayoutParams(0, -2, 1f))
            addView(c.tv(v, 12f, P.fg(), true).apply { gravity = Gravity.END; maxLines = 1; ellipsize = android.text.TextUtils.TruncateAt.MIDDLE }, LinearLayout.LayoutParams(0, -2, 1.6f))
        } as View
    }.toTypedArray())
    val v = ArrayList<View>()
    v.add(c.btn("← Назад", false) { back() })
    v.add(Banner(c, ic, label))
    v.add(c.btn("Открыть приложение") { P.putI("lc_$pk", opened + 1); go(pk) })
    v.add(c.row3(
        c.btn("Системные", false) {
            c.startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$pk")).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)); OverlayService.inst?.closeMenu()
        },
        c.btn(if (sh.confirm) "Точно?" else "Удалить", false) {
            if (sh.confirm) {
                c.startActivity(Intent(Intent.ACTION_DELETE, Uri.parse("package:$pk")).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)); OverlayService.inst?.closeMenu()
            } else { sh.confirm = true; sh.rebuild() }
        },
        c.btn("Убрать", false) { P.delApp(pk); back() }))
    if (sh.confirm) v.add(c.card(c.tv("Удалить «$label» с телефона? Откроется системное окно подтверждения.", 13f), c.btn("Отмена", false) { sh.confirm = false; sh.rebuild() }))
    v.add(c.row3(
        c.btn("Закрепить первым", false) { P.pinApp(pk); Toast.makeText(c, "Приложение теперь первое", Toast.LENGTH_SHORT).show(); back() },
        c.btn("Копировать пакет", false) {
            (c.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager).setPrimaryClip(ClipData.newPlainText("package", pk))
            Toast.makeText(c, "Скопировано", Toast.LENGTH_SHORT).show()
        }))
    v.add(infoCard)
    return c.stack(*v.toTypedArray())
}
