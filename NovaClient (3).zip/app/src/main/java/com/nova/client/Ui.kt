package com.nova.client
import android.app.AlertDialog
import android.content.*
import android.graphics.*
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.Environment
import android.provider.MediaStore
import android.view.*
import android.widget.*
import java.io.File
import java.text.SimpleDateFormat
import java.util.*

fun Context.dp(v: Int) = (v * resources.displayMetrics.density).toInt()
fun rr(c: Int, r: Float, stroke: Int = 0) = GradientDrawable().apply { setColor(c); cornerRadius = r; if (stroke != 0) setStroke(3, stroke) }
fun Context.tv(t: String, sz: Float = 14f, col: Int = P.fg(), bold: Boolean = false) = TextView(this).apply {
    text = t; textSize = sz; setTextColor(col); if (bold) setTypeface(typeface, Typeface.BOLD)
}
fun Context.btn(t: String, filled: Boolean = true, f: () -> Unit) = tv(t, 14f, if (filled) Color.WHITE else P.fg(), true).apply {
    gravity = Gravity.CENTER; setPadding(dp(14), dp(11), dp(14), dp(11))
    background = rr(if (filled) P.accent else P.card(), dp(12).toFloat()); setOnClickListener { f() }
}
fun Context.lp(m: Int = 0) = LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(m) }
fun Context.stack(vararg v: View) = LinearLayout(this).apply {
    orientation = LinearLayout.VERTICAL; setPadding(dp(14), dp(6), dp(14), dp(14)); v.forEach { addView(it, lp(8)) }
}
fun Context.card(vararg v: View) = LinearLayout(this).apply {
    orientation = LinearLayout.VERTICAL; setPadding(dp(14), dp(10), dp(14), dp(12)); background = rr(P.card(), dp(14).toFloat(), P.mix(P.bg(), P.fg(), 0.1f)); v.forEach { addView(it, lp(6)) }
}
fun Context.row3(vararg b: View) = LinearLayout(this).apply {
    b.forEach { addView(it, LinearLayout.LayoutParams(0, -2, 1f).apply { setMargins(dp(3), 0, dp(3), 0) }) }
}

val ACC = listOf(0xFF5B6CFF, 0xFFFF4D6D, 0xFF22C55E, 0xFFF59E0B, 0xFF06B6D4, 0xFFA855F7, 0xFFEC4899, 0xFF16171D).map { it.toInt() }
val TXT = listOf(0L, 0xFF16171D, 0xFFFFFFFF, 0xFF6B7280, 0xFF5B6CFF, 0xFFFF4D6D, 0xFF22C55E).map { it.toInt() }
val PBG = listOf(0L, 0xFFFFFFFF, 0xFFF3F4F8, 0xFF14151C, 0xFF0B1026, 0xFF1A0F2E, 0xFF0F2A1F).map { it.toInt() }
val MODES = listOf("stars" to "Звёзды", "cubes" to "3D кубы", "triangles" to "Треугольники", "circles" to "Круги", "cylinders" to "Цилиндры",
    "starshapes" to "Звёздочки", "rain" to "Дождь", "wind" to "Ветер", "fog" to "Туман", "space" to "Космос", "galaxy" to "Галактики", "planets" to "Планеты", "particles" to "Частицы", "smoke" to "Дым")

fun Context.infoView() = stack(
    tv("NOVA Client 1.0", 20f, P.accent, true),
    card(tv("Плавающее меню поверх всех окон: плашка FPS, быстрый запуск своих приложений, часы, заряд, таймер, скриншоты и запись экрана."),
        tv("FPS на плашке — частота обновления экрана, а не конкретной игры.", 13f, P.sub()),
        tv("Файлы лежат во вкладке «Фото и видео», оттуда их можно скачать на телефон.", 13f, P.sub())))

fun row(c: Context, ic: Drawable, name: String, f: () -> Unit): View = LinearLayout(c).apply {
    gravity = Gravity.CENTER_VERTICAL; setPadding(c.dp(12), c.dp(10), c.dp(12), c.dp(10)); background = rr(P.card(), c.dp(12).toFloat())
    addView(ImageView(c).apply { setImageDrawable(ic) }, LinearLayout.LayoutParams(c.dp(36), c.dp(36)))
    addView(c.tv(name, 15f).apply { setPadding(c.dp(12), 0, 0, 0) }); setOnClickListener { f() }
}
fun tile(c: Context, ic: Drawable?, label: String, click: () -> Unit, hold: (() -> Unit)? = null): View = LinearLayout(c).apply {
    orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_HORIZONTAL; setPadding(c.dp(4), c.dp(8), c.dp(4), c.dp(8))
    if (ic != null) addView(ImageView(c).apply { setImageDrawable(ic) }, LinearLayout.LayoutParams(c.dp(48), c.dp(48)))
    else addView(c.tv("+", 26f, P.accent, true).apply { gravity = Gravity.CENTER; background = rr(P.card(), c.dp(14).toFloat(), P.accent) }, LinearLayout.LayoutParams(c.dp(48), c.dp(48)))
    addView(c.tv(label, 11f, P.fg()).apply { gravity = Gravity.CENTER; maxLines = 1; ellipsize = android.text.TextUtils.TruncateAt.END }, LinearLayout.LayoutParams(-1, -2).apply { topMargin = c.dp(4) })
    setOnClickListener { click() }
    if (hold != null) setOnLongClickListener { hold(); true }
}
fun appsPage(c: Context, sh: Shell, go: (String) -> Unit): View {
    val pm = c.packageManager
    val dpk = sh.appPk
    if (dpk != null) return appDetail(c, sh, dpk, go)
    if (sh.flag) {
        val list = pm.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0).sortedBy { it.loadLabel(pm).toString().lowercase() }
        val s = c.stack(c.btn("← Назад", false) { sh.flag = false; sh.sy = 0; sh.rebuild() })
        list.forEach { ri -> val pk = ri.activityInfo.packageName; s.addView(row(c, ri.loadIcon(pm), ri.loadLabel(pm).toString()) { if (P.apps().size >= Xp.maxApps() && pk !in P.apps()) Toast.makeText(c, "Слотов нет — повышай уровень", Toast.LENGTH_SHORT).show() else { P.addApp(pk); sh.flag = false; sh.sy = 0; sh.rebuild() } }, c.lp(6)) }
        return s
    }
    val os = OverlayService.inst; val rec = CaptureService.inst?.recording == true
    val s = c.stack(c.row3(c.btn("Скриншот") { os?.snap() }, c.btn(if (rec) "Стоп" else "Запись") { os?.toggleRec() }, c.btn("Фонарик") { if (c.gate("torch")) flash(c) }))
    val items = ArrayList<View>()
    P.apps().forEach { pk ->
        val ic = try { pm.getApplicationIcon(pk) } catch (e: Exception) { null }
        if (ic != null && pm.getLaunchIntentForPackage(pk) != null) items.add(tile(c, ic, pm.getApplicationInfo(pk, 0).loadLabel(pm).toString(), { sh.appPk = pk; sh.confirm = false; sh.sy = 0; sh.rebuild() }) { P.putI("lc_$pk", P.int("lc_$pk", 0) + 1); go(pk) })
    }
    items.add(tile(c, null, "Добавить", { sh.flag = true; sh.sy = 0; sh.rebuild() }))
    items.chunked(4).forEach { ch ->
        s.addView(LinearLayout(c).apply {
            ch.forEach { addView(it, LinearLayout.LayoutParams(0, -2, 1f)) }
            repeat(4 - ch.size) { addView(View(c), LinearLayout.LayoutParams(0, 1, 1f)) }
        }, c.lp(4))
    }
    s.addView(c.tv("Слоты: ${P.apps().size}/${Xp.maxApps()} (+1 за каждый уровень) · нажми на значок — карточка, удерживай — быстрый запуск", 11f, P.sub()), c.lp(6))
    return s
}
fun tick(v: TextView, f: () -> String) { v.text = f(); v.postDelayed({ if (v.isAttachedToWindow) tick(v, f) }, 1000) }
fun battery(c: Context): String {
    val i = c.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
    val l = i?.getIntExtra("level", -1) ?: -1; val s = i?.getIntExtra("scale", 100) ?: 100; val st = i?.getIntExtra("status", 0) ?: 0
    return "${l * 100 / s}%" + if (st == 2 || st == 5) " (заряжается)" else ""
}
fun toolsPage(c: Context, sh: Shell): View {
    val clock = c.tv("", 24f, P.fg(), true); tick(clock) { SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(Date()) }
    val bat = c.tv("", 14f, P.sub()); tick(bat) { "Заряд: " + battery(c) }
    val tl = c.tv("", 34f, P.accent, true).apply { gravity = Gravity.CENTER }
    tick(tl) { val s = T.left(); "%02d:%02d".format(s / 60, s % 60) }
    val run = T.end > 0
    return c.stack(
        c.card(clock, bat),
        c.card(c.tv("Таймер", 13f, P.sub()), tl,
            c.row3(c.btn("+1 мин", false) { if (!run) T.total += 60; sh.rebuild() }, c.btn("+5 мин", false) { if (!run) T.total += 300; sh.rebuild() }, c.btn("Сброс", false) { T.stop(); T.total = 0; sh.rebuild() }),
            c.btn(if (run) "Стоп" else "Старт") { if (run) T.stop() else T.start(c.applicationContext); sh.rebuild() }))
}
fun utilsPage(c: Context, sh: Shell): View {
    val body = if (UiS.utab == 0) toolsPage(c, sh) else phonePage(c, sh)
    body.setPadding(0, 0, 0, 0)
    return c.stack(c.subTabs(listOf("Инструменты", "Телефон"), UiS.utab, "utab") { UiS.utab = it; UiS.top = true; sh.rebuild() }, body)
}

fun thumb(f: File, vid: Boolean, iv: ImageView) {
    Thread {
        val b = try {
            if (vid) MediaMetadataRetriever().run { setDataSource(f.path); val x = getFrameAtTime(0); release(); x }
            else BitmapFactory.decodeFile(f.path, BitmapFactory.Options().apply { inSampleSize = 4 })
        } catch (e: Exception) { null }
        iv.post { iv.setImageBitmap(b) }
    }.start()
}
fun Context.savePhone(f: File, vid: Boolean): Uri? {
    val cv = ContentValues().apply {
        put(MediaStore.MediaColumns.DISPLAY_NAME, f.name); put(MediaStore.MediaColumns.MIME_TYPE, if (vid) "video/mp4" else "image/png")
        put(MediaStore.MediaColumns.RELATIVE_PATH, (if (vid) Environment.DIRECTORY_MOVIES else Environment.DIRECTORY_PICTURES) + "/NovaClient")
    }
    val u = contentResolver.insert(if (vid) MediaStore.Video.Media.EXTERNAL_CONTENT_URI else MediaStore.Images.Media.EXTERNAL_CONTENT_URI, cv) ?: return null
    contentResolver.openOutputStream(u)?.use { o -> f.inputStream().use { it.copyTo(o) } }
    return u
}
fun Context.act(f: File, vid: Boolean, sh: Shell) {
    AlertDialog.Builder(this).setItems(arrayOf("Открыть", "Скачать на телефон", "Удалить")) { _, w ->
        when (w) {
            0 -> savePhone(f, vid)?.let { try { startActivity(Intent(Intent.ACTION_VIEW).setDataAndType(it, if (vid) "video/mp4" else "image/png").addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)) } catch (e: Exception) {} }
            1 -> Toast.makeText(this, if (savePhone(f, vid) != null) "Сохранено: " + (if (vid) "Movies" else "Pictures") + "/NovaClient" else "Ошибка", Toast.LENGTH_LONG).show()
            else -> { f.delete(); sh.rebuild() }
        }
    }.show()
}
fun Context.gallery(sh: Shell): View {
    val vid = sh.sub == 1
    val files = File(filesDir, if (vid) "videos" else "shots").listFiles()?.sortedByDescending { it.lastModified() } ?: emptyList()
    val s = stack(row3(btn("Фото", sh.sub == 0) { sh.sub = 0; sh.sy = 0; sh.rebuild() }, btn("Видео", sh.sub == 1) { sh.sub = 1; sh.sy = 0; sh.rebuild() }))
    if (files.isEmpty()) s.addView(tv(if (vid) "Видео пока нет. Запиши экран из плавающего меню." else "Скриншотов пока нет. Сделай их из плавающего меню.", 13f, P.sub()), lp(8))
    val cols = maxOf(3, resources.displayMetrics.widthPixels / dp(130))
    files.chunked(cols).forEach { ch ->
        s.addView(LinearLayout(this).apply {
            ch.forEach { f ->
                addView(ImageView(context).apply {
                    scaleType = ImageView.ScaleType.CENTER_CROP; background = rr(P.card(), dp(8).toFloat()); thumb(f, vid, this); setOnClickListener { act(f, vid, sh) }
                }, LinearLayout.LayoutParams(0, dp(110), 1f).apply { setMargins(dp(3), dp(3), dp(3), dp(3)) })
            }
            repeat(cols - ch.size) { addView(View(context), LinearLayout.LayoutParams(0, dp(110), 1f)) }
        }, lp())
    }
    return s
}

