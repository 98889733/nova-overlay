# Publishing NOVA Client on Google Play

1. Target API: Google Play requires targetSdk 36 (since 2026-08-31). The normal build stays on 34 so it keeps working. The Play build uses the flags -Pplay -Pagp=8.9.1 -Pkgp=2.0.21 with Gradle 8.13 (see .github/workflows/play-release.yml, run it by hand). It is untested: after it builds, test the app on an Android 16 device.
2. Own signing key (do NOT use nova.jks, it is public):
   keytool -genkeypair -v -keystore release.jks -alias nova -keyalg RSA -keysize 2048 -validity 36500
   GitHub Secrets: KS_B64 (base64 of release.jks), KS_PASS, KS_ALIAS. Build: gradle bundleRelease -> app/build/outputs/bundle/release/app-release.aab
3. Play Console: upload the .aab, enable Play App Signing, fill the Data safety form (no data collected), host PRIVACY_POLICY.md at a public URL.
4. Declarations: foreground service types (mediaProjection, specialUse "overlay") with a short demo video; justify SYSTEM_ALERT_WINDOW (floating FPS pill/menu).
5. Listing: icon 512x512, feature graphic 1024x500, at least 2 phone screenshots, short and full description.
6. New personal developer accounts must run a closed test (12+ testers, 14 days) before production.
