package com.nova.client
import android.content.Context
import android.graphics.*
import android.view.View
import kotlin.math.*

class BG(c: Context, var mode: String) : View(c) {
    private val d = c.resources.displayMetrics.density
    private val pa = Paint(Paint.ANTI_ALIAS_FLAG)
    private val rnd = java.util.Random()
    private class Pt(var x: Float, var y: Float, var vx: Float, var vy: Float, var s: Float, var a: Float, var b: Float, var c: Int)
    private val pts = ArrayList<Pt>()
    private var t = 0f
    private val pal = intArrayOf(0xFF5B6CFF.toInt(), 0xFFFF4D6D.toInt(), 0xFF22C55E.toInt(), 0xFFF59E0B.toInt(), 0xFF06B6D4.toInt(), 0xFFA855F7.toInt())
    private val CV = Array(8) { floatArrayOf(if ((it and 1) == 0) -1f else 1f, if ((it and 2) == 0) -1f else 1f, if ((it and 4) == 0) -1f else 1f) }
    private val CE = ArrayList<IntArray>().apply { for (i in 0..7) for (b in intArrayOf(1, 2, 4)) if ((i and b) == 0) add(intArrayOf(i, i or b)) }
    private val TV = arrayOf(floatArrayOf(1f, 1f, 1f), floatArrayOf(1f, -1f, -1f), floatArrayOf(-1f, 1f, -1f), floatArrayOf(-1f, -1f, 1f))
    private val TE = ArrayList<IntArray>().apply { for (i in 0..3) for (j in i + 1..3) add(intArrayOf(i, j)) }
    private val YV = Array(16) { val an = (it % 8) * PI.toFloat() / 4f; floatArrayOf(cos(an), if (it < 8) -1.2f else 1.2f, sin(an)) }
    private val YE = ArrayList<IntArray>().apply { for (k in 0..7) { add(intArrayOf(k, (k + 1) % 8)); add(intArrayOf(k + 8, (k + 1) % 8 + 8)); add(intArrayOf(k, k + 8)) } }

    fun setMode(m: String) { if (m == mode && pts.isNotEmpty()) return; mode = m; fillPts() }
    private fun r(a: Float, b: Float) = a + rnd.nextFloat() * (b - a)
    private fun al(c: Int, a: Int) = Color.argb(a, Color.red(c), Color.green(c), Color.blue(c))
    private fun sk(c: Int, a: Int) { pa.style = Paint.Style.STROKE; pa.color = al(c, a) }
    private fun fl(c: Int, a: Int) { pa.style = Paint.Style.FILL; pa.color = al(c, a) }
    private fun fillPts() {
        pts.clear(); if (width == 0) return
        val n = when (mode) { "rain" -> 80; "wind" -> 30; "fog" -> 8; "galaxy" -> 260; "planets" -> 6; "space" -> 130; "cubes", "triangles", "cylinders" -> 12; else -> 55 }
        repeat(n) { pts.add(Pt(r(0f, width.toFloat()), r(0f, height.toFloat()), r(-.6f, .6f), r(-.6f, .6f), r(1f, 3f), r(0f, 6.28f), r(0f, 6.28f), pal[rnd.nextInt(6)])) }
    }
    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) { fillPts() }
    private fun mv(p: Pt, w: Float, h: Float, k: Float) {
        p.x += p.vx * k * d; p.y += p.vy * k * d
        val m = 40 * d
        if (p.x < -m) p.x = w + m; if (p.x > w + m) p.x = -m; if (p.y < -m) p.y = h + m; if (p.y > h + m) p.y = -m
    }
    private fun sh3(cv: Canvas, p: Pt) {
        val V = when (mode) { "cubes" -> CV; "triangles" -> TV; else -> YV }
        val E = when (mode) { "cubes" -> CE; "triangles" -> TE; else -> YE }
        val ca = cos(p.a); val sa = sin(p.a); val cb = cos(p.b); val sb = sin(p.b); val sz = (10 + p.s * 8) * d
        val q = Array(V.size) { i ->
            val v = V[i]; val x1 = v[0] * ca + v[2] * sa; val z1 = -v[0] * sa + v[2] * ca
            val y2 = v[1] * cb - z1 * sb; val z2 = v[1] * sb + z1 * cb; val f = 1f / (1f + z2 * 0.22f)
            floatArrayOf(p.x + x1 * sz * f, p.y + y2 * sz * f)
        }
        sk(P.accent, 180)
        for (e in E) cv.drawLine(q[e[0]][0], q[e[0]][1], q[e[1]][0], q[e[1]][1], pa)
    }
    override fun onDraw(cv: Canvas) {
        if (pts.isEmpty()) return
        t += 0.016f
        val ac = P.accent; val w = width.toFloat(); val h = height.toFloat(); val cx = w / 2; val cy = h / 2
        pa.strokeWidth = d * 1.2f
        for (p in pts) {
            when (mode) {
                "rain" -> { val v = (9 + p.s * 4) * d; p.y += v; p.x -= 2 * d; if (p.y > h) { p.y = -20 * d; p.x = r(0f, w + 40 * d) }; sk(ac, 120); cv.drawLine(p.x, p.y, p.x + 3 * d, p.y - v * 1.6f, pa) }
                "wind" -> { p.x += (6 + p.s * 3) * d; if (p.x > w + 90 * d) p.x = -90 * d; val yy = p.y + sin(t * 2 + p.a) * 12 * d; sk(ac, 100); cv.drawLine(p.x, yy, p.x - p.s * 30 * d, yy, pa) }
                "fog" -> { mv(p, w, h, 0.3f); fl(ac, 28); cv.drawCircle(p.x, p.y, (80 + p.s * 40) * d, pa) }
                "space" -> {
                    val dx = p.x - cx; val dy = p.y - cy
                    p.x += dx * 0.012f * p.s; p.y += dy * 0.012f * p.s
                    if (abs(dx) > cx || abs(dy) > cy || (abs(dx) < 1 && abs(dy) < 1)) { p.x = cx + r(-30f, 30f) * d; p.y = cy + r(-30f, 30f) * d }
                    fl(ac, 220); cv.drawCircle(p.x, p.y, (0.8f + hypot(dx, dy) / w * 3f) * d, pa)
                }
                "galaxy" -> {
                    val f = p.b / 6.28f; val arm = if (p.vx > 0) 0f else PI.toFloat()
                    val an = arm + p.vy * 0.5f + f * 5f + t * 0.25f * (1.3f - f); val rad = f * 0.5f * min(w, h) * 1.6f
                    fl(p.c, 200); cv.drawCircle(cx + rad * cos(an), cy + rad * sin(an) * 0.6f, (0.8f + p.s * 0.5f) * d, pa)
                }
                "planets" -> {
                    mv(p, w, h, 0.25f); val R = (18 + p.s * 14) * d
                    fl(p.c, 230); cv.drawCircle(p.x, p.y, R, pa)
                    fl(Color.BLACK, 45); cv.drawCircle(p.x + R * .15f, p.y + R * .1f, R * .78f, pa)
                    if (p.s > 2f) { sk(p.c, 170); cv.drawOval(RectF(p.x - R * 1.7f, p.y - R * .4f, p.x + R * 1.7f, p.y + R * .4f), pa) }
                }
                "cubes", "triangles", "cylinders" -> { mv(p, w, h, 0.6f); p.a += p.vx * 0.03f + 0.01f; p.b += p.vy * 0.03f + 0.008f; sh3(cv, p) }
                "circles" -> { mv(p, w, h, 0.5f); sk(ac, 120); cv.drawCircle(p.x, p.y, (8 + p.s * 7) * d * (1f + 0.12f * sin(t * 2 + p.a)), pa) }
                "starshapes" -> {
                    mv(p, w, h, 0.5f); val R = (7 + p.s * 5) * d; val path = Path()
                    for (i in 0..9) {
                        val q = if (i % 2 == 0) R else R * 0.45f; val an = p.a + t * 0.5f + i * PI.toFloat() / 5f
                        val x = p.x + q * cos(an); val y = p.y + q * sin(an)
                        if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
                    }
                    path.close(); fl(ac, 160); cv.drawPath(path, pa)
                }
                else -> { mv(p, w, h, 0.5f); fl(ac, 200); cv.drawCircle(p.x, p.y, p.s * d * 0.9f, pa) }
            }
        }
        if (mode == "stars") {
            val md = 110 * d
            for (i in pts.indices) for (j in i + 1 until pts.size) {
                val dd = hypot(pts[i].x - pts[j].x, pts[i].y - pts[j].y)
                if (dd < md) { sk(ac, (160 * (1 - dd / md)).toInt()); cv.drawLine(pts[i].x, pts[i].y, pts[j].x, pts[j].y, pa) }
            }
        }
        postInvalidateOnAnimation()
    }
}
