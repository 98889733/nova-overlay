package com.nova.client
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.Image
import android.media.ImageReader
import android.media.MediaRecorder
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.*
import android.widget.Toast
import java.io.File

class CaptureService : Service() {
    companion object { var inst: CaptureService? = null }
    private var mp: MediaProjection? = null; private var vd: VirtualDisplay? = null; private var ir: ImageReader? = null
    private var last: Image? = null; private var mr: MediaRecorder? = null
    var recording = false
    private val h = Handler(Looper.getMainLooper())
    private var w = 0; private var hh = 0
    override fun onBind(i: Intent?): IBinder? = null
    private fun toast(t: String) = Toast.makeText(this, t, Toast.LENGTH_SHORT).show()
    override fun onStartCommand(i: Intent?, f: Int, s: Int): Int {
        if (i == null) { stopSelf(); return START_NOT_STICKY }
        startForeground(2, notif(this, "Захват экрана готов"), ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
        val data = i.getParcelableExtra<Intent>("data")
        if (data == null) { stopSelf(); return START_NOT_STICKY }
        val p = getSystemService(MediaProjectionManager::class.java).getMediaProjection(i.getIntExtra("code", -1), data)
        mp = p
        p.registerCallback(object : MediaProjection.Callback() { override fun onStop() { stopRec(); stopSelf() } }, h)
        val dm = resources.displayMetrics; w = dm.widthPixels / 2 * 2; hh = dm.heightPixels / 2 * 2
        val r = newReader()
        vd = p.createVirtualDisplay("nova", w, hh, dm.densityDpi, DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, r.surface, null, null)
        inst = this
        return START_NOT_STICKY
    }
    private fun newReader(): ImageReader {
        val r = ImageReader.newInstance(w, hh, PixelFormat.RGBA_8888, 3); ir = r
        r.setOnImageAvailableListener({ x -> val im = x.acquireLatestImage(); if (im != null) { last?.close(); last = im } }, h)
        return r
    }
    override fun onConfigurationChanged(n: android.content.res.Configuration) {
        super.onConfigurationChanged(n)
        if (recording) return
        val dm = resources.displayMetrics; val nw = dm.widthPixels / 2 * 2; val nh = dm.heightPixels / 2 * 2
        if (nw == w && nh == hh) return
        w = nw; hh = nh; last?.close(); last = null
        val old = ir; val r = newReader()
        vd?.resize(w, hh, dm.densityDpi); vd?.setSurface(r.surface); old?.close()
    }
    fun shot() {
        val im = last ?: run { toast("Нет кадра, попробуй ещё раз"); return }
        try {
            val p = im.planes[0]; p.buffer.rewind()
            val bmp = Bitmap.createBitmap(p.rowStride / p.pixelStride, hh, Bitmap.Config.ARGB_8888); bmp.copyPixelsFromBuffer(p.buffer)
            val out = Bitmap.createBitmap(bmp, 0, 0, w, hh)
            File(dir("shots"), ts() + ".png").outputStream().use { out.compress(Bitmap.CompressFormat.PNG, 100, it) }
            toast("Скриншот сохранён"); OverlayService.inst?.shotThumb(out); Q.done("shot")
        } catch (e: Exception) { toast("Ошибка скриншота") }
    }
    fun startRec() {
        if (recording) return
        val f = File(dir("videos"), ts() + ".mp4")
        val r = if (Build.VERSION.SDK_INT >= 31) MediaRecorder(this) else @Suppress("DEPRECATION") MediaRecorder()
        r.setVideoSource(MediaRecorder.VideoSource.SURFACE); r.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4)
        r.setVideoEncoder(MediaRecorder.VideoEncoder.H264); r.setVideoSize(w, hh); r.setVideoFrameRate(30)
        r.setVideoEncodingBitRate(8_000_000); r.setOutputFile(f.absolutePath)
        try { r.prepare() } catch (e: Exception) { toast("Ошибка записи"); return }
        vd?.setSurface(r.surface); r.start(); mr = r; recording = true; toast("Запись пошла"); OverlayService.inst?.recBadge(true); Q.done("rec")
    }
    fun stopRec() {
        if (!recording) return
        recording = false; OverlayService.inst?.recBadge(false)
        try { mr?.stop() } catch (e: Exception) {}
        mr?.release(); mr = null; vd?.setSurface(ir?.surface); toast("Видео сохранено")
    }
    override fun onDestroy() {
        inst = null; stopRec(); vd?.release(); last?.close(); ir?.close(); mp?.stop(); super.onDestroy()
    }
}
