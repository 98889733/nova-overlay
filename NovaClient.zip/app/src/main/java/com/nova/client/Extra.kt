package com.nova.client
import android.app.ActivityManager
import android.content.*
import android.graphics.*
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.os.Build
import android.os.Environment
import android.os.StatFs
import android.provider.Settings
import android.view.*
import android.widget.*

object Sc { val m = HashMap<String, Int>() }
fun Context.sk(k: String) = (if (this is android.app.Activity) "a" else "o") + k
fun HorizontalScrollView.keep(k: String) {
    isHorizontalScrollBarEnabled = false
    setOnScrollChangeListener { _, x, _, _, _ -> Sc.m[k] = x }
    addOnLayoutChangeListener(object : View.OnLayoutChangeListener {
        override fun onLayoutChange(v: View?, l: Int, t: Int, r: Int, b: Int, a: Int, d: Int, e: Int, f: Int) { removeOnLayoutChangeListener(this); scrollTo(Sc.m[k] ?: 0, 0) }
    })
}

class Wheel(c: Context, col: Int, val done: (Int) -> Unit) : View(c) {
    val hsv = FloatArray(3).also { Color.colorToHSV(col, it) }
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    fun setV(v: Float) { hsv[2] = v.coerceIn(0.05f, 1f); invalidate(); done(Color.HSVToColor(hsv)) }
    override fun onDraw(cv: Canvas) {
        val cx = width / 2f; val cy = height / 2f; val R = width / 2f - context.dp(10)
        p.style = Paint.Style.FILL
        p.shader = SweepGradient(cx, cy, IntArray(7) { Color.HSVToColor(floatArrayOf(it * 60f, 1f, 1f)) }, null); cv.drawCircle(cx, cy, R, p)
        p.shader = RadialGradient(cx, cy, R, Color.WHITE, 0x00FFFFFF, Shader.TileMode.CLAMP); cv.drawCircle(cx, cy, R, p)
        p.shader = null; p.color = Color.argb(((1 - hsv[2]) * 255).toInt(), 0, 0, 0); cv.drawCircle(cx, cy, R, p)
        val a = Math.toRadians(hsv[0].toDouble()); val x = cx + (hsv[1] * R * Math.cos(a)).toFloat(); val y = cy + (hsv[1] * R * Math.sin(a)).toFloat()
        p.style = Paint.Style.STROKE; p.strokeWidth = context.dp(3).toFloat(); p.color = Color.WHITE; cv.drawCircle(x, y, context.dp(9).toFloat(), p)
        p.strokeWidth = context.dp(1).toFloat(); p.color = Color.BLACK; cv.drawCircle(x, y, context.dp(10).toFloat(), p)
    }
    override fun onTouchEvent(e: MotionEvent): Boolean {
        parent?.requestDisallowInterceptTouchEvent(true)
        val cx = width / 2f; val cy = height / 2f; val R = width / 2f - context.dp(10); val dx = e.x - cx; val dy = e.y - cy
        hsv[0] = ((Math.toDegrees(Math.atan2(dy.toDouble(), dx.toDouble())) + 360) % 360).toFloat()
        hsv[1] = minOf(1f, Math.hypot(dx.toDouble(), dy.toDouble()).toFloat() / R)
        invalidate(); if (e.action == MotionEvent.ACTION_UP) done(Color.HSVToColor(hsv)); return true
    }
}
fun Context.pickerView(apply: () -> Unit): View {
    val tg = P.str("pickT", "acc")
    val cur = when (tg) { "acc" -> P.accent; "ptx" -> P.fg(); else -> P.bg() }
    val w = Wheel(this, cur) { c -> P.putI(tg, c); apply() }
    val sb = SeekBar(this).apply {
        max = 100; progress = (w.hsv[2] * 100).toInt()
        setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, u: Boolean) {}
            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) { w.setV(progress / 100f) }
        })
    }
    return LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        addView(chipRow(listOf("acc" to "Акцент", "ptx" to "Текст", "pbg" to "Фон"), tg, "pick") { P.putS("pickT", it); apply() })
        addView(LinearLayout(context).apply { gravity = Gravity.CENTER; addView(w, LinearLayout.LayoutParams(dp(240), dp(240))) }, lp(6))
        addView(tv("Яркость", 12f, P.sub()), lp(4)); addView(sb, lp(0))
    }
}
fun Context.sw(t: String, k: String, a: () -> Unit = {}) = Switch(this).apply {
    text = t; setTextColor(P.fg()); isChecked = P.sp.getBoolean(k, false); setOnCheckedChangeListener { _, b -> P.putB(k, b); a() }
}
fun Context.seek(k: String, lo: Int, hi: Int, def: Int, a: () -> Unit) = SeekBar(this).apply {
    max = hi - lo; progress = P.int(k, def) - lo
    setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
        override fun onProgressChanged(s: SeekBar?, p: Int, u: Boolean) {}
        override fun onStartTrackingTouch(s: SeekBar?) {}
        override fun onStopTrackingTouch(s: SeekBar?) { P.putI(k, progress + lo); a() }
    })
}
fun Context.settingsView(apply: () -> Unit): View {
    val a = { OverlayService.inst?.restyle(); apply() }
    val dk = Switch(this).apply {
        text = "Тёмная тема"; setTextColor(P.fg()); isChecked = P.dark
        setOnCheckedChangeListener { _, b -> P.putB("dark", b); P.putI("pbg", 0); P.putI("ptx", 0); a() }
    }
    return stack(dk,
        tv("Акцентный цвет", 13f, P.sub()), colorRow(ACC, P.accent, "acc") { P.putI("acc", it); a() },
        tv("Цвет текста (A — авто)", 13f, P.sub()), colorRow(TXT, P.int("ptx", 0), "ptx") { P.putI("ptx", it); a() },
        tv("Цвет фона (A — авто)", 13f, P.sub()), colorRow(PBG, P.int("pbg", 0), "pbg") { P.putI("pbg", it); a() },
        tv("Любой цвет — крути круг", 13f, P.sub()), pickerView(a),
        tv("Фон плавающего меню", 13f, P.sub()), chipRow(MODES, P.str("bgM", "stars"), "bgM") { P.putS("bgM", it); a() },
        tv("Фон приложения", 13f, P.sub()), chipRow(MODES, P.str("bgA", "stars"), "bgA") { P.putS("bgA", it); a() },
        tv("Плашка FPS", 13f, P.sub()), sw("Показывать время", "pt", a), sw("Показывать заряд", "pb", a),
        tv("Прозрачность плашки", 13f, P.sub()), seek("pa", 30, 100, 96, a),
        tv("Система", 13f, P.sub()), sw("Запускать меню при включении телефона", "boot"),
        btn("Сбросить настройки", false) {
            val ap = P.str("apps", "org.telegram.messenger"); P.sp.edit().clear().putString("apps", ap).apply(); a()
        })
}

fun batLevel(c: Context): Int {
    val i = c.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
    val l = i?.getIntExtra("level", -1) ?: -1; val s = i?.getIntExtra("scale", 100) ?: 100
    return if (l < 0) 0 else l * 100 / s
}
fun liveInfo(c: Context): String {
    val rt = Runtime.getRuntime(); val mem = (rt.totalMemory() - rt.freeMemory()) / 1048576
    val t0 = OverlayService.t0
    if (OverlayService.inst == null || t0 == 0L) return "Меню не запущено\nПамять приложения: $mem МБ"
    val mins = ((System.currentTimeMillis() - t0) / 60000).toInt(); val dl = OverlayService.l0 - batLevel(c)
    val rate = if (mins >= 10 && dl > 0) "\nРасход телефона: %.1f %%/ч".format(dl * 60f / mins) else ""
    return "Меню работает: $mins мин\nЗаряд с запуска: " + (if (dl > 0) "-$dl%" else "без изменений") + rate +
        "\nПамять приложения: $mem МБ\nAndroid не показывает расход отдельного приложения, цифры — убыль заряда всего телефона."
}
fun devInfo(c: Context): String {
    val mi = ActivityManager.MemoryInfo(); c.getSystemService(ActivityManager::class.java).getMemoryInfo(mi)
    val st = StatFs(Environment.getDataDirectory().path)
    val bi = c.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
    val temp = (bi?.getIntExtra("temperature", 0) ?: 0) / 10f; val volt = bi?.getIntExtra("voltage", 0) ?: 0
    @Suppress("DEPRECATION") val hz = c.getSystemService(WindowManager::class.java).defaultDisplay.refreshRate
    val dm = c.resources.displayMetrics
    return "Модель: ${Build.MANUFACTURER} ${Build.MODEL}\nAndroid ${Build.VERSION.RELEASE} (API ${Build.VERSION.SDK_INT})\n" +
        "Процессор: ${Runtime.getRuntime().availableProcessors()} ядер, ${Build.HARDWARE}\nЭкран: ${dm.widthPixels}x${dm.heightPixels}, %.0f Гц\n".format(hz) +
        "ОЗУ: свободно ${mi.availMem / 1048576} из ${mi.totalMem / 1048576} МБ\nПамять: свободно %.1f из %.1f ГБ\n".format(st.availableBytes / 1e9, st.totalBytes / 1e9) +
        "Заряд: ${batLevel(c)}%, ${"%.1f".format(temp)}°C, $volt мВ"
}
fun sysPage(c: Context): View {
    val live = c.tv("", 13f).apply { setLineSpacing(0f, 1.2f) }; tick(live) { liveInfo(c) }
    val dev = c.tv("", 13f).apply { setLineSpacing(0f, 1.2f) }; tick(dev) { devInfo(c) }
    return c.stack(c.card(c.tv("Это приложение", 13f, P.sub()), live), c.card(c.tv("Телефон", 13f, P.sub()), dev))
}
var torch = false
fun flash(c: Context) {
    try {
        val cm = c.getSystemService(CameraManager::class.java)
        val id = cm.cameraIdList.firstOrNull { cm.getCameraCharacteristics(it).get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true } ?: return
        torch = !torch; cm.setTorchMode(id, torch)
    } catch (e: Exception) { Toast.makeText(c, "Фонарик недоступен", Toast.LENGTH_SHORT).show() }
}
class BootReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        P.init(c)
        if (P.sp.getBoolean("boot", false) && Settings.canDrawOverlays(c)) c.startForegroundService(Intent(c, OverlayService::class.java))
    }
}
