package com.nova.client
import android.content.Context
import android.graphics.*
import android.os.Handler
import android.os.Looper
import android.view.*
import android.widget.*
import java.util.Random

class Catch(c: Context) : View(c) {
    private class S(var x: Float, var y: Float, var v: Float, var r: Float)
    private val list = ArrayList<S>(); private val rnd = Random(); private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private var score = 0; private var left = 0f; private var run = false; private var best = P.int("catch_best", 0)
    private val d = c.resources.displayMetrics.density
    override fun onMeasure(w: Int, h: Int) { setMeasuredDimension(MeasureSpec.getSize(w), context.dp(300)) }
    override fun onDraw(cv: Canvas) {
        p.style = Paint.Style.FILL; p.color = P.card(); p.textAlign = Paint.Align.CENTER
        cv.drawRoundRect(0f, 0f, width.toFloat(), height.toFloat(), 24f, 24f, p)
        if (!run) {
            p.color = P.fg(); p.textSize = 18 * d; cv.drawText("Лови звёзды", width / 2f, height / 2f - 20 * d, p)
            p.textSize = 13 * d; p.color = P.sub(); cv.drawText("Нажми, чтобы начать · рекорд $best", width / 2f, height / 2f + 10 * d, p)
            if (score > 0) cv.drawText("Последний счёт: $score", width / 2f, height / 2f + 34 * d, p)
            return
        }
        left -= 0.016f
        if (rnd.nextInt(100) < 5) list.add(S(rnd.nextFloat() * (width - 40 * d) + 20 * d, -20 * d, (2f + rnd.nextFloat() * 3f) * d, (14 + rnd.nextInt(10)) * d))
        val it2 = list.iterator()
        while (it2.hasNext()) { val s = it2.next(); s.y += s.v; if (s.y > height + 30 * d) it2.remove() }
        for (s in list) { p.color = P.accent; cv.drawCircle(s.x, s.y, s.r, p); p.color = Color.WHITE; cv.drawCircle(s.x, s.y, s.r * 0.4f, p) }
        p.color = P.fg(); p.textSize = 14 * d; p.textAlign = Paint.Align.LEFT; cv.drawText("Счёт $score", 12 * d, 22 * d, p)
        p.textAlign = Paint.Align.RIGHT; cv.drawText("%.0f c".format(left), width - 12 * d, 22 * d, p)
        if (left <= 0f) finish() else postInvalidateOnAnimation()
    }
    private fun finish() {
        run = false; if (score > best) { best = score; P.putI("catch_best", best) }
        val xp = minOf(score / 4, 5); if (xp > 0) Xp.add(xp.toLong())
        Q.done("game"); Xp.say("Счёт: $score" + if (xp > 0) " · +$xp XP" else "")
        invalidate()
    }
    override fun onTouchEvent(e: MotionEvent): Boolean {
        if (e.action != MotionEvent.ACTION_DOWN) return true
        if (!run) { list.clear(); score = 0; left = 30f; run = true; invalidate(); return true }
        val s = list.minByOrNull { Math.hypot((it.x - e.x).toDouble(), (it.y - e.y).toDouble()) }
        if (s != null && Math.hypot((s.x - e.x).toDouble(), (s.y - e.y).toDouble()) < s.r * 1.8f) { list.remove(s); score++ }
        return true
    }
}

open class Pad(c: Context, first: String) : TextView(c) {
    init { gravity = Gravity.CENTER; textSize = 16f; setTextColor(Color.WHITE); typeface = Typeface.DEFAULT_BOLD; minimumHeight = c.dp(140); show(first, P.accent) }
    fun show(t: String, col: Int) { text = t; background = rr(col, context.dp(16).toFloat()) }
}
class React(c: Context) : Pad(c, "Тест реакции\nНажми, чтобы начать") {
    private val h = Handler(Looper.getMainLooper()); private var st = 0; private var t0 = 0L; private var r: Runnable? = null
    override fun onTouchEvent(e: MotionEvent): Boolean {
        if (e.action != MotionEvent.ACTION_DOWN) return true
        when (st) {
            0 -> {
                st = 1; show("Жди зелёного...", 0xFFC0392B.toInt())
                val rn = Runnable { st = 2; t0 = System.currentTimeMillis(); show("ЖМИ!", 0xFF1E9E4B.toInt()) }
                r = rn; h.postDelayed(rn, 1000L + Random().nextInt(3000))
            }
            1 -> { r?.let { h.removeCallbacks(it) }; st = 0; show("Слишком рано!\nНажми, чтобы повторить", 0xFFC0392B.toInt()) }
            else -> {
                val ms = System.currentTimeMillis() - t0; st = 0
                val best = P.int("react_best", 9999); if (ms < best) P.putI("react_best", ms.toInt())
                show("$ms мс\nРекорд: ${minOf(best.toLong(), ms)} мс\nЕщё раз — нажми", P.accent)
                Q.done("game"); if (ms < 350) Xp.add(2)
            }
        }
        return true
    }
}
class Cps(c: Context) : Pad(c, "Тест кликов\nЖми как можно быстрее 5 секунд") {
    private var n = 0; private var run = false; private val h = Handler(Looper.getMainLooper())
    override fun onTouchEvent(e: MotionEvent): Boolean {
        if (e.action != MotionEvent.ACTION_DOWN) return true
        if (!run) {
            run = true; n = 0
            h.postDelayed({
                run = false; val cps = n / 5.0; val best = P.int("cps_best", 0)
                if (cps * 10 > best) P.putI("cps_best", (cps * 10).toInt())
                show("%.1f кликов/сек\nРекорд: %.1f\nЕщё раз — нажми".format(cps, maxOf(best / 10.0, cps)), P.accent); Q.done("cps")
            }, 5000)
        }
        n++; if (run) text = "$n"
        return true
    }
}
fun funCard(c: Context): View {
    val out = c.tv("Нажми кнопку", 16f, P.accent, true).apply { gravity = Gravity.CENTER; setPadding(0, c.dp(8), 0, c.dp(8)) }
    val ans = listOf("Да", "Нет", "Скорее да", "Скорее нет", "Спроси позже", "Определённо да", "Даже не думай", "Звёзды говорят «да»")
    val rnd = Random()
    return c.card(out, c.row3(c.btn("Кубик", false) { out.text = "Выпало: ${rnd.nextInt(6) + 1}" },
        c.btn("Монетка", false) { out.text = if (rnd.nextBoolean()) "Орёл" else "Решка" },
        c.btn("Шар судьбы", false) { out.text = ans[rnd.nextInt(ans.size)] }))
}
val GTABS = listOf("Звёзды", "Реакция", "Клики", "Прикол")
fun gamesPage(c: Context, sh: Shell): View {
    val body: View = when (UiS.gtab) {
        0 -> c.card(c.tv("Лови звёзды · 30 секунд", 13f, P.sub()), Catch(c))
        1 -> c.card(c.tv("Тест реакции", 13f, P.sub()), React(c))
        2 -> c.card(c.tv("Тест кликов (CPS)", 13f, P.sub()), Cps(c))
        else -> funCard(c)
    }
    return c.stack(c.chipRow(GTABS.mapIndexed { i, n -> "$i" to n }, "${UiS.gtab}", "gtab") { UiS.gtab = it.toInt(); UiS.top = true; sh.rebuild() },
        body, c.tv("За игры и задания дают опыт. Заходи за уровнями!", 12f, P.sub()))
}
