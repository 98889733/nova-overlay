package com.nova.client
import android.content.Context
import android.graphics.*
import android.graphics.drawable.Drawable
import android.os.SystemClock
import android.view.*
import android.widget.*
import kotlin.math.sin

// Фон кнопки: градиент, мягкое пульсирующее свечение и бегущая градиентная рамка.
class GlowDrawable(val rad: Float, val col: Int, val glow: Float) : Drawable() {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG); private val b = RectF(); private var t = 0f
    private val tickRun = Runnable { invalidateSelf() }
    override fun draw(cv: Canvas) {
        val r = bounds; if (r.width() <= 0) return
        val off = P.sp.getBoolean("noglow", false); val g = if (off) 0f else glow
        b.set(r.left + g, r.top + g, r.right - g, r.bottom - g); t += 0.05f
        p.style = Paint.Style.FILL; p.shader = null; p.color = col
        if (!off) { val pulse = 0.55f + 0.45f * sin(t * 2); p.setShadowLayer(g * (0.8f + 0.5f * pulse), 0f, 0f, withA(col, (70 + 150 * pulse).toInt())) }
        cv.drawRoundRect(b, rad, rad, p); p.clearShadowLayer()
        p.shader = LinearGradient(b.left, b.top, b.right, b.bottom, P.mix(col, Color.WHITE, 0.28f), P.mix(col, Color.BLACK, 0.18f), Shader.TileMode.CLAMP)
        cv.drawRoundRect(b, rad, rad, p); p.shader = null
        if (!off) {
            val hsv = FloatArray(3); Color.colorToHSV(col, hsv); hsv[0] = (hsv[0] + 55f) % 360f; val c2 = Color.HSVToColor(hsv)
            val sh = SweepGradient(b.centerX(), b.centerY(), intArrayOf(Color.WHITE, c2, col, Color.WHITE), null)
            val m = Matrix(); m.setRotate(t * 50f, b.centerX(), b.centerY()); sh.setLocalMatrix(m)
            p.style = Paint.Style.STROKE; p.strokeWidth = 2.5f; p.shader = sh
            cv.drawRoundRect(b, rad, rad, p); p.shader = null
            scheduleSelf(tickRun, SystemClock.uptimeMillis() + 40)
        }
    }
    override fun setAlpha(a: Int) {}
    override fun setColorFilter(f: ColorFilter?) {}
    @Suppress("DEPRECATION")
    override fun getOpacity() = PixelFormat.TRANSLUCENT
}

// Простые значки-картинки, чтобы кнопки были понятны без чтения.
class Ico(c: Context, val kind: String, val col: Int = P.fg(), val sizeDp: Int = 22) : View(c) {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    override fun onMeasure(w: Int, h: Int) { val s = context.dp(sizeDp); setMeasuredDimension(s, s) }
    override fun onDraw(cv: Canvas) {
        val u = width / 24f; val cx = width / 2f; val cy = height / 2f
        p.shader = null; p.style = Paint.Style.STROKE; p.strokeWidth = 2f * u; p.color = col; p.strokeCap = Paint.Cap.ROUND; p.strokeJoin = Paint.Join.ROUND
        when (kind) {
            "shot" -> {
                cv.drawRoundRect(RectF(3 * u, 7 * u, 21 * u, 20 * u), 3 * u, 3 * u, p); cv.drawCircle(cx, 13.5f * u, 3.5f * u, p)
                cv.drawLine(8 * u, 7 * u, 9.5f * u, 4 * u, p); cv.drawLine(9.5f * u, 4 * u, 14.5f * u, 4 * u, p); cv.drawLine(14.5f * u, 4 * u, 16 * u, 7 * u, p)
            }
            "rec" -> { cv.drawCircle(cx, cy, 9 * u, p); p.style = Paint.Style.FILL; p.color = 0xFFE5242B.toInt(); cv.drawCircle(cx, cy, 4.5f * u, p) }
            "torch" -> {
                val pa = Path(); pa.moveTo(8 * u, 3 * u); pa.lineTo(16 * u, 3 * u); pa.lineTo(14 * u, 9 * u); pa.lineTo(10 * u, 9 * u); pa.close(); cv.drawPath(pa, p)
                cv.drawRoundRect(RectF(10 * u, 9 * u, 14 * u, 21 * u), 1.5f * u, 1.5f * u, p)
            }
            "open" -> { p.style = Paint.Style.FILL; val pa = Path(); pa.moveTo(8 * u, 5 * u); pa.lineTo(19 * u, 12 * u); pa.lineTo(8 * u, 19 * u); pa.close(); cv.drawPath(pa, p) }
            "info" -> { cv.drawCircle(cx, cy, 9 * u, p); cv.drawLine(cx, 11 * u, cx, 17 * u, p); p.style = Paint.Style.FILL; cv.drawCircle(cx, 7.5f * u, 1.3f * u, p) }
            "trash" -> {
                cv.drawLine(4 * u, 6.5f * u, 20 * u, 6.5f * u, p); cv.drawLine(9 * u, 6.5f * u, 9 * u, 4 * u, p); cv.drawLine(9 * u, 4 * u, 15 * u, 4 * u, p); cv.drawLine(15 * u, 4 * u, 15 * u, 6.5f * u, p)
                val pa = Path(); pa.moveTo(6 * u, 6.5f * u); pa.lineTo(7 * u, 20 * u); pa.lineTo(17 * u, 20 * u); pa.lineTo(18 * u, 6.5f * u); cv.drawPath(pa, p)
                cv.drawLine(10.5f * u, 10 * u, 10.5f * u, 17 * u, p); cv.drawLine(13.5f * u, 10 * u, 13.5f * u, 17 * u, p)
            }
            "remove" -> { cv.drawCircle(cx, cy, 9 * u, p); cv.drawLine(8.5f * u, 8.5f * u, 15.5f * u, 15.5f * u, p); cv.drawLine(15.5f * u, 8.5f * u, 8.5f * u, 15.5f * u, p) }
            "pin" -> { cv.drawCircle(cx, 9 * u, 5 * u, p); cv.drawLine(cx, 14 * u, cx, 21 * u, p); p.style = Paint.Style.FILL; cv.drawCircle(cx, 9 * u, 1.6f * u, p) }
            "copy" -> { cv.drawRoundRect(RectF(9 * u, 9 * u, 20 * u, 20 * u), 2.5f * u, 2.5f * u, p); cv.drawRoundRect(RectF(4 * u, 4 * u, 15 * u, 15 * u), 2.5f * u, 2.5f * u, p) }
            "plus" -> { cv.drawLine(cx, 5 * u, cx, 19 * u, p); cv.drawLine(5 * u, cy, 19 * u, cy, p) }
            "back" -> { cv.drawLine(19 * u, cy, 5 * u, cy, p); cv.drawLine(5 * u, cy, 11 * u, 6 * u, p); cv.drawLine(5 * u, cy, 11 * u, 18 * u, p) }
            "apps" -> { for (i in 0..1) for (j in 0..1) cv.drawRoundRect(RectF((4 + i * 9) * u, (4 + j * 9) * u, (11 + i * 9) * u, (11 + j * 9) * u), 2 * u, 2 * u, p) }
            "cross" -> {
                cv.drawCircle(cx, cy, 6 * u, p); cv.drawLine(cx, 2 * u, cx, 8 * u, p); cv.drawLine(cx, 16 * u, cx, 22 * u, p)
                cv.drawLine(2 * u, cy, 8 * u, cy, p); cv.drawLine(16 * u, cy, 22 * u, cy, p)
            }
            "clock" -> { cv.drawCircle(cx, cy, 9 * u, p); cv.drawLine(cx, cy, cx, 6.5f * u, p); cv.drawLine(cx, cy, 16 * u, 14 * u, p) }
            "game" -> {
                cv.drawRoundRect(RectF(2 * u, 7 * u, 22 * u, 18 * u), 5 * u, 5 * u, p); cv.drawLine(7 * u, 10 * u, 7 * u, 15 * u, p); cv.drawLine(4.5f * u, 12.5f * u, 9.5f * u, 12.5f * u, p)
                p.style = Paint.Style.FILL; cv.drawCircle(15.5f * u, 11.5f * u, 1.3f * u, p); cv.drawCircle(18.5f * u, 14 * u, 1.3f * u, p)
            }
            "gear" -> {
                cv.drawCircle(cx, cy, 3.5f * u, p); cv.drawCircle(cx, cy, 6.5f * u, p)
                for (i in 0 until 8) { cv.save(); cv.rotate(i * 45f, cx, cy); cv.drawLine(cx, 2.5f * u, cx, 5.5f * u, p); cv.restore() }
            }
            "phone" -> { cv.drawRoundRect(RectF(7 * u, 2.5f * u, 17 * u, 21.5f * u), 2.5f * u, 2.5f * u, p); cv.drawLine(10.5f * u, 18.5f * u, 13.5f * u, 18.5f * u, p) }
            "home" -> {
                val pa = Path(); pa.moveTo(3 * u, 12 * u); pa.lineTo(cx, 3.5f * u); pa.lineTo(21 * u, 12 * u); cv.drawPath(pa, p)
                val q = Path(); q.moveTo(6 * u, 10.5f * u); q.lineTo(6 * u, 20 * u); q.lineTo(18 * u, 20 * u); q.lineTo(18 * u, 10.5f * u); cv.drawPath(q, p)
            }
            "media" -> {
                cv.drawRoundRect(RectF(3 * u, 4 * u, 21 * u, 20 * u), 3 * u, 3 * u, p)
                val pa = Path(); pa.moveTo(5 * u, 17 * u); pa.lineTo(10 * u, 11 * u); pa.lineTo(14 * u, 15 * u); pa.lineTo(16.5f * u, 12.5f * u); pa.lineTo(19 * u, 17 * u); cv.drawPath(pa, p)
                p.style = Paint.Style.FILL; cv.drawCircle(16 * u, 8.5f * u, 1.5f * u, p)
            }
            "chev" -> { cv.drawLine(6 * u, 9 * u, cx, 15 * u, p); cv.drawLine(cx, 15 * u, 18 * u, 9 * u, p) }
            "logo" -> {
                p.style = Paint.Style.FILL; p.color = col; cv.drawCircle(cx, cy, 11 * u, p)
                p.color = Color.WHITE; p.textAlign = Paint.Align.CENTER; p.textSize = 14 * u; p.typeface = Typeface.DEFAULT_BOLD
                cv.drawText("N", cx, cy - (p.ascent() + p.descent()) / 2, p)
            }
            else -> cv.drawCircle(cx, cy, 4 * u, p)
        }
    }
}
fun Context.ibtn(kind: String, label: String, filled: Boolean = false, f: () -> Unit): View = LinearLayout(this).apply {
    orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER; setPadding(dp(6), dp(10), dp(6), dp(8))
    background = if (filled) GlowDrawable(dp(12).toFloat(), P.accent, dp(3).toFloat()) else rr(P.card(), dp(12).toFloat(), P.mix(P.bg(), P.fg(), 0.1f))
    addView(Ico(context, kind, if (filled) Color.WHITE else P.fg(), 24))
    addView(tv(label, 10.5f, if (filled) Color.WHITE else P.fg(), true).apply { gravity = Gravity.CENTER; maxLines = 1 }, LinearLayout.LayoutParams(-2, -2).apply { topMargin = dp(3) })
    setOnClickListener { f() }
}
fun Context.rbtn(kind: String, label: String, f: () -> Unit): View = LinearLayout(this).apply {
    gravity = Gravity.CENTER; setPadding(dp(14), dp(11), dp(14), dp(11)); background = GlowDrawable(dp(12).toFloat(), P.accent, dp(4).toFloat())
    addView(Ico(context, kind, Color.WHITE, 22)); addView(tv(label, 14f, Color.WHITE, true).apply { setPadding(dp(8), 0, 0, 0) })
    setOnClickListener { f() }
}
fun Context.seekLive(k: String, lo: Int, hi: Int, def: Int, live: () -> Unit) = SeekBar(this).apply {
    max = hi - lo; progress = P.int(k, def) - lo
    setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
        override fun onProgressChanged(s: SeekBar?, p: Int, u: Boolean) { if (u) { P.putI(k, p + lo); live() } }
        override fun onStartTrackingTouch(s: SeekBar?) {}
        override fun onStopTrackingTouch(s: SeekBar?) {}
    })
}
