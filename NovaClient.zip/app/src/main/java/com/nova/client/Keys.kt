package com.nova.client
import android.content.Context
import android.text.InputType
import android.view.*
import android.view.inputmethod.InputMethodManager
import android.widget.*

// Поле ввода: пишешь сам обычной клавиатурой телефона, оформление в стиле приложения.
class KeyPad(c: Context, title: String, masked: Boolean, digitsOnly: Boolean, okLabel: String, caps: Boolean = true, val onOk: (String) -> Unit) : LinearLayout(c) {
    init {
        orientation = VERTICAL
        val et = EditText(c).apply {
            hint = title; setHintTextColor(P.sub()); setTextColor(P.fg()); textSize = 18f; isSingleLine = true
            inputType = if (digitsOnly) InputType.TYPE_CLASS_NUMBER
                else if (masked) InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
                else InputType.TYPE_CLASS_TEXT or (if (caps) InputType.TYPE_TEXT_FLAG_CAP_CHARACTERS else InputType.TYPE_TEXT_FLAG_CAP_SENTENCES)
            background = rr(P.card(), c.dp(12).toFloat(), P.accent); setPadding(c.dp(14), c.dp(12), c.dp(14), c.dp(12))
        }
        et.setOnTouchListener { v, ev ->
            if (ev.action == MotionEvent.ACTION_DOWN && c !is android.app.Activity) {
                OverlayService.inst?.focusable(true)
                v.postDelayed({ v.requestFocus(); c.getSystemService(InputMethodManager::class.java)?.showSoftInput(v, 0) }, 250)
            }
            false
        }
        addView(et, LinearLayout.LayoutParams(-1, -2))
        addView(c.btn(okLabel) {
            val t = et.text.toString()
            c.getSystemService(InputMethodManager::class.java)?.hideSoftInputFromWindow(et.windowToken, 0)
            OverlayService.inst?.focusable(false)
            et.setText(""); onOk(t)
        }, LinearLayout.LayoutParams(-1, -2).apply { topMargin = c.dp(8) })
    }
}
