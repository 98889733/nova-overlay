package com.nova.client
import android.app.Activity
import android.appwidget.AppWidgetManager
import android.content.ComponentName
import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.View
import android.widget.Toast

class MainActivity : Activity() {
    private lateinit var sh: Shell
    override fun onCreate(b: Bundle?) {
        super.onCreate(b); P.init(this); Xp.start(this); Xp.daily()
        if (Build.VERSION.SDK_INT >= 33) requestPermissions(arrayOf(android.Manifest.permission.POST_NOTIFICATIONS), 1)
        sh = Shell(this, "NOVA Client", "bgA", listOf("Главная", "Прицел", "Игры", "Медиа", "Настройки"), 0, null, icons = listOf("home", "cross", "game", "media", "gear")) { i, s ->
            when (i) { 0 -> home(s); 1 -> crossPage(this, s); 2 -> gamesPage(this, s); 3 -> gallery(s); else -> settingsView { s.rebuild() } }
        }
        sh.fitsSystemWindows = true; setContentView(sh)
        if (intent.getBooleanExtra("cap", false)) askCap()
    }
    override fun onConfigurationChanged(n: android.content.res.Configuration) { super.onConfigurationChanged(n); sh.rebuild() }
    override fun onPause() { Xp.visible = false; super.onPause() }
    override fun onNewIntent(i: Intent) { super.onNewIntent(i); setIntent(i); if (i.getBooleanExtra("cap", false)) askCap() }
    @Suppress("DEPRECATION")
    override fun onResume() {
        super.onResume(); Xp.visible = true; sh.rebuild()
        window.statusBarColor = P.bg()
        window.decorView.systemUiVisibility = if (P.fg() == 0xFF16171D.toInt()) View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR else 0
    }
    @Suppress("DEPRECATION")
    private fun askCap() = startActivityForResult(getSystemService(MediaProjectionManager::class.java).createScreenCaptureIntent(), 7)
    @Suppress("DEPRECATION")
    override fun onActivityResult(rc: Int, res: Int, data: Intent?) {
        super.onActivityResult(rc, res, data)
        if (rc == 7 && res == RESULT_OK && data != null) {
            startForegroundService(Intent(this, CaptureService::class.java).putExtra("code", res).putExtra("data", data))
            if (intent.getBooleanExtra("cap", false)) { intent.removeExtra("cap"); moveTaskToBack(true) }
            sh.postDelayed({ sh.rebuild() }, 600)
        }
    }
    private fun home(s: Shell): View {
        val body = if (UiS.htab == 0) homeMain() else phonePage(this, s)
        body.setPadding(0, 0, 0, 0)
        return stack(subTabs(listOf("Обзор", "Телефон"), UiS.htab, "htab") { UiS.htab = it; UiS.top = true; s.rebuild() }, body)
    }
    private fun pinWidget(cls: Class<*>) {
        val m = AppWidgetManager.getInstance(this)
        if (m.isRequestPinAppWidgetSupported) m.requestPinAppWidget(ComponentName(this, cls), null, null)
        else Toast.makeText(this, "Добавь виджет вручную: удерживай рабочий стол → Виджеты → NOVA", Toast.LENGTH_LONG).show()
    }
    private fun homeMain(): View {
        val ov = Settings.canDrawOverlays(this); val cap = CaptureService.inst != null; val run = OverlayService.inst != null
        val lv = Xp.level(); val lo = Xp.base(lv)
        return stack(
            card(tv("Уровень $lv", 20f, P.accent, true), bar((Xp.xp() - lo).toFloat() / (Xp.base(lv + 1) - lo)), tv("${Xp.xp()} XP · 20 XP за каждые 10 минут", 12f, P.sub())),
            card(tv("Быстрый старт", 13f, P.sub()), tv((if (ov) "✓ " else "○ ") + "1. Разрешение «поверх других окон»", 14f, if (ov) P.fg() else P.accent), tv((if (cap) "✓ " else "○ ") + "2. Доступ к записи экрана (для скриншотов)", 14f, if (cap) P.fg() else P.accent), tv((if (run) "✓ " else "○ ") + "3. Плавающее меню запущено", 14f, if (run) P.fg() else P.accent)),
            btn("1. Разрешить поверх окон") { startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))) },
            btn("2. Доступ к записи экрана", false) { askCap() },
            btn(if (run) "Остановить меню" else "Запустить меню") {
                if (run) stopService(Intent(this, OverlayService::class.java))
                else if (!ov) Toast.makeText(this, "Сначала разреши «поверх других окон»", Toast.LENGTH_LONG).show()
                else startForegroundService(Intent(this, OverlayService::class.java))
                sh.postDelayed({ sh.rebuild() }, 500)
            },
            tv("Потом открой любую игру или приложение — плашка с FPS останется сверху.", 12f, P.sub()),
            card(tv("Виджеты на рабочий стол", 13f, P.sub()),
                row3(ibtn("apps", "Панель") { pinWidget(NovaPanelWidget::class.java) }, ibtn("power", "Вкл/Выкл") { pinWidget(NovaToggleWidget::class.java) }, ibtn("clock", "Инфо") { pinWidget(NovaInfoWidget::class.java) }),
                tv("Или удерживай рабочий стол → Виджеты → NOVA. Есть и плитка «NOVA меню» в шторке быстрых настроек.", 11f, P.sub())))
    }
}
