package com.nova.client
import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.provider.Settings
import android.service.quicksettings.Tile
import android.service.quicksettings.TileService
import android.widget.RemoteViews
import android.widget.Toast

const val W_STOP = "com.nova.client.W_STOP"
const val W_SHOT = "com.nova.client.W_SHOT"
const val W_REC = "com.nova.client.W_REC"
const val W_CROSS = "com.nova.client.W_CROSS"
const val W_TORCH = "com.nova.client.W_TORCH"

object NovaWidgets {
    private const val IMM = PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
    private fun act(c: Context, a: String, code: Int): PendingIntent = PendingIntent.getBroadcast(c, code, Intent(c, NovaPanelWidget::class.java).setAction(a), IMM)
    private fun openApp(c: Context): PendingIntent = PendingIntent.getActivity(c, 90, Intent(c, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK), IMM)
    fun togglePI(c: Context): PendingIntent =
        if (OverlayService.inst != null) act(c, W_STOP, 11)
        else if (Settings.canDrawOverlays(c)) PendingIntent.getForegroundService(c, 12, Intent(c, OverlayService::class.java), IMM)
        else openApp(c)
    fun updateAll(c: Context) {
        try {
            P.init(c); val m = AppWidgetManager.getInstance(c)
            val kinds = listOf(NovaPanelWidget::class.java to 0, NovaToggleWidget::class.java to 1, NovaInfoWidget::class.java to 2)
            for ((cls, kind) in kinds) { val ids = m.getAppWidgetIds(ComponentName(c, cls)); if (ids.isNotEmpty()) update(c, m, ids, kind) }
            TileService.requestListeningState(c, ComponentName(c, NovaTile::class.java))
        } catch (e: Exception) {}
    }
    fun update(c: Context, m: AppWidgetManager, ids: IntArray, kind: Int) { for (id in ids) m.updateAppWidget(id, build(c, kind)) }
    private fun build(c: Context, kind: Int): RemoteViews {
        val running = OverlayService.inst != null
        when (kind) {
            0 -> {
                val v = RemoteViews(c.packageName, R.layout.w_panel)
                v.setOnClickPendingIntent(R.id.b_menu, togglePI(c)); v.setOnClickPendingIntent(R.id.b_shot, act(c, W_SHOT, 13))
                v.setOnClickPendingIntent(R.id.b_rec, act(c, W_REC, 14)); v.setOnClickPendingIntent(R.id.b_cross, act(c, W_CROSS, 15))
                v.setOnClickPendingIntent(R.id.b_torch, act(c, W_TORCH, 16))
                v.setInt(R.id.b_menu, "setColorFilter", if (running) 0xFF22C55E.toInt() else Color.WHITE)
                return v
            }
            1 -> {
                val v = RemoteViews(c.packageName, R.layout.w_toggle)
                v.setOnClickPendingIntent(R.id.w_root, togglePI(c))
                v.setTextViewText(R.id.t_state, if (running) "ВКЛ" else "ВЫКЛ")
                v.setInt(R.id.b_tog, "setColorFilter", if (running) 0xFF22C55E.toInt() else Color.WHITE)
                return v
            }
            else -> {
                val v = RemoteViews(c.packageName, R.layout.w_info)
                v.setTextViewText(R.id.i_bat, "Заряд " + battery(c) + " · ур. " + Xp.level())
                v.setOnClickPendingIntent(R.id.w_root, openApp(c))
                return v
            }
        }
    }
    fun needMenu(c: Context) { Toast.makeText(c, "Сначала включи меню NOVA", Toast.LENGTH_SHORT).show() }
}

open class NovaWidget(private val kind: Int) : AppWidgetProvider() {
    override fun onUpdate(c: Context, m: AppWidgetManager, ids: IntArray) { P.init(c); NovaWidgets.update(c, m, ids, kind) }
    override fun onReceive(c: Context, i: Intent) {
        super.onReceive(c, i); P.init(c)
        val o = OverlayService.inst
        when (i.action) {
            W_STOP -> { c.stopService(Intent(c, OverlayService::class.java)); NovaWidgets.updateAll(c) }
            W_SHOT -> if (o != null) o.snap() else NovaWidgets.needMenu(c)
            W_REC -> if (o != null) o.toggleRec() else NovaWidgets.needMenu(c)
            W_CROSS -> {
                val on = !P.sp.getBoolean("cross", false); P.putB("cross", on); o?.setCross(on)
                if (o == null) Toast.makeText(c, if (on) "Прицел включён, появится вместе с меню" else "Прицел выключен", Toast.LENGTH_SHORT).show()
            }
            W_TORCH -> if (Xp.ok("torch")) flash(c) else Toast.makeText(c, "Фонарик откроется на уровне ${Xp.need("torch")}", Toast.LENGTH_SHORT).show()
        }
    }
}
class NovaPanelWidget : NovaWidget(0)
class NovaToggleWidget : NovaWidget(1)
class NovaInfoWidget : NovaWidget(2)

class NovaTile : TileService() {
    private fun upd() {
        val t = qsTile ?: return
        t.state = if (OverlayService.inst != null) Tile.STATE_ACTIVE else Tile.STATE_INACTIVE
        t.label = "NOVA меню"; t.updateTile()
    }
    override fun onStartListening() { upd() }
    private fun openApp() {
        val i = Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        if (android.os.Build.VERSION.SDK_INT >= 34) startActivityAndCollapse(PendingIntent.getActivity(this, 0, i, PendingIntent.FLAG_IMMUTABLE))
        else @Suppress("DEPRECATION") startActivityAndCollapse(i)
    }
    override fun onClick() {
        P.init(this)
        if (OverlayService.inst != null) stopService(Intent(this, OverlayService::class.java))
        else if (Settings.canDrawOverlays(this)) { try { startForegroundService(Intent(this, OverlayService::class.java)) } catch (e: Exception) { openApp() } }
        else openApp()
        upd()
    }
}
