package com.nova.client
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.content.res.Configuration
import android.graphics.*
import android.graphics.drawable.GradientDrawable
import android.os.*
import android.view.*
import android.widget.*
import java.text.SimpleDateFormat
import java.util.*
import kotlin.math.abs
import kotlin.math.sin

class OverlayService : Service() {
    companion object { var inst: OverlayService? = null }
    private lateinit var wm: WindowManager
    private lateinit var pp: WindowManager.LayoutParams
    private val ctx by lazy { ContextThemeWrapper(this, android.R.style.Theme_DeviceDefault) }
    private var pill: LinearLayout? = null; private var menu: Shell? = null; private var cross: View? = null
    private var fpsTv: TextView? = null; private var collapsed = false
    private val h = Handler(Looper.getMainLooper())
    private var fc = 0; private var lt = 0L; private var fpsNow = 0
    private val cb = object : Choreographer.FrameCallback {
        override fun doFrame(t: Long) {
            if (inst == null) return
            fc++; if (lt == 0L) lt = t
            if (t - lt >= 500_000_000L) {
                val ex = if (P.sp.getBoolean("pinfo", false)) "  ·  " + SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date()) + "  ·  " + level(this@OverlayService) + "%" else ""
                fpsNow = Math.round(fc * 1e9 / (t - lt)).toInt(); fpsTv?.text = "FPS " + fpsNow + ex; fc = 0; lt = t
                fpsTv?.setTextColor(if (P.sp.getBoolean("fpscol", false)) (if (fpsNow >= 55) 0xFF22C55E.toInt() else if (fpsNow >= 30) 0xFFFFC107.toInt() else 0xFFE5242B.toInt()) else P.accent)
            }
            Choreographer.getInstance().postFrameCallback(this)
        }
    }
    private val type = WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
    private val flags = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL
    override fun onBind(i: Intent?): IBinder? = null
    override fun onStartCommand(i: Intent?, f: Int, s: Int): Int {
        if (i?.action == "com.nova.client.STOP") { stopSelf(); return START_NOT_STICKY }
        return START_STICKY
    }
    override fun onCreate() {
        super.onCreate(); inst = this; P.init(this); Xp.start(this)
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        val n = notif(this, "Меню запущено", true)
        if (Build.VERSION.SDK_INT >= 34) startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE) else startForeground(1, n)
        P.putL("ses_t", System.currentTimeMillis()); P.putI("ses_b", level(this))
        pp = WindowManager.LayoutParams(-2, -2, type, flags, PixelFormat.TRANSLUCENT).apply { gravity = Gravity.TOP or Gravity.START; x = ctx.dp(20); y = ctx.dp(60) }
        buildPill(true); Choreographer.getInstance().postFrameCallback(cb)
        if (P.sp.getBoolean("hudon", false)) setHud(true)
        NovaWidgets.updateAll(this); widgetTick()
        if (P.sp.getBoolean("cross", false)) setCross(true)
    }
    override fun onDestroy() {
        val t0 = P.getL("ses_t")
        if (t0 > 0) { P.putL("last_m", (System.currentTimeMillis() - t0) / 60000); P.putI("last_d", level(this) - P.int("ses_b", 0)) }
        inst = null; closeMenu(); setCross(false); recBadge(false); setHud(false); NovaWidgets.updateAll(this); pill?.let { try { wm.removeView(it) } catch (e: Exception) {} }; super.onDestroy()
    }
    private fun scr(): Point {
        val p = Point()
        if (Build.VERSION.SDK_INT >= 30) { val b = wm.currentWindowMetrics.bounds; p.set(b.width(), b.height()) }
        else @Suppress("DEPRECATION") wm.defaultDisplay.getRealSize(p)
        return p
    }
    private fun menuLp(): WindowManager.LayoutParams {
        val s = scr(); val land = s.x > s.y
        val w = minOf((s.x * P.int("mw", 92) / 100f).toInt(), ctx.dp(560))
        val h = (s.y * (if (land) minOf(0.92f, P.int("mh", 74) / 100f + 0.18f) else P.int("mh", 74) / 100f)).toInt()
        return WindowManager.LayoutParams(w, h, type, flags or WindowManager.LayoutParams.FLAG_WATCH_OUTSIDE_TOUCH, PixelFormat.TRANSLUCENT).apply { gravity = Gravity.CENTER }
    }
    override fun onConfigurationChanged(n: Configuration) {
        super.onConfigurationChanged(n)
        menu?.let { try { wm.updateViewLayout(it, menuLp()) } catch (e: Exception) {} }
        val s = scr(); pp.x = pp.x.coerceIn(0, maxOf(0, s.x - ctx.dp(60))); pp.y = pp.y.coerceIn(0, maxOf(0, s.y - ctx.dp(60)))
        pill?.let { try { wm.updateViewLayout(it, pp) } catch (e: Exception) {} }
    }
    fun restyle() { buildPill(); refreshCross(); if (hudV != null) { setHud(false); setHud(true) } }
    fun refreshCross() { if (cross != null) { setCross(false); setCross(true) } }
    fun setCross(on: Boolean) {
        cross?.let { try { wm.removeView(it) } catch (e: Exception) {} }; cross = null
        if (!on) return
        val v = CrossView(ctx, false); v.alpha = P.int("calpha", 100) / 100f * masterA()
        wm.addView(v, WindowManager.LayoutParams(-2, -2, type, WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL, PixelFormat.TRANSLUCENT)
            .apply { gravity = Gravity.CENTER; x = ctx.dp(P.int("coffx", 0)); y = ctx.dp(P.int("coffy", 0)) })
        cross = v
    }
    private fun buildPill(anim: Boolean = false) {
        pill?.let { try { wm.removeView(it) } catch (e: Exception) {} }
        val c = ctx
        val l = LinearLayout(c).apply { gravity = Gravity.CENTER_VERTICAL }
        fpsTv = null
        if (collapsed) {
            l.addView(Ico(c, "logo", P.accent, 40).apply { tag = { collapsed = false; buildPill(true) } })
        } else {
            l.setPadding(c.dp(12), c.dp(6), c.dp(8), c.dp(6)); l.background = pillBg()
            val f = c.tv("FPS --", P.int("psz", 13).toFloat(), P.accent, true); f.tag = { openMenu() }; l.addView(f); fpsTv = f
            if (!P.sp.getBoolean("noqp", false)) {
                val acts = listOf<Pair<String, () -> Unit>>(
                    "apps" to { openMenu() }, "shot" to { snap() }, "rec" to { toggleRec() },
                    "torch" to { if (Xp.ok("torch")) flash(applicationContext) else Toast.makeText(this, "Откроется на уровне ${Xp.need("torch")}", Toast.LENGTH_SHORT).show() },
                    "cross" to { if (Xp.ok("cross")) { val on = !P.sp.getBoolean("cross", false); P.putB("cross", on); setCross(on) } })
                acts.forEach { (k, fn) -> l.addView(Ico(c, k, P.fg(), 22).apply { tag = fn }, LinearLayout.LayoutParams(-2, -2).apply { leftMargin = c.dp(10) }) }
            }
            l.addView(Ico(c, "chev", P.sub(), 22).apply { tag = { collapsed = true; buildPill(true) } }, LinearLayout.LayoutParams(-2, -2).apply { leftMargin = c.dp(10) })
        }
        val target = P.int("pop", 100) / 100f * masterA()
        l.alpha = target; l.visibility = if (menu != null) View.INVISIBLE else View.VISIBLE
        pp.flags = flags or (if (P.sp.getBoolean("awake", false)) WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON else 0)
        var sx = 0f; var sy = 0f; var ox = 0; var oy = 0; var moved = false
        l.setOnTouchListener { v, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> { sx = e.rawX; sy = e.rawY; ox = pp.x; oy = pp.y; moved = false }
                MotionEvent.ACTION_MOVE -> {
                    val dx = e.rawX - sx; val dy = e.rawY - sy
                    if (abs(dx) > 10 || abs(dy) > 10) moved = true
                    if (moved) { pp.x = ox + dx.toInt(); pp.y = oy + dy.toInt(); wm.updateViewLayout(v, pp) }
                }
                MotionEvent.ACTION_UP -> if (!moved) {
                    var hit = false
                    for (i in 0 until l.childCount) {
                        val ch = l.getChildAt(i)
                        if (e.x >= ch.left - c.dp(4) && e.x <= ch.right + c.dp(4)) { (ch.tag as? (() -> Unit))?.invoke(); hit = true; break }
                    }
                    if (!hit) openMenu()
                } else if (P.sp.getBoolean("snap", false) && Xp.ok("snap")) {
                    val sz = scr(); pp.x = if (pp.x + v.width / 2 < sz.x / 2) 0 else sz.x - v.width; wm.updateViewLayout(v, pp)
                }
            }
            true
        }
        wm.addView(l, pp); pill = l
        if (anim) fadeIn(l, target)
    }
    private var mlp: WindowManager.LayoutParams? = null
    private fun openMenu() {
        if (menu != null) return
        pill?.visibility = View.INVISIBLE
        val c = ctx
        val sh = Shell(c, "NOVA", "bgM", listOf("Запуск", "Прицел", "Утилиты", "Игры", "Опции"), P.int("mr", 24), { closeMenu() }, icons = listOf("apps", "cross", "clock", "game", "gear"), onOff = { closeMenu(); stopSelf() }) { i, s ->
            when (i) {
                0 -> appsPage(c, s) { pk -> closeMenu(); packageManager.getLaunchIntentForPackage(pk)?.let { startActivity(it.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) } }
                1 -> crossPage(c, s)
                2 -> utilsPage(c, s)
                3 -> gamesPage(c, s)
                else -> c.settingsView { s.rebuild() }
            }
        }
        val lp = menuLp(); mlp = lp
        sh.dragCb = { dx, dy -> lp.x += dx.toInt(); lp.y += dy.toInt(); try { wm.updateViewLayout(sh, lp) } catch (e: Exception) {} }
        sh.setOnTouchListener { _, e -> if (e.action == MotionEvent.ACTION_OUTSIDE && !P.sp.getBoolean("keepopen", false)) closeMenu(); false }
        wm.addView(sh, lp); menu = sh; fadeIn(sh, masterA())
    }
    private fun pillBg(): GradientDrawable {
        val d = GradientDrawable(); d.setColor(P.bg()); d.setStroke(ctx.dp(2), P.accent)
        when (P.str("pshape", "round")) {
            "capsule" -> d.cornerRadius = ctx.dp(40).toFloat()
            "square" -> d.cornerRadius = ctx.dp(3).toFloat()
            "leaf" -> { val a = ctx.dp(20).toFloat(); val b = ctx.dp(3).toFloat(); d.cornerRadii = floatArrayOf(a, a, b, b, a, a, b, b) }
            "cut" -> { val a = ctx.dp(14).toFloat(); d.cornerRadii = floatArrayOf(a, a, 0f, 0f, a, a, 0f, 0f) }
            else -> d.cornerRadius = ctx.dp(18).toFloat()
        }
        return d
    }
    private var badge: TextView? = null; private var recStart = 0L
    fun recBadge(on: Boolean) {
        badge?.let { try { wm.removeView(it) } catch (e: Exception) {} }; badge = null
        if (!on) return
        val c = ctx; recStart = System.currentTimeMillis()
        val b = c.tv("● REC 00:00", 12f, Color.WHITE, true).apply {
            setPadding(c.dp(10), c.dp(5), c.dp(10), c.dp(5)); background = rr(0xE6E5242B.toInt(), c.dp(14).toFloat())
            setOnClickListener { CaptureService.inst?.stopRec() }
        }
        wm.addView(b, WindowManager.LayoutParams(-2, -2, type, flags, PixelFormat.TRANSLUCENT).apply { gravity = Gravity.TOP or Gravity.END; x = c.dp(10); y = c.dp(30) })
        badge = b; badgeTick(b)
    }
    private fun badgeTick(v: TextView) {
        h.postDelayed({
            if (badge === v) {
                val s = (System.currentTimeMillis() - recStart) / 1000
                v.text = "● REC %02d:%02d".format(s / 60, s % 60); v.alpha = if (s % 2 == 0L) 1f else 0.6f; badgeTick(v)
            }
        }, 1000)
    }
    fun shotThumb(b: Bitmap) {
        val c = ctx; val w = c.dp(96); val ht = w * b.height / b.width
        val iv = ImageView(c)
        iv.setImageBitmap(Bitmap.createScaledBitmap(b, w, ht, true)); iv.background = rr(Color.WHITE, c.dp(10).toFloat(), P.accent); iv.setPadding(5, 5, 5, 5)
        val rm = { try { wm.removeView(iv) } catch (e: Exception) {} }
        iv.setOnClickListener { rm(); startActivity(Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
        wm.addView(iv, WindowManager.LayoutParams(-2, -2, type, flags, PixelFormat.TRANSLUCENT).apply { gravity = Gravity.BOTTOM or Gravity.START; x = c.dp(14); y = c.dp(90) })
        iv.alpha = 0f; iv.animate().alpha(1f).setDuration(200).start()
        h.postDelayed({ rm() }, 3500)
    }
    fun focusable(on: Boolean) {
        val m = menu ?: return
        val lp = m.layoutParams as? WindowManager.LayoutParams ?: return
        lp.flags = if (on) lp.flags and WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE.inv() else lp.flags or WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
        try { wm.updateViewLayout(m, lp) } catch (e: Exception) {}
    }
    fun shutdown() { CaptureService.inst?.stopRec(); stopSelf() }
    private fun widgetTick() { h.postDelayed({ if (inst != null) { NovaWidgets.updateAll(this); widgetTick() } }, 60000) }
    fun masterA() = P.int("oall", 100) / 100f
    fun applyAlpha() {
        pill?.alpha = P.int("pop", 100) / 100f * masterA(); menu?.alpha = masterA()
        cross?.alpha = P.int("calpha", 100) / 100f * masterA(); hudV?.alpha = masterA()
    }
    private fun fadeIn(v: View, to: Float) {
        if (P.sp.getBoolean("noanim", false)) { v.alpha = to; return }
        val st = P.str("wanim", "both")
        if (st != "scale") v.alpha = 0f
        if (st != "fade") { v.scaleX = 0.88f; v.scaleY = 0.88f }
        v.animate().alpha(to).scaleX(1f).scaleY(1f).setDuration(200).start()
    }
    private fun fadeOut(v: View, end: () -> Unit) {
        if (P.sp.getBoolean("noanim", false)) { end(); return }
        val st = P.str("wanim", "both"); val a = v.animate().setDuration(160)
        if (st != "scale") a.alpha(0f)
        if (st != "fade") a.scaleX(0.88f).scaleY(0.88f)
        a.withEndAction { end() }.start()
    }
    private var hudV: LinearLayout? = null; private var hudBig: TextView? = null; private var hudSmall: TextView? = null
    fun setHud(on: Boolean) {
        hudV?.let { try { wm.removeView(it) } catch (e: Exception) {} }; hudV = null
        if (!on) return
        val c = ctx; val sz = P.int("hudsz", 15).toFloat()
        val big = c.tv("--:--", sz + 5, P.fg(), true); val small = c.tv("", sz - 3, P.sub())
        val v = LinearLayout(c).apply {
            orientation = LinearLayout.VERTICAL; setPadding(c.dp(10), c.dp(6), c.dp(12), c.dp(6)); background = rr(withA(P.bg(), 225), c.dp(12).toFloat(), P.accent)
            addView(big); addView(small)
        }
        val lp = WindowManager.LayoutParams(-2, -2, type, flags, PixelFormat.TRANSLUCENT).apply { gravity = Gravity.TOP or Gravity.START; x = P.int("hudx", c.dp(20)); y = P.int("hudy", c.dp(120)) }
        var sx = 0f; var sy = 0f; var ox = 0; var oy = 0
        v.setOnTouchListener { vv, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> { sx = e.rawX; sy = e.rawY; ox = lp.x; oy = lp.y }
                MotionEvent.ACTION_MOVE -> { lp.x = ox + (e.rawX - sx).toInt(); lp.y = oy + (e.rawY - sy).toInt(); try { wm.updateViewLayout(vv, lp) } catch (ex: Exception) {} }
                MotionEvent.ACTION_UP -> { P.putI("hudx", lp.x); P.putI("hudy", lp.y) }
            }
            true
        }
        wm.addView(v, lp); hudV = v; hudBig = big; hudSmall = small
        fadeIn(v, masterA()); hudTick(v)
    }
    private fun hudTick(v: View) {
        hudUpdate()
        h.postDelayed({ if (hudV === v) hudTick(v) }, 1000)
    }
    private fun hudUpdate() {
        val big = hudBig ?: return; val small = hudSmall ?: return
        big.text = SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date())
        val mode = P.str("hudm", "c"); val sb = StringBuilder("Заряд " + battery(this))
        if (mode != "c") {
            val mi = android.app.ActivityManager.MemoryInfo(); getSystemService(android.app.ActivityManager::class.java).getMemoryInfo(mi)
            val bi = registerReceiver(null, android.content.IntentFilter(Intent.ACTION_BATTERY_CHANGED)); val tp = (bi?.getIntExtra("temperature", 0) ?: 0) / 10f
            sb.append("\nОЗУ ").append("%.1f/%.1f ГБ".format((mi.totalMem - mi.availMem) / 1073741824.0, mi.totalMem / 1073741824.0)).append(" · ").append("%.0f °C".format(tp))
        }
        if (mode == "f") sb.append("\nFPS ").append(fpsNow)
        small.text = sb.toString()
    }
    fun closeMenu() {
        val m = menu; menu = null; pill?.visibility = View.VISIBLE
        if (m != null) fadeOut(m) { try { wm.removeView(m) } catch (e: Exception) {} }
    }
    private fun need(): Boolean {
        if (CaptureService.inst != null) return false
        Toast.makeText(this, "Сначала выдай доступ к записи экрана", Toast.LENGTH_LONG).show()
        startActivity(Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK).putExtra("cap", true))
        return true
    }
    fun snap() {
        if (need()) return
        if (CaptureService.inst?.recording == true) { Toast.makeText(this, "Сначала останови запись", Toast.LENGTH_SHORT).show(); return }
        val d0 = P.int("sdelay", 0) * 1000L
        closeMenu()
        if (d0 > 0) Toast.makeText(this, "Скриншот через ${d0 / 1000} с", Toast.LENGTH_SHORT).show()
        h.postDelayed({ pill?.visibility = View.INVISIBLE; cross?.visibility = View.INVISIBLE }, d0)
        h.postDelayed({ CaptureService.inst?.shot() }, d0 + 500)
        h.postDelayed({ pill?.visibility = View.VISIBLE; cross?.visibility = View.VISIBLE }, d0 + 1200)
    }
    fun toggleRec() {
        if (need()) return
        val cs = CaptureService.inst ?: return
        if (cs.recording) { cs.stopRec(); menu?.rebuild() } else { cs.startRec(); closeMenu() }
    }
}
