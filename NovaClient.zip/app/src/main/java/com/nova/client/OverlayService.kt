package com.nova.client
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.content.res.Configuration
import android.graphics.*
import android.graphics.drawable.GradientDrawable
import android.os.*
import android.view.*
import android.widget.*
import java.text.SimpleDateFormat
import java.util.*
import kotlin.math.abs

class OverlayService : Service() {
    companion object { var inst: OverlayService? = null }
    private lateinit var wm: WindowManager
    private lateinit var pp: WindowManager.LayoutParams
    private val ctx by lazy { ContextThemeWrapper(this, android.R.style.Theme_DeviceDefault) }
    private var pill: LinearLayout? = null; private var menu: Shell? = null; private var cross: View? = null
    private var fpsTv: TextView? = null; private var collapsed = false
    private val h = Handler(Looper.getMainLooper())
    private var fc = 0; private var lt = 0L
    private val cb = object : Choreographer.FrameCallback {
        override fun doFrame(t: Long) {
            if (inst == null) return
            fc++; if (lt == 0L) lt = t
            if (t - lt >= 500_000_000L) {
                val ex = if (P.sp.getBoolean("pinfo", false)) "  ·  " + SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date()) + "  ·  " + level(this@OverlayService) + "%" else ""
                fpsTv?.text = "FPS " + Math.round(fc * 1e9 / (t - lt)) + ex; fc = 0; lt = t
            }
            Choreographer.getInstance().postFrameCallback(this)
        }
    }
    private val type = WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
    private val flags = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL
    override fun onBind(i: Intent?): IBinder? = null
    override fun onStartCommand(i: Intent?, f: Int, s: Int) = START_STICKY
    override fun onCreate() {
        super.onCreate(); inst = this; P.init(this); Xp.start(this)
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        val n = notif(this, "Меню запущено")
        if (Build.VERSION.SDK_INT >= 34) startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE) else startForeground(1, n)
        P.putL("ses_t", System.currentTimeMillis()); P.putI("ses_b", level(this))
        pp = WindowManager.LayoutParams(-2, -2, type, flags, PixelFormat.TRANSLUCENT).apply { gravity = Gravity.TOP or Gravity.START; x = ctx.dp(20); y = ctx.dp(60) }
        buildPill(); Choreographer.getInstance().postFrameCallback(cb)
        if (P.sp.getBoolean("cross", false)) setCross(true)
    }
    override fun onDestroy() {
        val t0 = P.getL("ses_t")
        if (t0 > 0) { P.putL("last_m", (System.currentTimeMillis() - t0) / 60000); P.putI("last_d", level(this) - P.int("ses_b", 0)) }
        inst = null; closeMenu(); setCross(false); recBadge(false); pill?.let { try { wm.removeView(it) } catch (e: Exception) {} }; super.onDestroy()
    }
    private fun scr(): Point {
        val p = Point()
        if (Build.VERSION.SDK_INT >= 30) { val b = wm.currentWindowMetrics.bounds; p.set(b.width(), b.height()) }
        else @Suppress("DEPRECATION") wm.defaultDisplay.getRealSize(p)
        return p
    }
    private fun menuLp(): WindowManager.LayoutParams {
        val s = scr(); val land = s.x > s.y
        return WindowManager.LayoutParams(minOf((s.x * 0.92).toInt(), ctx.dp(560)), (s.y * (if (land) 0.92 else 0.74)).toInt(), type, flags, PixelFormat.TRANSLUCENT).apply { gravity = Gravity.CENTER }
    }
    override fun onConfigurationChanged(n: Configuration) {
        super.onConfigurationChanged(n)
        menu?.let { try { wm.updateViewLayout(it, menuLp()) } catch (e: Exception) {} }
        val s = scr(); pp.x = pp.x.coerceIn(0, maxOf(0, s.x - ctx.dp(60))); pp.y = pp.y.coerceIn(0, maxOf(0, s.y - ctx.dp(60)))
        pill?.let { try { wm.updateViewLayout(it, pp) } catch (e: Exception) {} }
    }
    fun restyle() { buildPill(); if (cross != null) { setCross(false); setCross(true) } }
    fun setCross(on: Boolean) {
        cross?.let { try { wm.removeView(it) } catch (e: Exception) {} }; cross = null
        if (!on) return
        val v = object : View(ctx) {
            private val p = Paint(Paint.ANTI_ALIAS_FLAG)
            override fun onMeasure(w: Int, hh: Int) { setMeasuredDimension(ctx.dp(32), ctx.dp(32)) }
            override fun onDraw(cv: Canvas) {
                val c = width / 2f; val g = ctx.dp(4).toFloat(); val l = ctx.dp(11).toFloat()
                p.color = P.accent; p.strokeWidth = ctx.dp(2).toFloat()
                cv.drawLine(c - g - l, c, c - g, c, p); cv.drawLine(c + g, c, c + g + l, c, p)
                cv.drawLine(c, c - g - l, c, c - g, p); cv.drawLine(c, c + g, c, c + g + l, p); cv.drawCircle(c, c, ctx.dp(1).toFloat(), p)
            }
        }
        wm.addView(v, WindowManager.LayoutParams(-2, -2, type, WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL, PixelFormat.TRANSLUCENT).apply { gravity = Gravity.CENTER })
        cross = v
    }
    private fun buildPill() {
        pill?.let { try { wm.removeView(it) } catch (e: Exception) {} }
        val c = ctx
        fpsTv = c.tv("FPS --", P.int("psz", 13).toFloat(), P.accent, true)
        val arrow = c.tv(if (collapsed) "▸" else "▾", 14f, P.fg(), true)
        val l = LinearLayout(c).apply {
            gravity = Gravity.CENTER_VERTICAL; setPadding(c.dp(12), c.dp(6), c.dp(10), c.dp(6)); background = pillBg()
            alpha = P.int("pop", 100) / 100f; visibility = if (menu != null) View.INVISIBLE else View.VISIBLE
        }
        if (!collapsed) l.addView(fpsTv)
        l.addView(arrow.apply { setPadding(if (collapsed) 0 else c.dp(10), 0, 0, 0) })
        pp.flags = flags or (if (P.sp.getBoolean("awake", false)) WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON else 0)
        var sx = 0f; var sy = 0f; var ox = 0; var oy = 0; var moved = false
        l.setOnTouchListener { v, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> { sx = e.rawX; sy = e.rawY; ox = pp.x; oy = pp.y; moved = false }
                MotionEvent.ACTION_MOVE -> {
                    val dx = e.rawX - sx; val dy = e.rawY - sy
                    if (abs(dx) > 10 || abs(dy) > 10) moved = true
                    if (moved) { pp.x = ox + dx.toInt(); pp.y = oy + dy.toInt(); wm.updateViewLayout(v, pp) }
                }
                MotionEvent.ACTION_UP -> if (!moved) { if (collapsed || e.x > arrow.left) { collapsed = !collapsed; buildPill() } else openMenu() }
                else if (P.sp.getBoolean("snap", false) && Xp.ok("snap")) { val sz = scr(); pp.x = if (pp.x + v.width / 2 < sz.x / 2) 0 else sz.x - v.width; wm.updateViewLayout(v, pp) }
            }
            true
        }
        wm.addView(l, pp); pill = l
    }
    private fun openMenu() {
        if (menu != null) return
        pill?.visibility = View.INVISIBLE
        val c = ctx
        val sh = Shell(c, "NOVA  ·  ур. " + Xp.level(), "bgM", listOf("Приложения", "Инструменты", "Игры", "Телефон", "Настройки"), P.int("mr", 24), { closeMenu() }) { i, s ->
            when (i) {
                0 -> appsPage(c, s) { pk -> closeMenu(); packageManager.getLaunchIntentForPackage(pk)?.let { startActivity(it.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) } }
                1 -> toolsPage(c, s)
                2 -> gamesPage(c, s)
                3 -> phonePage(c, s)
                else -> c.settingsView { s.rebuild() }
            }
        }
        wm.addView(sh, menuLp()); menu = sh
    }
    private fun pillBg(): GradientDrawable {
        val d = GradientDrawable(); d.setColor(P.bg()); d.setStroke(ctx.dp(2), P.accent)
        when (P.str("pshape", "round")) {
            "capsule" -> d.cornerRadius = ctx.dp(40).toFloat()
            "square" -> d.cornerRadius = ctx.dp(3).toFloat()
            "leaf" -> { val a = ctx.dp(20).toFloat(); val b = ctx.dp(3).toFloat(); d.cornerRadii = floatArrayOf(a, a, b, b, a, a, b, b) }
            "cut" -> { val a = ctx.dp(14).toFloat(); d.cornerRadii = floatArrayOf(a, a, 0f, 0f, a, a, 0f, 0f) }
            else -> d.cornerRadius = ctx.dp(18).toFloat()
        }
        return d
    }
    private var badge: TextView? = null; private var recStart = 0L
    fun recBadge(on: Boolean) {
        badge?.let { try { wm.removeView(it) } catch (e: Exception) {} }; badge = null
        if (!on) return
        val c = ctx; recStart = System.currentTimeMillis()
        val b = c.tv("● REC 00:00", 12f, Color.WHITE, true).apply {
            setPadding(c.dp(10), c.dp(5), c.dp(10), c.dp(5)); background = rr(0xE6E5242B.toInt(), c.dp(14).toFloat())
            setOnClickListener { CaptureService.inst?.stopRec() }
        }
        wm.addView(b, WindowManager.LayoutParams(-2, -2, type, flags, PixelFormat.TRANSLUCENT).apply { gravity = Gravity.TOP or Gravity.END; x = c.dp(10); y = c.dp(30) })
        badge = b; badgeTick(b)
    }
    private fun badgeTick(v: TextView) {
        h.postDelayed({
            if (badge === v) {
                val s = (System.currentTimeMillis() - recStart) / 1000
                v.text = "● REC %02d:%02d".format(s / 60, s % 60); v.alpha = if (s % 2 == 0L) 1f else 0.6f; badgeTick(v)
            }
        }, 1000)
    }
    fun shotThumb(b: Bitmap) {
        val c = ctx; val w = c.dp(96); val ht = w * b.height / b.width
        val iv = ImageView(c)
        iv.setImageBitmap(Bitmap.createScaledBitmap(b, w, ht, true)); iv.background = rr(Color.WHITE, c.dp(10).toFloat(), P.accent); iv.setPadding(5, 5, 5, 5)
        val rm = { try { wm.removeView(iv) } catch (e: Exception) {} }
        iv.setOnClickListener { rm(); startActivity(Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
        wm.addView(iv, WindowManager.LayoutParams(-2, -2, type, flags, PixelFormat.TRANSLUCENT).apply { gravity = Gravity.BOTTOM or Gravity.START; x = c.dp(14); y = c.dp(90) })
        iv.alpha = 0f; iv.animate().alpha(1f).setDuration(200).start()
        h.postDelayed({ rm() }, 3500)
    }
    fun focusable(on: Boolean) {
        val m = menu ?: return
        val lp = m.layoutParams as? WindowManager.LayoutParams ?: return
        lp.flags = if (on) lp.flags and WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE.inv() else lp.flags or WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
        try { wm.updateViewLayout(m, lp) } catch (e: Exception) {}
    }
    fun closeMenu() {
        menu?.let { try { wm.removeView(it) } catch (e: Exception) {} }; menu = null; pill?.visibility = View.VISIBLE
    }
    private fun need(): Boolean {
        if (CaptureService.inst != null) return false
        Toast.makeText(this, "Сначала выдай доступ к записи экрана", Toast.LENGTH_LONG).show()
        startActivity(Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK).putExtra("cap", true))
        return true
    }
    fun snap() {
        if (need()) return
        if (CaptureService.inst?.recording == true) { Toast.makeText(this, "Сначала останови запись", Toast.LENGTH_SHORT).show(); return }
        closeMenu(); pill?.visibility = View.INVISIBLE; cross?.visibility = View.INVISIBLE
        h.postDelayed({ CaptureService.inst?.shot() }, 500); h.postDelayed({ pill?.visibility = View.VISIBLE; cross?.visibility = View.VISIBLE }, 1200)
    }
    fun toggleRec() {
        if (need()) return
        val cs = CaptureService.inst ?: return
        if (cs.recording) { cs.stopRec(); menu?.rebuild() } else { cs.startRec(); closeMenu() }
    }
}
