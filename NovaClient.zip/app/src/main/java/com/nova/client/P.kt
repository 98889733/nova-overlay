package com.nova.client
import android.app.*
import android.content.*
import android.graphics.Color
import android.media.AudioManager
import android.media.ToneGenerator
import android.os.*
import android.widget.Toast
import java.io.File
import java.text.SimpleDateFormat
import java.util.*

object P {
    lateinit var sp: SharedPreferences
    fun init(c: Context) { if (!::sp.isInitialized) sp = c.applicationContext.getSharedPreferences("nova", 0) }
    fun int(k: String, d: Int) = sp.getInt(k, d)
    fun putI(k: String, v: Int) = sp.edit().putInt(k, v).apply()
    fun str(k: String, d: String = "") = sp.getString(k, d) ?: d
    fun putS(k: String, v: String) = sp.edit().putString(k, v).apply()
    fun putL(k: String, v: Long) = sp.edit().putLong(k, v).apply()
    fun getL(k: String) = sp.getLong(k, 0L)
    fun putB(k: String, v: Boolean) = sp.edit().putBoolean(k, v).apply()
    val dark: Boolean get() = sp.getBoolean("dark", false)
    val accent: Int get() = int("acc", 0xFF5B6CFF.toInt())
    private fun lum(c: Int) = (0.299f * Color.red(c) + 0.587f * Color.green(c) + 0.114f * Color.blue(c)) / 255f
    fun bg(): Int { val v = int("pbg", 0); return if (v != 0) v else if (dark) 0xFF14151C.toInt() else Color.WHITE }
    fun fg(): Int { val v = int("ptx", 0); return if (v != 0) v else if (lum(bg()) < 0.5f) Color.WHITE else 0xFF16171D.toInt() }
    fun mix(a: Int, b: Int, t: Float) = Color.rgb(
        (Color.red(a) + (Color.red(b) - Color.red(a)) * t).toInt(),
        (Color.green(a) + (Color.green(b) - Color.green(a)) * t).toInt(),
        (Color.blue(a) + (Color.blue(b) - Color.blue(a)) * t).toInt())
    fun card() = mix(bg(), fg(), 0.08f)
    fun sub() = mix(bg(), fg(), 0.55f)
    fun apps() = str("apps", "org.telegram.messenger").split("|").filter { it.isNotEmpty() }
    fun addApp(p: String) { if (p !in apps()) { putS("apps", (apps() + p).joinToString("|")); Q.done("app") } }
    fun pinApp(p: String) = putS("apps", (listOf(p) + apps().filter { it != p }).joinToString("|"))
    fun delApp(p: String) = putS("apps", (apps() - p).joinToString("|"))
}

object T {
    var end = 0L; var total = 0
    private val h = Handler(Looper.getMainLooper())
    private var r: Runnable? = null
    fun left(): Int = if (end > 0) maxOf(0L, (end - System.currentTimeMillis() + 999) / 1000).toInt() else total
    fun start(c: Context) {
        if (total <= 0) return
        end = System.currentTimeMillis() + total * 1000L
        r?.let { h.removeCallbacks(it) }
        r = Runnable { end = 0; ring(c) }
        h.postDelayed(r!!, total * 1000L)
    }
    fun stop() { r?.let { h.removeCallbacks(it) }; end = 0 }
    private fun ring(c: Context) {
        Toast.makeText(c, "Таймер!", Toast.LENGTH_LONG).show()
        c.getSystemService(Vibrator::class.java)?.vibrate(VibrationEffect.createOneShot(900, 255))
        try { ToneGenerator(AudioManager.STREAM_ALARM, 100).startTone(ToneGenerator.TONE_CDMA_ALERT_CALL_GUARD, 1500) } catch (e: Exception) {}
    }
}

fun Context.dir(n: String) = File(filesDir, n).apply { mkdirs() }
fun ts(): String = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
fun notif(c: Context, t: String): Notification {
    c.getSystemService(NotificationManager::class.java).createNotificationChannel(NotificationChannel("nova", "NOVA", NotificationManager.IMPORTANCE_LOW))
    return Notification.Builder(c, "nova").setContentTitle("NOVA Client").setContentText(t).setSmallIcon(android.R.drawable.ic_menu_view).build()
}

val UNL = mapOf(
    "bg_stars" to 1, "bg_cubes" to 1, "bg_circles" to 2, "bg_triangles" to 3, "bg_smoke" to 3, "bg_rain" to 4, "bg_wind" to 5, "bg_cylinders" to 6,
    "bg_starshapes" to 7, "bg_fog" to 8, "bg_space" to 10, "bg_galaxy" to 12, "bg_planets" to 15,
    "shape_round" to 1, "shape_capsule" to 2, "shape_square" to 3, "shape_leaf" to 5, "shape_cut" to 8,
    "cross" to 2, "torch" to 3, "pinfo" to 4, "snap" to 4, "wheel" to 5, "awake" to 6, "boot" to 7, "bgs" to 9, "minihud" to 3)
val UNLOCKS: List<Pair<Int, String>> by lazy {
    val base = listOf(
        1 to "Фоны: звёзды, 3D-кубы, частицы · форма плашки: круглая", 2 to "Фон: круги · форма: капсула · прицел на экране",
        3 to "Фон: треугольники и дым · форма: квадрат · фонарик", 4 to "Фон: дождь · время и заряд на плашке · прилипание к краю",
        5 to "Фон: ветер · цветовой круг · форма: листик", 6 to "Фон: цилиндры · не гасить экран", 7 to "Фон: звёздочки · автозапуск при включении",
        8 to "Фон: туман · форма: срез", 9 to "Скорость анимации фона", 10 to "Фон: космос", 12 to "Фон: галактики", 15 to "Фон: планеты")
    base + CS_ALL.groupBy { it.lv }.map { (lv, l) -> lv to "Прицелы: " + l.joinToString(", ") { it.n } } +
        CS_EFF.filter { it.lv > 1 }.groupBy { it.lv }.map { (lv, l) -> lv to "Анимации прицела: " + l.joinToString(", ") { it.n } }
}

object Xp {
    private val h = Handler(Looper.getMainLooper()); private var on = false; private var app: Context? = null
    var visible = false
    fun xp() = P.getL("xp")
    fun level(x: Long = xp()) = Math.sqrt(x / 25.0).toInt() + 1
    fun base(l: Int) = (l - 1) * (l - 1) * 25L
    fun maxApps() = if (P.sp.getBoolean("all", false)) 99 else 2 + level()
    fun need(k: String) = UNL[k] ?: 1
    fun lv(n: Int) = P.sp.getBoolean("all", false) || level() >= n
    fun ok(k: String) = P.sp.getBoolean("all", false) || level() >= need(k)
    fun say(t: String) { app?.let { Toast.makeText(it, t, Toast.LENGTH_LONG).show() } }
    fun add(n: Long) {
        val before = level(); P.putL("xp", xp() + n); val after = level()
        if (after > before) app?.let { Toast.makeText(it, "Новый уровень: $after!", Toast.LENGTH_LONG).show() }
    }
    fun daily(): Boolean {
        val d = System.currentTimeMillis() / 86400000L
        if (P.getL("xp_day") == d) return false
        P.putL("xp_day", d); add(10); return true
    }
    fun start(c: Context) { app = c.applicationContext; if (on) return; on = true; tick() }
    private fun tick() { h.postDelayed({ if (visible || OverlayService.inst != null) add(1); tick() }, 30000) }
}

class Quest(val k: String, val t: String, val xp: Int)
val QUESTS = listOf(
    Quest("shot", "Сделать скриншот", 15), Quest("rec", "Записать видео", 20), Quest("app", "Добавить своё приложение в меню", 10),
    Quest("color", "Сменить акцентный цвет", 10), Quest("shape", "Сменить форму плашки", 10), Quest("bg", "Сменить фон", 10),
    Quest("cross", "Включить прицел", 5), Quest("game", "Сыграть в мини-игру", 10), Quest("cps", "Пройти тест кликов", 10))
object Q {
    fun has(k: String) = P.sp.getBoolean("q_$k", false)
    fun done(k: String) {
        val q = QUESTS.firstOrNull { it.k == k } ?: return
        if (has(k)) return
        P.putB("q_$k", true); Xp.add(q.xp.toLong()); Xp.say("Задание: ${q.t} (+${q.xp} XP)")
    }
    fun all() { QUESTS.forEach { if (!has(it.k)) { P.putB("q_${it.k}", true); Xp.add(it.xp.toLong()) } } }
}
