package com.nova.client
import android.app.ActivityManager
import android.content.*
import android.graphics.*
import android.graphics.drawable.GradientDrawable
import android.hardware.display.DisplayManager
import android.os.*
import android.view.*
import android.widget.*
import kotlin.math.*

object Sc { val m = HashMap<String, Int>() }
object UiS { var wheel = "" }

fun HorizontalScrollView.keep(key: String) {
    setOnScrollChangeListener { _, x, _, _, _ -> Sc.m[key] = x }
    val me = this
    viewTreeObserver.addOnGlobalLayoutListener(object : ViewTreeObserver.OnGlobalLayoutListener {
        override fun onGlobalLayout() { me.viewTreeObserver.removeOnGlobalLayoutListener(this); me.scrollTo(Sc.m[key] ?: 0, 0) }
    })
}
fun Context.colorRow(list: List<Int>, cur: Int, key: String, onWheel: () -> Unit, sel: (Int) -> Unit): View = HorizontalScrollView(this).apply {
    isHorizontalScrollBarEnabled = false; keep(key)
    addView(LinearLayout(context).apply {
        list.forEach { c ->
            addView(tv(if (c == 0) "A" else "", 13f, P.fg(), true).apply {
                gravity = Gravity.CENTER
                background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(if (c == 0) P.card() else c); setStroke(if (c == cur) dp(3) else dp(1), if (c == cur) P.fg() else P.sub()) }
                setOnClickListener { sel(c) }
            }, LinearLayout.LayoutParams(dp(38), dp(38)).apply { rightMargin = dp(8) })
        }
        addView(tv("+", 18f, Color.WHITE, true).apply {
            gravity = Gravity.CENTER
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL; setGradientType(GradientDrawable.SWEEP_GRADIENT)
                setColors(intArrayOf(-65536, -256, -16711936, -16711681, -16776961, -65281, -65536)); setStroke(dp(1), P.sub())
            }
            setOnClickListener { onWheel() }
        }, LinearLayout.LayoutParams(dp(38), dp(38)))
    })
}
fun Context.chipRow(items: List<Pair<String, String>>, cur: String, key: String, sel: (String) -> Unit): View = HorizontalScrollView(this).apply {
    isHorizontalScrollBarEnabled = false; keep(key)
    addView(LinearLayout(context).apply {
        items.forEach { (k, n) -> addView(btn(n, k == cur) { sel(k) }.apply { textSize = 12f }, LinearLayout.LayoutParams(-2, -2).apply { rightMargin = dp(6) }) }
    })
}

class Wheel(c: Context, start: Int, val pick: (Int) -> Unit) : View(c) {
    private val hsv = FloatArray(3).also { Color.colorToHSV(start, it) }
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private var mode = 0
    private fun rad() = width / 2f - context.dp(10)
    private fun barL() = context.dp(10).toFloat()
    private fun barR() = width - context.dp(10).toFloat()
    override fun onMeasure(w: Int, h: Int) { val ww = minOf(MeasureSpec.getSize(w), context.dp(280)); setMeasuredDimension(ww, ww + context.dp(46)) }
    override fun onDraw(cv: Canvas) {
        val cx = width / 2f; val r = rad()
        p.style = Paint.Style.FILL
        p.shader = SweepGradient(cx, cx, intArrayOf(-65536, -256, -16711936, -16711681, -16776961, -65281, -65536), null); cv.drawCircle(cx, cx, r, p)
        p.shader = RadialGradient(cx, cx, r, Color.WHITE, 0x00FFFFFF, Shader.TileMode.CLAMP); cv.drawCircle(cx, cx, r, p)
        p.shader = null; p.color = Color.argb(((1 - hsv[2]) * 255).toInt(), 0, 0, 0); cv.drawCircle(cx, cx, r, p)
        val a = Math.toRadians(hsv[0].toDouble())
        val mx = cx + (hsv[1] * r * cos(a)).toFloat(); val my = cx + (hsv[1] * r * sin(a)).toFloat()
        p.style = Paint.Style.STROKE; p.strokeWidth = context.dp(3).toFloat(); p.color = Color.WHITE; cv.drawCircle(mx, my, context.dp(9).toFloat(), p)
        p.strokeWidth = context.dp(1).toFloat(); p.color = Color.BLACK; cv.drawCircle(mx, my, context.dp(11).toFloat(), p)
        val top = cx * 2 + context.dp(12); val bot = top + context.dp(22); val l = barL(); val rt = barR()
        p.style = Paint.Style.FILL
        p.shader = LinearGradient(l, 0f, rt, 0f, Color.BLACK, Color.HSVToColor(floatArrayOf(hsv[0], hsv[1], 1f)), Shader.TileMode.CLAMP)
        cv.drawRoundRect(l, top, rt, bot, 14f, 14f, p); p.shader = null
        val tx = l + hsv[2] * (rt - l); p.style = Paint.Style.STROKE; p.strokeWidth = context.dp(3).toFloat(); p.color = Color.WHITE
        cv.drawCircle(tx, (top + bot) / 2, context.dp(12).toFloat(), p)
    }
    override fun onTouchEvent(e: MotionEvent): Boolean {
        val cx = width / 2f
        if (e.action == MotionEvent.ACTION_DOWN) mode = if (e.y > cx * 2 + context.dp(4)) 1 else 0
        if (mode == 0) {
            val dx = e.x - cx; val dy = e.y - cx
            hsv[0] = ((Math.toDegrees(atan2(dy, dx).toDouble()) + 360) % 360).toFloat(); hsv[1] = min(1f, hypot(dx, dy) / rad())
        } else hsv[2] = ((e.x - barL()) / (barR() - barL())).coerceIn(0.02f, 1f)
        invalidate(); parent?.requestDisallowInterceptTouchEvent(true)
        if (e.action == MotionEvent.ACTION_UP) pick(Color.HSVToColor(hsv))
        return true
    }
}

fun Context.sw(label: String, key: String, a: () -> Unit) = Switch(this).apply {
    text = label; setTextColor(P.fg()); isChecked = P.sp.getBoolean(key, false)
    setOnCheckedChangeListener { _, b -> P.putB(key, b); a() }
}
fun Context.colorSec(label: String, key: String, list: List<Int>, cur: Int, def: Int, a: () -> Unit): List<View> {
    val l = arrayListOf<View>(tv(label, 13f, P.sub()), colorRow(list, cur, key, { UiS.wheel = if (UiS.wheel == key) "" else key; a() }) { UiS.wheel = ""; P.putI(key, it); a() })
    if (UiS.wheel == key) l.add(Wheel(this, def) { P.putI(key, it); a() })
    return l
}
fun Context.settingsView(apply: () -> Unit): View {
    val a = { OverlayService.inst?.restyle(); apply() }
    val dk = Switch(this).apply {
        text = "Тёмная тема"; setTextColor(P.fg()); isChecked = P.dark
        setOnCheckedChangeListener { _, b -> P.putB("dark", b); P.putI("pbg", 0); P.putI("ptx", 0); a() }
    }
    val op = SeekBar(this).apply {
        max = 70; progress = P.int("pop", 100) - 30
        setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, u: Boolean) {}
            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) { P.putI("pop", (s?.progress ?: 70) + 30); OverlayService.inst?.restyle() }
        })
    }
    val v = ArrayList<View>()
    v.add(dk)
    v.addAll(colorSec("Акцентный цвет", "acc", ACC, P.accent, P.accent, a))
    v.addAll(colorSec("Цвет текста (A — авто)", "ptx", TXT, P.int("ptx", 0), P.fg(), a))
    v.addAll(colorSec("Цвет фона (A — авто)", "pbg", PBG, P.int("pbg", 0), P.bg(), a))
    v.add(tv("Фон плавающего меню", 13f, P.sub())); v.add(chipRow(MODES, P.str("bgM", "stars"), "bgM") { P.putS("bgM", it); a() })
    v.add(tv("Фон приложения", 13f, P.sub())); v.add(chipRow(MODES, P.str("bgA", "stars"), "bgA") { P.putS("bgA", it); a() })
    v.add(tv("Плашка FPS", 13f, P.sub()))
    v.add(sw("Время и заряд на плашке", "pinfo", a)); v.add(sw("Не гасить экран", "awake", a))
    v.add(tv("Прозрачность плашки", 12f, P.sub())); v.add(op)
    v.add(btn("Сбросить настройки", false) {
        val ap = P.str("apps", "org.telegram.messenger"); P.sp.edit().clear().putString("apps", ap).apply(); UiS.wheel = ""; a()
    })
    return stack(*v.toTypedArray())
}

fun level(c: Context): Int {
    val i = c.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
    val l = i?.getIntExtra("level", -1) ?: -1; val s = i?.getIntExtra("scale", 100) ?: 100
    return l * 100 / s
}
fun gb(b: Long) = "%.1f ГБ".format(b / 1073741824.0)
fun phoneInfo(c: Context): String {
    val mi = ActivityManager.MemoryInfo(); c.getSystemService(ActivityManager::class.java).getMemoryInfo(mi)
    val st = StatFs(Environment.getDataDirectory().path); val dm = c.resources.displayMetrics
    val hz = c.getSystemService(DisplayManager::class.java).getDisplay(0)?.refreshRate ?: 0f
    val up = SystemClock.elapsedRealtime() / 60000
    return "Модель: ${Build.MANUFACTURER} ${Build.MODEL}\nAndroid ${Build.VERSION.RELEASE} (API ${Build.VERSION.SDK_INT})\n" +
        "Экран: ${dm.widthPixels}×${dm.heightPixels}, ${dm.densityDpi} dpi, ${"%.0f".format(hz)} Гц\n" +
        "Процессор: ${Runtime.getRuntime().availableProcessors()} ядер, ${Build.SUPPORTED_ABIS[0]}\n" +
        "ОЗУ: свободно ${gb(mi.availMem)} из ${gb(mi.totalMem)}\nПамять: свободно ${gb(st.availableBytes)} из ${gb(st.totalBytes)}\n" +
        "Включён: ${up / 60} ч ${up % 60} мин"
}
fun batInfo(c: Context): String {
    val i = c.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
    val t = (i?.getIntExtra("temperature", 0) ?: 0) / 10f; val v = (i?.getIntExtra("voltage", 0) ?: 0) / 1000f
    val hl = when (i?.getIntExtra("health", 1)) { 2 -> "хорошее"; 3 -> "перегрев"; 4 -> "изношена"; 5 -> "перенапряжение"; 7 -> "холодная"; else -> "неизвестно" }
    return "Заряд: ${battery(c)}\nТемпература: ${"%.1f".format(t)} °C\nНапряжение: ${"%.2f".format(v)} В\nСостояние: $hl"
}
fun appStats(c: Context): String {
    val rt = Runtime.getRuntime(); val mem = (rt.totalMemory() - rt.freeMemory()) / 1048576
    val t0 = P.getL("ses_t")
    val s = if (OverlayService.inst != null && t0 > 0) {
        val b0 = P.int("ses_b", 0); val cur = level(c)
        "Меню работает: ${(System.currentTimeMillis() - t0) / 60000} мин\nЗаряд за это время: $b0% → $cur% (${cur - b0}%)"
    } else "Меню остановлено\nПоследняя сессия: ${P.getL("last_m")} мин, изменение заряда ${P.int("last_d", 0)}%"
    return "$s\nПамять приложения: $mem МБ\nЦифры заряда — расход всего телефона за это время, а не только NOVA."
}
fun phonePage(c: Context, sh: Shell): View {
    val t1 = c.tv("", 13f); tick(t1) { phoneInfo(c) }
    val t2 = c.tv("", 13f); tick(t2) { batInfo(c) }
    val t3 = c.tv("", 13f); tick(t3) { appStats(c) }
    return c.stack(c.card(c.tv("Телефон", 13f, P.sub()), t1), c.card(c.tv("Батарея", 13f, P.sub()), t2),
        c.card(c.tv("NOVA в цифрах", 13f, P.sub()), t3),
        c.btn("Точный расход по приложениям (система)", false) {
            try { c.startActivity(Intent(Intent.ACTION_POWER_USAGE_SUMMARY).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) } catch (e: Exception) { Toast.makeText(c, "Не удалось открыть", Toast.LENGTH_SHORT).show() }
        })
}

class Shell(c: Context, val title: String, val bgKey: String, val tabs: List<String>, val corner: Int = 0, val onClose: (() -> Unit)? = null,
            val page: (Int, Shell) -> View) : FrameLayout(c) {
    var cur = 0; var sub = 0; var flag = false; var info = false; var sy = 0
    private val bg = BG(c, P.str(bgKey, "stars"))
    init { rebuild() }
    fun rebuild() {
        removeAllViews(); val c = context
        background = rr(P.bg(), c.dp(corner).toFloat()); clipToOutline = true
        bg.applyMode(P.str(bgKey, "stars")); addView(bg, FrameLayout.LayoutParams(-1, -1))
        val root = LinearLayout(c).apply { orientation = LinearLayout.VERTICAL }
        val hd = LinearLayout(c).apply { gravity = Gravity.CENTER_VERTICAL; setPadding(c.dp(16), c.dp(10), c.dp(10), c.dp(4)) }
        hd.addView(c.tv(title, 18f, P.accent, true), LinearLayout.LayoutParams(0, -2, 1f))
        hd.addView(c.tv("?", 16f, P.accent, true).apply {
            gravity = Gravity.CENTER; background = rr(P.card(), c.dp(18).toFloat(), P.accent); setOnClickListener { info = !info; sy = 0; rebuild() }
        }, LinearLayout.LayoutParams(c.dp(36), c.dp(36)))
        onClose?.let { cl ->
            hd.addView(c.tv("✕", 16f, P.fg(), true).apply { gravity = Gravity.CENTER; setOnClickListener { cl() } },
                LinearLayout.LayoutParams(c.dp(36), c.dp(36)).apply { leftMargin = c.dp(8) })
        }
        root.addView(hd)
        val me = this
        val wpx = c.resources.displayMetrics.widthPixels; val maxW = c.dp(640)
        val body = FrameLayout(c).apply {
            addView(if (info) c.infoView() else page(cur, me), FrameLayout.LayoutParams(if (corner == 0 && wpx > maxW) maxW else -1, -2, Gravity.CENTER_HORIZONTAL))
        }
        val sv = ScrollView(c).apply { addView(body); setOnScrollChangeListener { _, _, y, _, _ -> sy = y } }
        val want = sy
        sv.viewTreeObserver.addOnGlobalLayoutListener(object : ViewTreeObserver.OnGlobalLayoutListener {
            override fun onGlobalLayout() { sv.viewTreeObserver.removeOnGlobalLayoutListener(this); sv.scrollTo(0, want) }
        })
        root.addView(sv, LinearLayout.LayoutParams(-1, 0, 1f))
        val tb = LinearLayout(c).apply { setPadding(c.dp(10), c.dp(6), c.dp(10), c.dp(10)) }
        tabs.forEachIndexed { i, n ->
            tb.addView(c.btn(n, i == cur && !info) { cur = i; info = false; sy = 0; rebuild() }.apply { textSize = if (tabs.size > 3) 11f else 12f; setPadding(c.dp(4), c.dp(11), c.dp(4), c.dp(11)) },
                LinearLayout.LayoutParams(0, -2, 1f).apply { setMargins(c.dp(3), 0, c.dp(3), 0) })
        }
        root.addView(tb); addView(root, FrameLayout.LayoutParams(-1, -1))
    }
}
