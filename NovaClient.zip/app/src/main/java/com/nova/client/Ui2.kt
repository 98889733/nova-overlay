package com.nova.client
import android.app.ActivityManager
import android.content.*
import android.graphics.*
import android.graphics.drawable.GradientDrawable
import android.hardware.display.DisplayManager
import android.os.*
import android.view.*
import android.widget.*
import kotlin.math.*

object Sc { val m = HashMap<String, Int>() }
object UiS { var wheel = ""; var pw = false; var xpin = false; var stab = 0; var gtab = 0; var top = false }

fun HorizontalScrollView.keep(key: String) {
    setOnScrollChangeListener { _, x, _, _, _ -> Sc.m[key] = x }
    val me = this
    viewTreeObserver.addOnGlobalLayoutListener(object : ViewTreeObserver.OnGlobalLayoutListener {
        override fun onGlobalLayout() { me.viewTreeObserver.removeOnGlobalLayoutListener(this); me.scrollTo(Sc.m[key] ?: 0, 0) }
    })
}
fun Context.colorRow(list: List<Int>, cur: Int, key: String, onWheel: () -> Unit, sel: (Int) -> Unit): View = HorizontalScrollView(this).apply {
    isHorizontalScrollBarEnabled = false; keep(key)
    addView(LinearLayout(context).apply {
        list.forEach { c ->
            addView(tv(if (c == 0) "A" else "", 13f, P.fg(), true).apply {
                gravity = Gravity.CENTER
                background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(if (c == 0) P.card() else c); setStroke(if (c == cur) dp(3) else dp(1), if (c == cur) P.fg() else P.sub()) }
                setOnClickListener { sel(c) }
            }, LinearLayout.LayoutParams(dp(38), dp(38)).apply { rightMargin = dp(8) })
        }
        addView(tv("+", 18f, Color.WHITE, true).apply {
            gravity = Gravity.CENTER
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL; setGradientType(GradientDrawable.SWEEP_GRADIENT)
                setColors(intArrayOf(-65536, -256, -16711936, -16711681, -16776961, -65281, -65536)); setStroke(dp(1), P.sub())
            }
            setOnClickListener { onWheel() }
        }, LinearLayout.LayoutParams(dp(38), dp(38)))
    })
}
fun Context.chipRow(items: List<Pair<String, String>>, cur: String, key: String, sel: (String) -> Unit): View = HorizontalScrollView(this).apply {
    isHorizontalScrollBarEnabled = false; keep(key)
    addView(LinearLayout(context).apply {
        items.forEach { (k, n) -> addView(btn(n, k == cur) { sel(k) }.apply { textSize = 12f }, LinearLayout.LayoutParams(-2, -2).apply { rightMargin = dp(6) }) }
    })
}

class Wheel(c: Context, start: Int, val pick: (Int) -> Unit) : View(c) {
    private val hsv = FloatArray(3).also { Color.colorToHSV(start, it) }
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private var mode = 0
    private fun rad() = width / 2f - context.dp(10)
    private fun barL() = context.dp(10).toFloat()
    private fun barR() = width - context.dp(10).toFloat()
    override fun onMeasure(w: Int, h: Int) { val ww = minOf(MeasureSpec.getSize(w), context.dp(280)); setMeasuredDimension(ww, ww + context.dp(46)) }
    override fun onDraw(cv: Canvas) {
        val cx = width / 2f; val r = rad()
        p.style = Paint.Style.FILL
        p.shader = SweepGradient(cx, cx, intArrayOf(-65536, -256, -16711936, -16711681, -16776961, -65281, -65536), null); cv.drawCircle(cx, cx, r, p)
        p.shader = RadialGradient(cx, cx, r, Color.WHITE, 0x00FFFFFF, Shader.TileMode.CLAMP); cv.drawCircle(cx, cx, r, p)
        p.shader = null; p.color = Color.argb(((1 - hsv[2]) * 255).toInt(), 0, 0, 0); cv.drawCircle(cx, cx, r, p)
        val a = Math.toRadians(hsv[0].toDouble())
        val mx = cx + (hsv[1] * r * cos(a)).toFloat(); val my = cx + (hsv[1] * r * sin(a)).toFloat()
        p.style = Paint.Style.STROKE; p.strokeWidth = context.dp(3).toFloat(); p.color = Color.WHITE; cv.drawCircle(mx, my, context.dp(9).toFloat(), p)
        p.strokeWidth = context.dp(1).toFloat(); p.color = Color.BLACK; cv.drawCircle(mx, my, context.dp(11).toFloat(), p)
        val top = cx * 2 + context.dp(12); val bot = top + context.dp(22); val l = barL(); val rt = barR()
        p.style = Paint.Style.FILL
        p.shader = LinearGradient(l, 0f, rt, 0f, Color.BLACK, Color.HSVToColor(floatArrayOf(hsv[0], hsv[1], 1f)), Shader.TileMode.CLAMP)
        cv.drawRoundRect(l, top, rt, bot, 14f, 14f, p); p.shader = null
        val tx = l + hsv[2] * (rt - l); p.style = Paint.Style.STROKE; p.strokeWidth = context.dp(3).toFloat(); p.color = Color.WHITE
        cv.drawCircle(tx, (top + bot) / 2, context.dp(12).toFloat(), p)
    }
    override fun onTouchEvent(e: MotionEvent): Boolean {
        val cx = width / 2f
        if (e.action == MotionEvent.ACTION_DOWN) mode = if (e.y > cx * 2 + context.dp(4)) 1 else 0
        if (mode == 0) {
            val dx = e.x - cx; val dy = e.y - cx
            hsv[0] = ((Math.toDegrees(atan2(dy, dx).toDouble()) + 360) % 360).toFloat(); hsv[1] = min(1f, hypot(dx, dy) / rad())
        } else hsv[2] = ((e.x - barL()) / (barR() - barL())).coerceIn(0.02f, 1f)
        invalidate(); parent?.requestDisallowInterceptTouchEvent(true)
        if (e.action == MotionEvent.ACTION_UP) pick(Color.HSVToColor(hsv))
        return true
    }
}

fun Context.gate(k: String): Boolean {
    if (Xp.ok(k)) return true
    Toast.makeText(this, "Откроется на уровне ${Xp.need(k)}", Toast.LENGTH_SHORT).show(); return false
}
fun Context.sw(label: String, key: String, need: String? = null, a: () -> Unit): Switch {
    val locked = need != null && !Xp.ok(need)
    var busy = false
    return Switch(this).apply {
        text = label + if (locked) "  ·  ур. ${Xp.need(need!!)}" else ""
        setTextColor(if (locked) P.sub() else P.fg()); isChecked = P.sp.getBoolean(key, false) && !locked
        setOnCheckedChangeListener { v, b ->
            if (!busy) {
                if (b && locked) { busy = true; v.isChecked = false; busy = false; gate(need!!) }
                else { P.putB(key, b); a() }
            }
        }
    }
}
fun Context.seek(k: String, lo: Int, hi: Int, def: Int, need: String? = null, a: () -> Unit) = SeekBar(this).apply {
    max = hi - lo; progress = P.int(k, def) - lo
    setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
        override fun onProgressChanged(s: SeekBar?, p: Int, u: Boolean) {}
        override fun onStartTrackingTouch(s: SeekBar?) {}
        override fun onStopTrackingTouch(s: SeekBar?) {
            if (need != null && !Xp.ok(need)) { gate(need); progress = P.int(k, def) - lo }
            else { P.putI(k, (s?.progress ?: 0) + lo); a() }
        }
    })
}
fun Context.sec(t: String) = tv(t.uppercase(), 11f, P.accent, true).apply { letterSpacing = 0.12f; setPadding(0, dp(10), 0, 0) }
fun Context.bar(f: Float): View {
    val ff = f.coerceIn(0.03f, 0.97f)
    return LinearLayout(this).apply {
        background = rr(P.mix(P.bg(), P.fg(), 0.12f), dp(6).toFloat())
        addView(View(context).apply { background = rr(P.accent, dp(6).toFloat()) }, LinearLayout.LayoutParams(0, dp(10), ff))
        addView(View(context), LinearLayout.LayoutParams(0, dp(10), 1f - ff))
    }
}
val SHAPES = listOf("round" to "Круглая", "capsule" to "Капсула", "square" to "Квадрат", "leaf" to "Листик", "cut" to "Срез")
fun lbl(k: String, n: String, pre: String) = if (Xp.ok(pre + k)) n else "$n · ур.${Xp.need(pre + k)}"

fun Context.colorSec(label: String, key: String, list: List<Int>, cur: Int, def: Int, a: () -> Unit): List<View> {
    val l = arrayListOf<View>(tv(label, 13f, P.sub()), colorRow(list, cur, key, { if (gate("wheel")) { UiS.wheel = if (UiS.wheel == key) "" else key; a() } }) { UiS.wheel = ""; P.putI(key, it); if (key == "acc") Q.done("color"); a() })
    if (UiS.wheel == key && Xp.ok("wheel")) l.add(Wheel(this, def) { P.putI(key, it); if (key == "acc") Q.done("color"); a() })
    return l
}
val STABS = listOf("Тема и цвета", "Фон", "Плашка", "Система", "Промокоды")
val PROMOS = mapOf("BOBO" to 250L, "FLY" to 100L, "NOVAHUB" to 600L, "NOVA" to 50L, "3131" to 5000L)
fun Context.redeem(raw: String, done: () -> Unit) {
    val code = raw.trim().uppercase().removePrefix("(").substringBefore(")").substringBefore("-").trim()
    val xp = PROMOS[code]
    if (code.isEmpty()) Toast.makeText(this, "Введи промокод", Toast.LENGTH_SHORT).show()
    else if (xp == null) Toast.makeText(this, "Такого промокода нет", Toast.LENGTH_SHORT).show()
    else if (P.sp.getBoolean("promo_$code", false)) Toast.makeText(this, "Этот промокод уже использован", Toast.LENGTH_SHORT).show()
    else { P.putB("promo_$code", true); Xp.add(xp); Xp.say("Промокод принят: +$xp XP"); done() }
}
fun Context.settingsView(apply: () -> Unit): View {
    val a = { OverlayService.inst?.restyle(); apply() }
    val v = ArrayList<View>()
    v.add(chipRow(STABS.mapIndexed { i, n -> "$i" to n }, "${UiS.stab}", "stab") { UiS.stab = it.toInt(); UiS.top = true; apply() })
    when (UiS.stab) {
        0 -> {
            val dk = Switch(this).apply {
                text = "Тёмная тема"; setTextColor(P.fg()); isChecked = P.dark
                setOnCheckedChangeListener { _, b -> P.putB("dark", b); P.putI("pbg", 0); P.putI("ptx", 0); a() }
            }
            v.add(sec("Тема")); v.add(dk)
            v.add(sec("Цвета"))
            v.addAll(colorSec("Акцентный цвет", "acc", ACC, P.accent, P.accent, a))
            v.addAll(colorSec("Цвет текста (A — авто)", "ptx", TXT, P.int("ptx", 0), P.fg(), a))
            v.addAll(colorSec("Цвет фона (A — авто)", "pbg", PBG, P.int("pbg", 0), P.bg(), a))
            v.add(tv("Кнопка «+» открывает цветовой круг (ур. ${Xp.need("wheel")})", 11f, P.sub()))
        }
        1 -> {
            val modes = MODES.map { it.first to lbl(it.first, it.second, "bg_") }
            v.add(sec("Фон"))
            v.add(tv("Фон плавающего меню", 13f, P.sub())); v.add(chipRow(modes, P.str("bgM", "stars"), "bgM") { if (gate("bg_$it")) { P.putS("bgM", it); Q.done("bg"); a() } })
            v.add(tv("Фон приложения", 13f, P.sub())); v.add(chipRow(modes, P.str("bgA", "stars"), "bgA") { if (gate("bg_$it")) { P.putS("bgA", it); Q.done("bg"); a() } })
            v.add(tv("Скорость анимации", 12f, P.sub())); v.add(seek("bgs", 30, 250, 100, "bgs", a))
            v.add(sw("Остановить анимацию (экономит батарею)", "bgoff", null, a))
        }
        2 -> {
            v.add(sec("Плашка FPS"))
            v.add(tv("Форма", 13f, P.sub())); v.add(chipRow(SHAPES.map { it.first to lbl(it.first, it.second, "shape_") }, P.str("pshape", "round"), "pshape") { if (gate("shape_$it")) { P.putS("pshape", it); Q.done("shape"); a() } })
            v.add(tv("Размер текста", 12f, P.sub())); v.add(seek("psz", 11, 22, 13, null, a))
            v.add(tv("Прозрачность", 12f, P.sub())); v.add(seek("pop", 30, 100, 100, null, a))
            v.add(sw("Время и заряд на плашке", "pinfo", "pinfo", a))
            v.add(sw("Прилипать к краю экрана", "snap", "snap", a))
            v.add(sw("Не гасить экран", "awake", "awake", a))
            v.add(sec("Окно меню"))
            v.add(tv("Скругление окна меню", 12f, P.sub())); v.add(seek("mr", 0, 40, 24, null, a))
        }
        3 -> {
            v.add(sec("Система"))
            v.add(sw("Запускать меню при включении телефона", "boot", "boot") {})
            v.add(btn("Сбросить настройки (уровень сохранится)", false) {
                val keep = P.sp.all.filterKeys { it.startsWith("promo_") || it.startsWith("q_") || it == "xp" || it == "xp_day" || it == "apps" }
                val e = P.sp.edit().clear()
                keep.forEach { (k, x) -> when (x) { is Boolean -> e.putBoolean(k, x); is Long -> e.putLong(k, x); is String -> e.putString(k, x) } }
                e.apply(); UiS.wheel = ""; a()
            })
            if (UiS.pw) v.add(card(tv("Доступ", 13f, P.sub()), KeyPad(this, "Пароль", true, false, "Войти") { t ->
                if (sha(t) == SECRET) { P.putB("dev", true); UiS.pw = false; Toast.makeText(this, "Секретное меню открыто", Toast.LENGTH_LONG).show(); a() }
                else Toast.makeText(this, "Неверно", Toast.LENGTH_SHORT).show()
            }, btn("Отмена", false) { UiS.pw = false; apply() }))
            v.add(tv("NOVA Client v1.1", 11f, P.sub()).apply {
                gravity = Gravity.CENTER; setPadding(0, dp(18), 0, dp(6))
                setOnClickListener { secretTaps++; if (secretTaps >= 7) { secretTaps = 0; UiS.pw = true; apply() } }
            })
            if (P.sp.getBoolean("dev", false)) v.addAll(secretSection(a))
        }
        else -> {
            val used = PROMOS.keys.filter { P.sp.getBoolean("promo_$it", false) }
            v.add(sec("Промокоды"))
            v.add(card(tv("Введи промокод и получи опыт (XP). Каждый код работает один раз.", 13f), KeyPad(this, "Промокод", false, false, "Активировать") { redeem(it, a) }))
            v.add(tv("Активировано: " + if (used.isEmpty()) "пока ничего" else used.joinToString(", "), 12f, P.sub()))
        }
    }
    return stack(*v.toTypedArray())
}
var secretTaps = 0
const val SECRET = "50da30b0157229b8ff169edfbd31de65a4621394265f24201a6236982bed9ce0"
fun sha(s: String) = java.security.MessageDigest.getInstance("SHA-256").digest(s.toByteArray()).joinToString("") { "%02x".format(it) }
fun Context.secretSection(a: () -> Unit): List<View> {
    val l = ArrayList<View>()
    l.add(sec("Секретное меню"))
    l.add(tv("Уровень ${Xp.level()} · ${Xp.xp()} XP", 13f, P.fg()))
    l.add(tv("Установить уровень", 12f, P.sub()))
    l.add(SeekBar(this).apply {
        max = 59; progress = (Xp.level() - 1).coerceIn(0, 59)
        setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, u: Boolean) {}
            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) { P.putL("xp", Xp.base((s?.progress ?: 0) + 1)); a() }
        })
    })
    l.add(row3(btn("+100 XP", false) { Xp.add(100); a() }, btn("+1000", false) { Xp.add(1000); a() }, btn("+10000", false) { Xp.add(10000); a() }))
    l.add(btn("Ввести XP числом", false) { UiS.xpin = !UiS.xpin; a() })
    if (UiS.xpin) l.add(KeyPad(this, "XP", false, true, "Задать") { t -> t.toLongOrNull()?.let { P.putL("xp", it.coerceIn(0L, 100000000L)) }; UiS.xpin = false; a() })
    l.add(sw("Открыть все функции", "all", null, a))
    l.add(btn("Выполнить все задания") { Q.all(); a() })
    l.add(btn("Сбросить прогресс", false) { P.putL("xp", 0); QUESTS.forEach { P.putB("q_${it.k}", false) }; P.putB("all", false); a() })
    l.add(btn("Скрыть секретное меню", false) { P.putB("dev", false); a() })
    return l
}
fun levelPage(c: Context): View {
    val x = Xp.xp(); val l = Xp.level(x); val lo = Xp.base(l); val hi = Xp.base(l + 1)
    val rows = UNLOCKS.map { (lv, t) -> c.tv((if (l >= lv) "✓ " else "· ") + "Ур. $lv — $t", 13f, if (l >= lv) P.fg() else P.sub()) }
    return c.stack(
        c.card(c.tv("Уровень $l", 24f, P.accent, true), c.bar((x - lo).toFloat() / (hi - lo)), c.tv("$x / $hi XP", 13f, P.fg()),
            c.tv("Опыт идёт, пока меню запущено или приложение открыто: 20 XP за 10 минут. +10 XP за первый вход каждый день.", 12f, P.sub())),
        c.card(*(listOf<View>(c.tv("Что открывается", 13f, P.sub())) + rows).toTypedArray()),
        c.card(*(listOf<View>(c.tv("Задания", 13f, P.sub())) + QUESTS.map { c.tv((if (Q.has(it.k)) "✓ " else "· ") + it.t + "  (+${it.xp} XP)", 13f, if (Q.has(it.k)) P.fg() else P.sub()) }).toTypedArray()),
        c.card(c.tv("Приложений в плавающем меню: ${Xp.maxApps()}", 14f), c.tv("Каждый новый уровень даёт ещё один слот.", 12f, P.sub())))
}

fun level(c: Context): Int {
    val i = c.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
    val l = i?.getIntExtra("level", -1) ?: -1; val s = i?.getIntExtra("scale", 100) ?: 100
    return l * 100 / s
}
fun gb(b: Long) = "%.1f ГБ".format(b / 1073741824.0)
fun phoneInfo(c: Context): String {
    val mi = ActivityManager.MemoryInfo(); c.getSystemService(ActivityManager::class.java).getMemoryInfo(mi)
    val st = StatFs(Environment.getDataDirectory().path); val dm = c.resources.displayMetrics
    val hz = c.getSystemService(DisplayManager::class.java).getDisplay(0)?.refreshRate ?: 0f
    val up = SystemClock.elapsedRealtime() / 60000
    return "Модель: ${Build.MANUFACTURER} ${Build.MODEL}\nAndroid ${Build.VERSION.RELEASE} (API ${Build.VERSION.SDK_INT})\n" +
        "Экран: ${dm.widthPixels}×${dm.heightPixels}, ${dm.densityDpi} dpi, ${"%.0f".format(hz)} Гц\n" +
        "Процессор: ${Runtime.getRuntime().availableProcessors()} ядер, ${Build.SUPPORTED_ABIS[0]}\n" +
        "ОЗУ: свободно ${gb(mi.availMem)} из ${gb(mi.totalMem)}\nПамять: свободно ${gb(st.availableBytes)} из ${gb(st.totalBytes)}\n" +
        "Включён: ${up / 60} ч ${up % 60} мин"
}
fun batInfo(c: Context): String {
    val i = c.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
    val t = (i?.getIntExtra("temperature", 0) ?: 0) / 10f; val v = (i?.getIntExtra("voltage", 0) ?: 0) / 1000f
    val hl = when (i?.getIntExtra("health", 1)) { 2 -> "хорошее"; 3 -> "перегрев"; 4 -> "изношена"; 5 -> "перенапряжение"; 7 -> "холодная"; else -> "неизвестно" }
    return "Заряд: ${battery(c)}\nТемпература: ${"%.1f".format(t)} °C\nНапряжение: ${"%.2f".format(v)} В\nСостояние: $hl"
}
fun appStats(c: Context): String {
    val rt = Runtime.getRuntime(); val mem = (rt.totalMemory() - rt.freeMemory()) / 1048576
    val t0 = P.getL("ses_t")
    val s = if (OverlayService.inst != null && t0 > 0) {
        val b0 = P.int("ses_b", 0); val cur = level(c)
        "Меню работает: ${(System.currentTimeMillis() - t0) / 60000} мин\nЗаряд за это время: $b0% → $cur% (${cur - b0}%)"
    } else "Меню остановлено\nПоследняя сессия: ${P.getL("last_m")} мин, изменение заряда ${P.int("last_d", 0)}%"
    return "$s\nПамять приложения: $mem МБ\nЦифры заряда — расход всего телефона за это время, а не только NOVA."
}
fun phonePage(c: Context, sh: Shell): View {
    val t1 = c.tv("", 13f); tick(t1) { phoneInfo(c) }
    val t2 = c.tv("", 13f); tick(t2) { batInfo(c) }
    val t3 = c.tv("", 13f); tick(t3) { appStats(c) }
    return c.stack(c.card(c.tv("Телефон", 13f, P.sub()), t1), c.card(c.tv("Батарея", 13f, P.sub()), t2),
        c.card(c.tv("NOVA в цифрах", 13f, P.sub()), t3),
        c.btn("Точный расход по приложениям (система)", false) {
            try { c.startActivity(Intent(Intent.ACTION_POWER_USAGE_SUMMARY).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) } catch (e: Exception) { Toast.makeText(c, "Не удалось открыть", Toast.LENGTH_SHORT).show() }
        })
}

class Shell(c: Context, val title: String, val bgKey: String, val tabs: List<String>, val corner: Int = 0, val onClose: (() -> Unit)? = null,
            val page: (Int, Shell) -> View) : FrameLayout(c) {
    var cur = 0; var sub = 0; var flag = false; var info = false; var sy = 0
    private val bg = BG(c, P.str(bgKey, "stars"))
    init { rebuild() }
    fun rebuild() {
        removeAllViews(); val c = context
        background = rr(P.bg(), c.dp(corner).toFloat()); clipToOutline = true
        bg.applyMode(P.str(bgKey, "stars")); addView(bg, FrameLayout.LayoutParams(-1, -1))
        val root = LinearLayout(c).apply { orientation = LinearLayout.VERTICAL }
        val hd = LinearLayout(c).apply { gravity = Gravity.CENTER_VERTICAL; setPadding(c.dp(16), c.dp(10), c.dp(10), c.dp(4)) }
        hd.addView(c.tv(title, 18f, P.accent, true), LinearLayout.LayoutParams(0, -2, 1f))
        hd.addView(c.tv("?", 16f, P.accent, true).apply {
            gravity = Gravity.CENTER; background = rr(P.card(), c.dp(18).toFloat(), P.accent); setOnClickListener { info = !info; sy = 0; rebuild() }
        }, LinearLayout.LayoutParams(c.dp(36), c.dp(36)))
        onClose?.let { cl ->
            hd.addView(c.tv("✕", 16f, P.fg(), true).apply { gravity = Gravity.CENTER; setOnClickListener { cl() } },
                LinearLayout.LayoutParams(c.dp(36), c.dp(36)).apply { leftMargin = c.dp(8) })
        }
        root.addView(hd)
        val me = this
        val wpx = c.resources.displayMetrics.widthPixels; val maxW = c.dp(640)
        val body = FrameLayout(c).apply {
            addView(if (info) c.infoView() else page(cur, me), FrameLayout.LayoutParams(if (corner == 0 && wpx > maxW) maxW else -1, -2, Gravity.CENTER_HORIZONTAL))
        }
        val sv = ScrollView(c).apply { addView(body); setOnScrollChangeListener { _, _, y, _, _ -> sy = y } }
        if (UiS.top) { sy = 0; UiS.top = false }
        val want = sy
        sv.viewTreeObserver.addOnGlobalLayoutListener(object : ViewTreeObserver.OnGlobalLayoutListener {
            override fun onGlobalLayout() { sv.viewTreeObserver.removeOnGlobalLayoutListener(this); sv.scrollTo(0, want) }
        })
        root.addView(sv, LinearLayout.LayoutParams(-1, 0, 1f))
        val tb = LinearLayout(c).apply { setPadding(c.dp(10), c.dp(6), c.dp(10), c.dp(10)) }
        tabs.forEachIndexed { i, n ->
            tb.addView(c.btn(n, i == cur && !info) { cur = i; info = false; sy = 0; rebuild() }.apply { textSize = if (tabs.size > 4) 12f else if (tabs.size > 3) 11f else 12f; setPadding(c.dp(if (tabs.size > 4) 14 else 4), c.dp(11), c.dp(if (tabs.size > 4) 14 else 4), c.dp(11)) },
                (if (tabs.size > 4) LinearLayout.LayoutParams(-2, -2) else LinearLayout.LayoutParams(0, -2, 1f)).apply { setMargins(c.dp(3), 0, c.dp(3), 0) })
        }
        root.addView(if (tabs.size > 4) HorizontalScrollView(c).apply { isHorizontalScrollBarEnabled = false; addView(tb) } else tb); addView(root, FrameLayout.LayoutParams(-1, -1))
    }
}
