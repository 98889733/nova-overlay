package com.nova.client
import android.content.Context
import android.graphics.Color
import android.view.*
import android.widget.*
import kotlin.math.abs

object SW {
    var start = 0L; var acc = 0L; var running = false; val laps = ArrayList<Long>()
    fun now() = if (running) acc + System.currentTimeMillis() - start else acc
    fun toggle() { if (running) { acc += System.currentTimeMillis() - start; running = false } else { start = System.currentTimeMillis(); running = true } }
    fun lap() { if (running) laps.add(0, now()) }
    fun reset() { running = false; acc = 0; laps.clear() }
    fun fmt(ms: Long) = "%02d:%02d.%d".format(ms / 60000, ms / 1000 % 60, ms / 100 % 10)
}
fun tickMs(v: TextView, ms: Long, f: () -> String) { v.text = f(); v.postDelayed({ if (v.isAttachedToWindow) tickMs(v, ms, f) }, ms) }

fun toolsPage(c: Context, sh: Shell): View {
    val clock = c.tv("", 24f, P.fg(), true); tick(clock) { java.text.SimpleDateFormat("HH:mm:ss", java.util.Locale.getDefault()).format(java.util.Date()) }
    val bat = c.tv("", 14f, P.sub()); tick(bat) { "Заряд: " + battery(c) }
    val tl = c.tv("", 34f, P.accent, true).apply { gravity = Gravity.CENTER }
    tick(tl) { val s = T.left(); "%02d:%02d".format(s / 60, s % 60) }
    val run = T.end > 0
    val sw = c.tv("", 34f, P.accent, true).apply { gravity = Gravity.CENTER }
    tickMs(sw, 100) { SW.fmt(SW.now()) }
    val laps = SW.laps.take(5).mapIndexed { i, l -> c.tv("Круг ${SW.laps.size - i}: ${SW.fmt(l)}", 12f, P.sub()) }
    return c.stack(
        c.card(clock, bat),
        c.card(c.tv("Таймер", 13f, P.sub()), tl,
            c.row3(c.btn("+1 мин", false) { if (!run) T.total += 60; sh.rebuild() }, c.btn("+5 мин", false) { if (!run) T.total += 300; sh.rebuild() }, c.btn("Сброс", false) { T.stop(); T.total = 0; sh.rebuild() }),
            c.btn(if (run) "Стоп" else "Старт") { if (run) T.stop() else T.start(c.applicationContext); sh.rebuild() }),
        c.card(*(listOf<View>(c.tv("Секундомер", 13f, P.sub()), sw,
            c.row3(c.btn(if (SW.running) "Стоп" else "Старт") { SW.toggle(); if (SW.running) Q.done("sw"); sh.rebuild() }, c.btn("Круг", false) { SW.lap(); sh.rebuild() }, c.btn("Сброс", false) { SW.reset(); sh.rebuild() })) + laps).toTypedArray()))
}

fun notesList() = P.str("notes", "").split("\u0001").filter { it.isNotEmpty() }
fun notesPage(c: Context, sh: Shell): View {
    val v = ArrayList<View>()
    v.add(KeyPad(c, "Новая заметка", false, false, "Сохранить", false) { t ->
        val s = t.trim()
        if (s.isNotEmpty()) { P.putS("notes", (listOf(s) + notesList()).take(30).joinToString("\u0001")); Q.done("note"); sh.rebuild() }
    })
    val list = notesList()
    if (list.isEmpty()) v.add(c.tv("Заметок пока нет. Напиши что-нибудь выше.", 12f, P.sub()))
    list.forEachIndexed { i, n ->
        v.add(LinearLayout(c).apply {
            gravity = Gravity.CENTER_VERTICAL; setPadding(c.dp(12), c.dp(10), c.dp(8), c.dp(10)); background = rr(P.card(), c.dp(12).toFloat())
            addView(c.tv(n, 14f), LinearLayout.LayoutParams(0, -2, 1f))
            addView(Ico(c, "remove", P.sub(), 24).apply {
                setOnClickListener { P.putS("notes", list.filterIndexed { j, _ -> j != i }.joinToString("\u0001")); sh.rebuild() }
            }, LinearLayout.LayoutParams(c.dp(36), c.dp(36)))
        })
    }
    return c.stack(*v.toTypedArray())
}

fun calc(expr: String): String? {
    val s = expr.replace(" ", ""); var i = 0
    fun num(): Double? { val st = i; while (i < s.length && (s[i].isDigit() || s[i] == '.')) i++; return s.substring(st, i).toDoubleOrNull() }
    fun term(): Double? {
        var a = num() ?: return null
        while (i < s.length && (s[i] == '×' || s[i] == '÷')) { val op = s[i]; i++; val b = num() ?: return null; a = if (op == '×') a * b else a / b }
        return a
    }
    var r = term() ?: return null
    while (i < s.length && (s[i] == '+' || s[i] == '−')) { val op = s[i]; i++; val b = term() ?: return null; r = if (op == '+') r + b else r - b }
    if (i != s.length || r.isNaN() || r.isInfinite()) return null
    return if (r == Math.floor(r) && abs(r) < 1e15) r.toLong().toString() else "%.8f".format(r).trimEnd('0').trimEnd('.')
}
fun calcPage(c: Context): View {
    val ex = StringBuilder()
    val disp = c.tv("0", 28f, P.accent, true).apply {
        gravity = Gravity.END; setPadding(c.dp(14), c.dp(12), c.dp(14), c.dp(12)); background = rr(P.card(), c.dp(14).toFloat(), P.accent); maxLines = 2
    }
    fun upd() { disp.text = if (ex.isEmpty()) "0" else ex.toString() }
    val rows = listOf(listOf("C", "⌫", "÷", "×"), listOf("7", "8", "9", "−"), listOf("4", "5", "6", "+"), listOf("1", "2", "3", "="), listOf("0", "00", ".", ""))
    val v = ArrayList<View>(); v.add(disp)
    for (row in rows) {
        v.add(LinearLayout(c).apply {
            for (k in row) {
                val lp = LinearLayout.LayoutParams(0, c.dp(48), 1f).apply { setMargins(c.dp(2), c.dp(2), c.dp(2), c.dp(2)) }
                if (k.isEmpty()) { addView(View(c), lp); continue }
                val acc = k == "=" || k == "÷" || k == "×" || k == "−" || k == "+"
                addView(c.tv(k, 18f, if (k == "=") Color.WHITE else if (acc) P.accent else P.fg(), true).apply {
                    gravity = Gravity.CENTER
                    background = if (k == "=") GlowDrawable(c.dp(10).toFloat(), P.accent, c.dp(2).toFloat()) else rr(P.card(), c.dp(10).toFloat(), P.mix(P.bg(), P.fg(), 0.1f))
                    setOnClickListener {
                        performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP)
                        when (k) {
                            "C" -> ex.setLength(0)
                            "⌫" -> if (ex.isNotEmpty()) ex.setLength(ex.length - 1)
                            "=" -> { val r = calc(ex.toString()); if (r != null) { ex.setLength(0); ex.append(r); Q.done("calc") } else Toast.makeText(c, "Ошибка в выражении", Toast.LENGTH_SHORT).show() }
                            else -> if (ex.length < 24) ex.append(k)
                        }
                        upd()
                    }
                }, lp)
            }
        })
    }
    return c.stack(*v.toTypedArray())
}
