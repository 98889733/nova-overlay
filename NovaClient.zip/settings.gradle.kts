pluginManagement {
    repositories { google(); mavenCentral(); gradlePluginPortal() }
    val agp: String by settings
    val kgp: String by settings
    plugins {
        id("com.android.application") version agp
        id("org.jetbrains.kotlin.android") version kgp
    }
}
dependencyResolutionManagement { repositories { google(); mavenCentral() } }
rootProject.name = "NovaClient"
include(":app")
